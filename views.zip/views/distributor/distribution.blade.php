
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title  -->
    

    <!-- Favicon  -->
    <link rel="icon" href="../../../customer/img/core-img/favicon.ico">

    <!-- Core Style CSS -->
    <link rel="stylesheet" href="../../../distributor/css/core-style.css">
    <link rel="stylesheet" href="../../../distributor/style.css">

    <!-- Responsive CSS -->
    <link href="../../../distributor/css/responsive.css" rel="stylesheet">
	<style>
		<style>
* {
    box-sizing: border-box;
}

body {
    margin: 0;
    font-family: Arial, Helvetica, sans-serif;
}
h1{
    font-family:arizonia;
}

.header {
    text-align: center;
    padding: 32px;
}

.row {
    display: -ms-flexbox; /* IE 10 */
    display: flex;
    -ms-flex-wrap: wrap; /* IE 10 */
    flex-wrap: wrap;
    padding: 0 4px;
}

/* Create two equal columns that sits next to each other */
.column {
    -ms-flex: 50%; /* IE 10 */
    flex: 50%;
    padding: 0 4px;
}

.column img {
    margin-top: 8px;
    vertical-align: middle;
}

/* Style the buttons */
.btn {
    border: none;
    outline: none;
    padding: 10px 16px;
    background-color: #f1f1f1;
    cursor: pointer;
    font-size: 18px;
}

.btn:hover {
    background-color: #ddd;
}

.btn.active {
    background-color: #666;
    color: white;
}
table
{
	text-align:center;
	
}
input[type=text],input[type=file],input[type=password],input[type=number],input[type=email],input[type=date],textarea,button {
    width: 100%;
    padding: 15px;
    margin: 5px 0 22px 0;
    display: inline-block;
    border: none;
    background: #f1f1f1;
	border-radius: 12px;
}
	
th
{
	height:70px;
	background-color:#000;
	text-align:center;
	color:#FFF;
}
td
{
	text-align:center;
}
	</style>
</head>

<body>
    <div class="catagories-side-menu">
        <!-- Close Icon -->
        <div id="sideMenuClose">
            <i class="ti-close"></i>
        </div>
        <!--  Side Nav  -->
        <div class="nav-side-menu">
            <div class="menu-list">
                <h6>Categories</h6>
                <ul id="menu-content" class="menu-content collapse out">
                    <!-- Single Item -->
                    <li data-toggle="collapse" data-target="#women" class="collapsed active">
                        <a href="#">Distributor<span class="arrow"></span></a>
                        <ul class="sub-menu collapse" id="women">
                            <li><a href="/distribution">Distribution Details</a></li>
                            <li><a href="/delivered_products">Completed Requests</a></li>
                            <li><a href="">Replacement Requests</a></li>
                            <li><a href="">Return Requests</a></li>
                           
                        </ul>
                    </li>
                    <!-- Single Item -->
                    
                    <!-- Single Item -->
                    <li data-toggle="collapse" data-target="#profile" class="collapsed">
                        <a href="#">Profile<span class="arrow"></span></a>
                        <ul class="sub-menu collapse" id="profile">
                            <li><a href="">My Profile</a></li>
                            <li><a href="">Change Password</a></li>
                            
                        </ul>
                    </li>
                    
                 </ul>
            </div>
        </div>
    </div>

    <div id="wrapper">

        <!-- ****** Header Area Start ****** -->
        <header class="header_area">
            <!-- Top Header Area Start -->
            <div class="top_header_area">
                <div class="container h-100">
                    <div class="row h-100 align-items-center justify-content-end">

                        <div class="col-12 col-lg-7">
                            <div class="top_single_area d-flex align-items-center">
                                <!-- Logo Area -->
                                <div class="top_logo">
                                    <a href="#"><h1>Haute Couture</h1></a>
                                </div>
                                <!-- Cart & Menu Area -->
                                <div class="header-cart-menu d-flex align-items-center ml-auto">
                                    <!-- Cart Area -->
                                    <div class="cart">
                                        <!--<a href="#" id="header-cart-btn" target="_blank"><span class="cart_quantity">2</span> <i class="ti-bag"></i> Your Bag $20</a>
                                       
                                         Cart List Area Start-->
                                        <ul class="cart-list">
                                            <li>
                                                <a href="#" class="image"><img src="../../../distributor/img/product-img/product-10.jpg" class="cart-thumb" alt=""></a>
                                                <div class="cart-item-desc">
                                                    <h6><a href="#">Women's Fashion</a></h6>
                                                    <p>1x - <span class="price">$10</span></p>
                                                </div>
                                                <span class="dropdown-product-remove"><i class="icon-cross"></i></span>
                                            </li>
                                            <li>
                                                <a href="#" class="image"><img src="../../../distributor/img/product-img/product-11.jpg" class="cart-thumb" alt=""></a>
                                                <div class="cart-item-desc">
                                                    <h6><a href="#">Women's Fashion</a></h6>
                                                    <p>1x - <span class="price">$10</span></p>
                                                </div>
                                                <span class="dropdown-product-remove"><i class="icon-cross"></i></span>
                                            </li>
                                            <li class="total">
                                                <span class="pull-right">Total: $20.00</span>
                                                <a href="cart.html" class="btn btn-sm btn-cart">Cart</a>
                                                <a href="checkout-1.html" class="btn btn-sm btn-checkout">Checkout</a>
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="header-right-side-menu ml-15">
                                        <a href="#" id="sideMenuBtn"><i class="ti-menu" aria-hidden="true"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>

            <!-- Top Header Area End -->
            <div class="main_header_area">
                <div class="container h-100">
                    <div class="row h-100">
                        <div class="col-12 d-md-flex justify-content-between">
                            <!-- Header Social Area -->
                            <!--<div class="header-social-area">
                                <a href="#"><span class="karl-level">Share</span> <i class="fa fa-pinterest" aria-hidden="true"></i></a>
                                <a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                                <a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                                <a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
                            </div>-->
                            <!-- Menu Area -->
                            <div class="main-menu-area">
                                <nav class="navbar navbar-expand-lg align-items-start">

                                    <!--<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#karl-navbar" aria-controls="karl-navbar" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"><i class="ti-menu"></i></span></button>

                                    <div class="collapse navbar-collapse align-items-start collapse" id="karl-navbar">
                                        <ul class="navbar-nav animated" id="nav">
                                            <li class="nav-item active"><a class="nav-link" href="index.html">Home</a></li>
                                            <li class="nav-item dropdown">
                                                <a class="nav-link dropdown-toggle" href="#" id="karlDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Pages</a>
                                                <div class="dropdown-menu" aria-labelledby="karlDropdown">
                                                    <a class="dropdown-item" href="index.html">Home</a>
                                                    <a class="dropdown-item" href="shop.html">Shop</a>
                                                    <a class="dropdown-item" href="product-details.html">Product Details</a>
                                                    <a class="dropdown-item" href="cart.html">Cart</a>
                                                    <a class="dropdown-item" href="checkout.html">Checkout</a>
                                                </div>
                                            </li>
                                            <li class="nav-item"><a class="nav-link" href="#">Dresses</a></li>
                                            <li class="nav-item"><a class="nav-link" href="#"><span class="karl-level">hot</span> Shoes</a></li>
                                            <li class="nav-item"><a class="nav-link" href="#">Contact</a></li>
                                        </ul>
                                    </div>-->
                                    <div>
                            	<ul class="navbar-nav animated" id="nav">
                                <li class="nav-item dropdown">

			
                                     <a class="nav-link dropdown-toggle" href="#" id="karlDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><img src="../../../distributor/images/user.png" style="width:45px;height:45px;"/>{{Session::get('email')}}{{csrf_field()}}</a>
                                                <div class="dropdown-menu" aria-labelledby="karlDropdown">
                                                    <a class="dropdown-item" href=""><img src="../../../distributor/images/user.png" style="width:20px; height:20px;"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Profile</a>

                                                    <a class="dropdown-item" href="/logout"><img src="../../../distributor/images/login-icon.jpg" style="width:20px; height:20px;"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Logout</a>
                                                    <!--<a class="dropdown-item" href="product-details.html">Product Details</a>
                                                    <a class="dropdown-item" href="cart.html">Cart</a>
                                                    <a class="dropdown-item" href="checkout.html">Checkout</a>-->
                                                </div>
                                 </li>
                                
                                 <li><br>
                                 	
                                 </li> 
                                               
                                  <li>
                                                                      
                                    </li>          
                                </ul>
                            </div>

                                </nav>
                            </div>
                            
                            <!-- Help Line -->
                            
                            <div class="help-line">
                                <a href="tel:+346573556778"><i class="ti-headphone-alt"></i> +91-9207064521</a>

                            </div>
                            
                        </div>
                                            </div>
                </div>
            </div>
        </header>
        <!-- ****** Header Area End ****** -->

        <!-- ****** Top Discount Area Start ****** -->
        <section class="top-discount-area d-md-flex align-items-center">
            <!-- Single Discount Area -->
            <div class="single-discount-area">
                <h5><a href="/log">HOME</a></h5>
                
            </div>
            <!-- Single Discount Area -->
            <div class="single-discount-area">
                <h5><a href="">Completed Requests</a></h5>
            </div>
            <!-- Single Discount Area -->
            <div class="single-discount-area">
                <h5><a href="">New Requests</a></h5>
            </div>
        </section>
        <!-- ****** Top Discount Area End ****** -->

        <!-- ****** Welcome Slides Area Start ****** -->


        <br><br><br>

<h5 style="color:#fc0c4c;margin-left: 90px;font-family: frosty;">My Account > Distribution Requests</h5>
<br>

        <?php
         $reg=Session::get('email');
            $reg_id=DB::table('logs')->where('email',$reg)->first();
// dd($reg_id);
        ?>
        <div style="width:1400px;">
           
   
                             <?php
            $my=DB::table('admin_request_designers')->where('status',2)->where('distributor_id',$reg_id->reg_id)->get();
                                
                                if(count($my)!=0)
                                {
                                    foreach($my as $im)
                                    {
                                        
                                        $email=DB::table('logs')->where('reg_id',$im->reg_id)->first();
                                        $product=DB::table('products')->where('product_id',$im->product_id)->first();
                                        $product_name=$product->product_name;
                                        $size=DB::table('letter_sizes')->where('letter_size_id',$product->letter_size_id)->first();
                                        $fabric=DB::table('fabrics')->where('fab_id',$product->fab_id)->first();
                                        $distributors=DB::table('registers')->select('registers.reg_id','registers.register_name','logs.email','logs.login_status','logs.login_type')
->join('logs','registers.reg_id','=','logs.reg_id')
->where(['login_type'=>3])
->get();
                                        //$co_id=$i->co_id;
                                        $delivery=DB::table('deliverydetails')->where('order_id',$im->order_id)->first();


                            ?>
                                       
                            
    <div style="width:1400px;height:300px;margin-left:100px;margin-top:5px;border-style:ridge;" align="center">

            <div style="width:180px;height:auto;margin-top:60px;float:left;"> 
                <img src="../../../storage/upload/<?php echo $product->cover_image;?>" style="width:150px;height:150px;">
            </div>
            <div style="width:600px;height:auto;float:left;display: inline;margin-top:60px;">
                <table style="width:500px;height:auto;" align="left">
                        <tr>
                            <td style="margin-left: 30px;font-family: Georgia;font-size:25px;">{{$product->product_name}}</td>
                            
                        </tr>
                        <tr>
                            <td style="margin-left: 30px;font-family: Georgia;font-size:15px;">{{$product->product_description}}</td>
                        </tr>
                        
                </table>
            </div>
            <div style="width:100px;height:auto;float:left;display: inline;margin-top:80px;">
                        <input type="text" id="product_color" style=" width:50px;height:50px;border-radius:25px;background-color:#{{$im->product_color}}">
            </div>
            <div style="width:150px;height:auto;float:left;display: inline;margin-top:80px;">
            
                {{$delivery->address}}

            </div>
            <div style="width:50px;height:auto;float:left;display: inline;margin-top:80px;">
            </div>
            <div style="width:100px;height:auto;float:left;display: inline;margin-top:50px;">

                        <table style="width:100px;">
                            
                            <?php

                                if($delivery->payment_mode=='card')
                                {

                                
                            ?>
                            <tr>
                                <td><img src="../../../admin/images/paid-cash.jpg" style="width:150px;height:150px;border-radius:150px;"></td>
                            </tr>

                            <?php
                                }
                                else if($delivery->payment_mode=='cash')
                                {

                                
                            ?>
                            <tr>
                            <td><button style="width:150px;height:80px;background-color:red;color:white">PAY</button></td>
                            </tr>

                            <?php
                                }
                            ?>
                        </table>
            </div>
            <div style="width:50px;height:auto;float:left;display: inline;margin-top:80px;">
            </div>
            <!--  -->
            <div style="width:50px;height:auto;float:left;display: inline;margin-top:80px;">
            </div>
            <div style="width:100px;height:auto;float:left;margin-top:100px;">
                <a href="{{route('delivered', ['ard_id' => $im->ard_id])}}"><button style="width:100px;height:80px;color:white;background-color:green;">Product Delivered</button></a>
            </div>
            
    </div>
            
        <?php

}
}
?>
   

</div> 



<?php
            $my=DB::table('request_designers')->where('status',3)->where('distributor_id',$reg_id->reg_id)->get();
                                
                                if(count($my)!=0)
                                {
                                    foreach($my as $im)
                                    {
                                        
                                        $email=DB::table('logs')->where('reg_id',$im->reg_id)->first();
                                        $product=DB::table('products')->where('product_id',$im->product_id)->first();
                                        $product_name=$product->product_name;
                                        $size=DB::table('letter_sizes')->where('letter_size_id',$product->letter_size_id)->first();
                                        $fabric=DB::table('fabrics')->where('fab_id',$product->fab_id)->first();
                                        $distributors=DB::table('registers')->select('registers.reg_id','registers.register_name','logs.email','logs.login_status','logs.login_type')
->join('logs','registers.reg_id','=','logs.reg_id')
->where(['login_type'=>3])
->get();
                                        //$co_id=$i->co_id;
                                        $delivery=DB::table('deliverydetails')->where('order_id',$im->order_id)->first();


                            ?>
                                       
                            
    <div style="width:1400px;height:300px;margin-left:100px;margin-top:5px;border-style:ridge;" align="center">

            <div style="width:180px;height:auto;margin-top:60px;float:left;"> 
                <img src="../../../storage/upload/<?php echo $product->cover_image;?>" style="width:150px;height:150px;">
            </div>
            <div style="width:600px;height:auto;float:left;display: inline;margin-top:60px;">
                <table style="width:500px;height:auto;" align="left">
                        <tr>
                            <td style="margin-left: 30px;font-family: Georgia;font-size:25px;">{{$product->product_name}}</td>
                            
                        </tr>
                        <tr>
                            <td style="margin-left: 30px;font-family: Georgia;font-size:15px;">{{$product->product_description}}</td>
                        </tr>
                        
                </table>
            </div>
            <div style="width:100px;height:auto;float:left;display: inline;margin-top:80px;">
                        <input type="text" id="product_color" style=" width:50px;height:50px;border-radius:25px;background-color:#{{$im->product_color}}">
            </div>
            <div style="width:150px;height:auto;float:left;display: inline;margin-top:80px;">
            
                {{$delivery->address}}

            </div>
            <div style="width:50px;height:auto;float:left;display: inline;margin-top:80px;">
            </div>
            <div style="width:100px;height:auto;float:left;display: inline;margin-top:50px;">

                        <table style="width:100px;">
                            
                            <?php

                                if($im->checked=='paid_by_card')
                                {

                                
                            ?>
                            <tr>
                                <td><img src="../../../admin/images/paid-cash.jpg" style="width:150px;height:150px;border-radius:150px;"></td>
                            </tr>

                            <?php
                                }
                                else if($im->checked=='paid_by_cash')
                                {
                            ?>
                            <tr>
                                <td><a href="{{route('recieve_money', ['rtd_id' => $im->rtd_id])}}"><button style="width:150px;height:80px;background-color:red;color:white">PAY</button></a></td>
                            </tr>
                            <?php
                                }
                            ?>
                        </table>
            </div>
            <div style="width:50px;height:auto;float:left;display: inline;margin-top:80px;">
            </div>
            <!--  -->
            <div style="width:50px;height:auto;float:left;display: inline;margin-top:80px;">
            </div>
            <div style="width:100px;height:auto;float:left;margin-top:100px;">
                <a href="{{route('delivered_designer', ['rtd_id' => $im->rtd_id])}}"><button style="width:100px;height:80px;color:white;background-color:green;">Product Delivered</button></a>
            </div>
            
    </div>
            
        <?php

}
}
?>
   
   <script>
            var msg = '{{Session::get('alert')}}';
            var exist = '{{Session::has('alert')}}';
            if(exist){
            alert(msg);
             }
        </script>  
</div> 
        </div>
        <!-- ****** Top Catagory Area End ****** -->
<br><br>
            		
            <hr/>

        <!-- ****** Footer Area End ****** -->
    </div>
    <!-- /.wrapper end -->

    <!-- jQuery (Necessary for All JavaScript Plugins) -->
    <script src="../../../distributor/js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="../../../distributor/js/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="../../../distributor/js/bootstrap.min.js"></script>
    <!-- Plugins js -->
    <script src="../../../distributor/js/plugins.js"></script>
    <!-- Active js -->
    <script src="../../../distributor/js/active.js"></script>
    <script>
// Get the elements with class="column"
var elements = document.getElementsByClassName("column");

// Declare a loop variable
var i;

// Full-width images
function one() {
    for (i = 0; i < elements.length; i++) {
        elements[i].style.msFlex = "100%";  // IE10
        elements[i].style.flex = "100%";
    }
}

// Two images side by side
function two() {
    for (i = 0; i < elements.length; i++) {
        elements[i].style.msFlex = "50%";  // IE10
        elements[i].style.flex = "50%";
    }
}

// Four images side by side
function four() {
    for (i = 0; i < elements.length; i++) {
        elements[i].style.msFlex = "25%";  // IE10
        elements[i].style.flex = "25%";
    }
}

// Add active class to the current button (highlight it)
var header = document.getElementById("myHeader");
var btns = header.getElementsByClassName("btn");
for (var i = 0; i < btns.length; i++) {
  btns[i].addEventListener("click", function() {
    var current = document.getElementsByClassName("active");
    current[0].className = current[0].className.replace(" active", "");
    this.className += " active";
  });
}
</script>
   

</body>

</html>