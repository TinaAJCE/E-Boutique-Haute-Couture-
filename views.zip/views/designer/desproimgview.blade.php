
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title  -->
    <!-- image slideshow -->
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">


    <!-- Favicon  -->
    <link rel="icon" href="../../../customer/img/core-img/favicon.ico">

    <!-- Core Style CSS -->
    <link rel="stylesheet" href="../../../designer/css/core-style.css">
    <link rel="stylesheet" href="../../../designer/style.css">

    <!-- Responsive CSS -->
    <link href="../../../designer/css/responsive.css" rel="stylesheet">
	<style>
        <style>
        .mySlides {display:none;}

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    font-family: Arial, Helvetica, sans-serif;
}
h1{
    font-family:arizonia;
}

.header {
    text-align: center;
    padding: 32px;
}

.row {
    display: -ms-flexbox; /* IE 10 */
    display: flex;
    -ms-flex-wrap: wrap; /* IE 10 */
    flex-wrap: wrap;
    padding: 0 4px;
}

/* Create two equal columns that sits next to each other */
.column {
    -ms-flex: 50%; /* IE 10 */
    flex: 50%;
    padding: 0 4px;
}

.column img {
    margin-top: 8px;
    vertical-align: middle;
}

/* Style the buttons */
.btn {
    border: none;
    outline: none;
    padding: 10px 16px;
    background-color: #f1f1f1;
    cursor: pointer;
    font-size: 18px;
}

.btn:hover {
    background-color: #ddd;
}

.btn.active {
    background-color: #666;
    color: white;
}
	</style>
</head>

<body>
<?php

                                                       
$reg=Session::get('email');
$register=DB::table('logs')->where('email',$reg)->first();
$reg_id=$register->reg_id;

?>
    <div class="catagories-side-menu">
        <!-- Close Icon -->
        <div id="sideMenuClose">
            <i class="ti-close"></i>
        </div>
        <!--  Side Nav  -->
        <div class="nav-side-menu">
            <div class="menu-list">
                <h6>Categories</h6>
                <ul id="menu-content" class="menu-content collapse out">
                    <!-- Single Item -->
                    <li data-toggle="collapse" data-target="#women" class="collapsed active">
                        <a href="#">Designer<span class="arrow"></span></a>
                        <ul class="sub-menu collapse" id="women">
                        <li><a href="/upload_designs">Upload My Designs</a></li>
                            <li><a href="{{route('admin_request', ['reg_id' => $reg_id])}}">Admin Requests</a></li>
                            <li><a href="{{route('customer_request', ['reg_id' => $reg_id])}}">Customer Requests</a></li>
                            <li><a href="{{route('completed_request', ['reg_id' => $reg_id])}}">Completed Requests</a></li>
                            <li><a href="{{route('my_products', ['reg_id' => $reg_id])}}">My Products</a></li>
                           
                           
                        </ul>
                    </li>
                    <!-- Single Item -->
                    
                    <!-- Single Item -->
                    <li data-toggle="collapse" data-target="#profile" class="collapsed">
                        <a href="#">Profile<span class="arrow"></span></a>
                        <ul class="sub-menu collapse" id="profile">
                        <li><a href="{{route('my_profile', ['reg_id' => $reg_id])}}">My Profile</a></li>
                        <li><a href="{{route('change_password', ['reg_id' => $reg_id])}}">Change Password</a></li>
                            
                        </ul>
                    </li>
                    
                 </ul>
            </div>
        </div>
    </div>

    <div id="wrapper">

        <!-- ****** Header Area Start ****** -->
        <header class="header_area">
            <!-- Top Header Area Start -->
            <div class="top_header_area">
                <div class="container h-100">
                    <div class="row h-100 align-items-center justify-content-end">

                        <div class="col-12 col-lg-7">
                            <div class="top_single_area d-flex align-items-center">
                                <!-- Logo Area -->
                                <div class="top_logo">
                                    <a href="#"><h1>Haute Couture</h1></a>
                                </div>
                                <!-- Cart & Menu Area -->
                                <div class="header-cart-menu d-flex align-items-center ml-auto">
                                    <!-- Cart Area -->
                                    <div class="cart">
                                        <!--<a href="#" id="header-cart-btn" target="_blank"><span class="cart_quantity">2</span> <i class="ti-bag"></i> Your Bag $20</a>
                                       
                                         Cart List Area Start-->
                                        <ul class="cart-list">
                                            <li>
                                                <a href="#" class="image"><img src="../../../designer/img/custo/product-img/product-10.jpg" class="cart-thumb" alt=""></a>
                                                <div class="cart-item-desc">
                                                    <h6><a href="#">Women's Fashion</a></h6>
                                                    <p>1x - <span class="price">$10</span></p>
                                                </div>
                                                <span class="dropdown-product-remove"><i class="icon-cross"></i></span>
                                            </li>
                                            <li>
                                                <a href="#" class="image"><img src="../../../designer/img/custo/product-img/product-11.jpg" class="cart-thumb" alt=""></a>
                                                <div class="cart-item-desc">
                                                    <h6><a href="#">Women's Fashion</a></h6>
                                                    <p>1x - <span class="price">$10</span></p>
                                                </div>
                                                <span class="dropdown-product-remove"><i class="icon-cross"></i></span>
                                            </li>
                                            <li class="total">
                                                <span class="pull-right">Total: $20.00</span>
                                                <a href="cart.html" class="btn btn-sm btn-cart">Cart</a>
                                                <a href="checkout-1.html" class="btn btn-sm btn-checkout">Checkout</a>
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="header-right-side-menu ml-15">
                                        <a href="#" id="sideMenuBtn"><i class="ti-menu" aria-hidden="true"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>

            <!-- Top Header Area End -->
            <div class="main_header_area">
                <div class="container h-100">
                    <div class="row h-100">
                        <div class="col-12 d-md-flex justify-content-between">
                            <!-- Header Social Area -->
                            <!--<div class="header-social-area">
                                <a href="#"><span class="karl-level">Share</span> <i class="fa fa-pinterest" aria-hidden="true"></i></a>
                                <a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                                <a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                                <a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
                            </div>-->
                            <!-- Menu Area -->
                            <div class="main-menu-area">
                                <nav class="navbar navbar-expand-lg align-items-start">

                                    <!--<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#karl-navbar" aria-controls="karl-navbar" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"><i class="ti-menu"></i></span></button>

                                    <div class="collapse navbar-collapse align-items-start collapse" id="karl-navbar">
                                        <ul class="navbar-nav animated" id="nav">
                                            <li class="nav-item active"><a class="nav-link" href="index.html">Home</a></li>
                                            <li class="nav-item dropdown">
                                                <a class="nav-link dropdown-toggle" href="#" id="karlDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Pages</a>
                                                <div class="dropdown-menu" aria-labelledby="karlDropdown">
                                                    <a class="dropdown-item" href="index.html">Home</a>
                                                    <a class="dropdown-item" href="shop.html">Shop</a>
                                                    <a class="dropdown-item" href="product-details.html">Product Details</a>
                                                    <a class="dropdown-item" href="cart.html">Cart</a>
                                                    <a class="dropdown-item" href="checkout.html">Checkout</a>
                                                </div>
                                            </li>
                                            <li class="nav-item"><a class="nav-link" href="#">Dresses</a></li>
                                            <li class="nav-item"><a class="nav-link" href="#"><span class="karl-level">hot</span> Shoes</a></li>
                                            <li class="nav-item"><a class="nav-link" href="#">Contact</a></li>
                                        </ul>
                                    </div>-->
                                    <div>
                            	<ul class="navbar-nav animated" id="nav">
                                <li class="nav-item dropdown">
                                				
                                                
                                     <a class="nav-link dropdown-toggle" href="#" id="karlDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><img src="../../../designer/images/user.png" style="width:45px; height:45px;position:absolute;"/><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{{Session::get('email')}}{{csrf_field()}}</a>
                                                <div class="dropdown-menu" aria-labelledby="karlDropdown">
                                                    <a class="dropdown-item" href="{{route('my_profile', ['reg_id' => $reg_id])}}"><img src="../../../designer/images/user.png" style="width:20px; height:20px;"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Profile</a>

                                                    <a class="dropdown-item" href="/logout"><img src="../../../designer/images/login-icon.jpg" style="width:20px; height:20px;"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Logout</a>
                                                    <!--<a class="dropdown-item" href="product-details.html">Product Details</a>
                                                    <a class="dropdown-item" href="cart.html">Cart</a>
                                                    <a class="dropdown-item" href="checkout.html">Checkout</a>-->
                                                </div>
                                 </li>
                                
                                 <li><br>
                                 	
                                 </li> 
                                               
                                  <li>
                                                                      
                                    </li>          
                                </ul>
                            </div>

                                </nav>
                            </div>
                            
                            <!-- Help Line -->
                            
                            <div class="help-line">
                                <a href="tel:+346573556778"><i class="ti-headphone-alt"></i> +91-9207064521</a>

                            </div>
                            
                        </div>
                                            </div>
                </div>
            </div>
        </header>
        <!-- ****** Header Area End ****** -->

        <!-- ****** Top Discount Area Start ****** -->
        <section class="top-discount-area d-md-flex align-items-center">
            <!-- Single Discount Area -->
            <div class="single-discount-area">
                <h5><a href="{{route('deshome', ['reg_id' => $reg_id])}}">HOME</a></h5>
                
            </div>
            <!-- Single Discount Area -->
            <div class="single-discount-area">
                <h5><a href="{{route('completed_request', ['reg_id' => $reg_id])}}">Completed Requests</a></h5>
            </div>
            <!-- Single Discount Area -->
            <div class="single-discount-area">
                <h5><a href="{{route('my_products', ['reg_id' => $reg_id])}}">My Designs</a></h5>
            </div>
        </section>
       <div>

        <?php
            $sess=Session::get('product_id');
        ?>
      


      <?php
                $sql =  DB::table('products')->where('product_id', $sess)->first();

                $sql1=DB::table('products_images')->where('product_id',$sess)->get();
   
        ?>        
 		<div class="container" style="width:50%;position:relative;left:-300px;">
                      <table>
                          <tr>
                              <td>
                                  <?php
                                     if(count($sql1)!=0)
                                     {
                                        foreach($sql1 as $img)
                                        {
                                            // $img = $img->file_name;
                                              //echo $obj;
                                         
                                  ?>
                                  <table style="top:10px;">

                                      
                                                  <tr>
                                                          <td>
                                                              <div class="thumbnail" style="width:100px;margin-top:10px;">
                                                              
                                                              <img src="../../../storage/upload/<?php echo $img->file_name; ?>" onclick="myFunction(this)"  style="width:150px;height:150px;" draggable="false" /> 
                                                              </div>
                                                          </td>
                                                      </tr>
                                          <?php
                                              }
                                            }
                                          ?>
                                    
                                          
                                              <tr>
                                                  <td>
                                                      <div class="thumbnail" style="width:100px;margin-top:10px;">
                                                          <img src="../../../storage/upload/<?php echo $sql->cover_image;?>" id="imge" onclick="myFunction(this)"  style="width:150px;height:150px;" draggable="false" />
                                                      </div>
                                                  </td>
                                              </tr>
                             
                                  </table>
                              </td>
                              <td>
                              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                       
                              </td>
                                  
                      
                          
                            <td>
                                <div>
                                    <table>
                                        <tr>
                                          
                                            <td>
                                                <div class="w3-container" style="width:450px;">
                                                    <div class="tiles">
                                                        <div class="tile" data-scale="2.4" id="main">
                                                            <div class="enlarge_pane_contain">
                                                                <div class="enlarge_pane">
                                                                    <div class="enlarge inline-demo">
                                                                        <div class="enlarge_contain"  name="main"  >
                                                                           
                                                                            <img src="../../../storage/upload/<?php echo $sql->cover_image;?>" name="expandedImg" id="test-imgs" class="preview-image img" style="width:600px;height:750px;" >
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                          
                                                          
                                                    </div>
                                                      
                                                </div>
                      
                                            </td>
                                              
                                        </tr>
                                         
                                    </table>
                                </div>
                            </td>
                            <script>
                               
                                function myFunction(imgs) 
                                {
                                    
                                    var expandImg = document.getElementById("test-imgs");                                    
                                    var hovImg = document.getElementById("hov-img");
                                    
                                    //alert(hovImg.href);
                                    //var imgText = document.getElementById("imgtext");
                                    expandImg.src = imgs.src;
                                    hovImg.src=imgs.src;
                                    expandImg.parentElement.style.display = "block";
                                }
                            </script>
                                                        
                              <td>
                              <?php


        $p_id=$sql->product_id;
        $p_name=$sql->product_name;
        $p_price=$sql->product_price;
        $p_color=$sql->product_color;
        $p_stock=$sql->product_stock;
        $p_desc=$sql->product_description;
        $p_image=$sql->cover_image;
        $p_status=$sql->product_status;
        $p_catid=$sql->category_id;
        $bsid=$sql->bs_id;
        $fabid=$sql->fab_id;
        $hid=$sql->h_id;
        $lsizeid=$sql->letter_size_id;
        $lid=$sql->l_id;
        $nid=$sql->n_id;

        $cat=DB::table('products_categories')->where('category_id',$p_catid)->first();

        $chest=DB::table('bust_sizes')->where('bs_id',$bsid)->first();

        $fabric=DB::table('fabrics')->where('fab_id',$fabid)->first();
        $fabfeature=DB::table('fabric_features')->where('fab_id',$fabid)->get();

        $hip=DB::table('hip_sizes')->where('h_id',$hid)->first();




?>

                           



















  
                             
                                
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                       
                              </td>
                                        
                            <td>
                                <div style="width:900px;">
                                    
                                    <h2><font face = "Bedrock" size = "6"><?php echo $p_name;?></font></h2>
                                    <hr/>
                                    <table>
                                          <tr>
                                                <th>price</th>
                                                <td><img src="../../../admin/images/black-rupee-money.jpg" style="width:20px;height:20px;border-radius:10px;"><?php echo $p_price;?></td>
                                          </tr>
                                          <tr>
                                                <th>Size Chart</th>
                                                <td><a href="../../../admin/images/size_chart.png"><img src="../../../admin/images/size_chart.png" style="width:450px;height:150px;"></a></td>
                                          </tr>
                                          <tr>
                                                
                                          <td colspan="2"><font color="#FF0000">Hurry..!!&nbsp; Only &nbsp;<?php echo $p_stock;?>&nbsp; left</font></td>
                                                
                                          </tr>
                                         
                                          <tr>
                                                <th>Category</th>
                                                <td><?php echo $cat->category_name;?></td>
                                                
                                          </tr>
                                          <tr>

                                                <th>Fabric Used</th>
                                                <td><?php echo $fabric->fab_name;?></td><br>

                                          </tr>
                                          <tr>
                                          <th></th>
                                          <td><img src="../../../storage/upload/<?php echo $fabric->fab_image;?>" class="preview-image img" id="test-img" onMouseOver="zoom(this)" style="width:100px;height:100px;border-radius:12px;"/></td>
                                        </tr>

                                          <tr>
                                                <th>Fabric Features</th>
                                                
                                                <td>
                                                <?php
                                                foreach($fabfeature as $ff)
                                                {
                                               ?><li>
                                                <?php echo $ff->features;?></li>
                                                <?php
                                                }
                                                ?>
                                                </td>
                                          </tr>
                                          
                                          <tr>
                                                <th>About Product</th>
                                                <td><?php echo $p_desc;?></td>
                                                
                                          </tr>
                                    </table>
                                </div>
                                
                                <br><br><br>
<a href="{{route('my_products', ['reg_id' => $reg_id])}}"><button style="background-color:ash;width:180px;height:80px;border-radius:12px;"><=Back To Products</button></a>











                                   
        	<div class="clearfix"> </div>
		</div>
		
				
                                                
       
        
            		
            <hr/>

        <!-- ****** Footer Area End ****** -->
    </div>
    <!-- /.wrapper end -->

    <!-- jQuery (Necessary for All JavaScript Plugins) -->
    <script src="../../../designer/js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="../../../designer/js/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="../../../designer/js/bootstrap.min.js"></script>
    <!-- Plugins js -->
    <script src="../../../designer/js/plugins.js"></script>
    <!-- Active js -->
    <script src="../../../designer/js/active.js"></script>
    <script>
// Get the elements with class="column"
var elements = document.getElementsByClassName("column");

// Declare a loop variable
var i;

// Full-width images
function one() {
    for (i = 0; i < elements.length; i++) {
        elements[i].style.msFlex = "100%";  // IE10
        elements[i].style.flex = "100%";
    }
}

// Two images side by side
function two() {
    for (i = 0; i < elements.length; i++) {
        elements[i].style.msFlex = "50%";  // IE10
        elements[i].style.flex = "50%";
    }
}

// Four images side by side
function four() {
    for (i = 0; i < elements.length; i++) {
        elements[i].style.msFlex = "25%";  // IE10
        elements[i].style.flex = "25%";
    }
}

// Add active class to the current button (highlight it)
var header = document.getElementById("myHeader");
var btns = header.getElementsByClassName("btn");
for (var i = 0; i < btns.length; i++) {
  btns[i].addEventListener("click", function() {
    var current = document.getElementsByClassName("active");
    current[0].className = current[0].className.replace(" active", "");
    this.className += " active";
  });
}
</script>
   

</body>

</html>