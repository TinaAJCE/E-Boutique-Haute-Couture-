<head>
	
	<!-- Meta tag Keywords -->
   
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<!--<meta name="keywords" content="Wedding Ceremony web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design"
	/>-->
	<script type="application/x-javascript">
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<!--// Meta tag Keywords -->
	<!-- css files -->
	<link rel="stylesheet" href="css/bootstrap.css" type="text/css" media="all">
	<!-- Bootstrap-Core-CSS -->
	<link rel="stylesheet" href="css/font-awesome.css" type="text/css" media="all">
	<!-- Font-Awesome-Icons-CSS -->
	<link rel="stylesheet" href="css/lightbox.css" type="text/css" media="all">
	<link href="css/easy-responsive-tabs.css" rel="stylesheet" type="text/css" media="all" />
	<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
	<!-- Style-CSS -->
	<!-- //css files -->
	<!-- web fonts -->
	<link href="//fonts.googleapis.com/css?family=Arizonia&amp;subset=latin-ext" rel="stylesheet">
	<link href="//fonts.googleapis.com/css?family=Droid+Sans:400,700" rel="stylesheet">
	<!-- //web fonts -->
</head>

<div class="w3l-main" id="home">
		<!--navigation-->
		<div class="header-w3">
			<div class="header-top-agile">
				<div class="social-icons-agileits">
					<ul>
						<!--<li><span class="glyphicon glyphicon-envelope" aria-hidden="true"></span> <a href="mailto:info@example.com">info@example.com</a></li>
						<li><span class="glyphicon glyphicon-earphone" aria-hidden="true"></span> +141 587 426 825</li>-->
					</ul>
				</div>
				<div class="social">
					<!--<ul>
						<li><a href="#" class="link facebook" target="_parent"><span class="fa fa-facebook-square"></span></a></li>
						<li><a href="#" class="link twitter" target="_parent"><span class="fa fa-twitter"></span></a></li>
						<li><a href="#" class="link google-plus" target="_parent"><span class="fa fa-google-plus-square"></span></a></li>
					</ul>-->
				</div>
				<div class="clearfix"></div>
			</div>
			<div class="header-bottom-agile">
				<div class=" navigation">
					<nav class="navbar navbar-default cl-effect-16" id="cl-effect-16">
						<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
						
												
						<a href="" class="nav navbar-nav" style="font-family:Baskerville, 'Palatino Linotype', Palatino, 'Century Schoolbook L', 'Times New Roman', serif; font-size:25px;">Haute Couture</a>
                        
                        
						<div id="navbar" class="navbar-collapse navbar-right collapse hover-effect">
                        
							<ul class="nav navbar-nav">
                            
								<li class="active"><a href="/home" data-hover="Home">Home</a></li>
								<li><a href="#about" data-hover="About Us" class="scroll">About Us</a></li>
								<!--<li><a href="#events" data-hover="Events" class="scroll">Events</a></li>-->
								<li><a href="#gallery" data-hover="Gallery" class="scroll">Gallery</a></li>
								<li><a href="/login1" data-hover="Login">Login</a></li>
								<!--<li><a href="#contact" data-hover="Contact Us" class="scroll">Contact Us</a></li>-->
							</ul>
						</div>
					</nav>
				</div>
				<div class="w3ls_search">
					<div class="cd-main-header">
						<ul class="cd-header-buttons">
							<!--<li><a class="cd-search-trigger" href="#cd-search"> <span></span></a></li>-->
						</ul>
						<!-- cd-header-buttons -->
					</div>
					<div id="cd-search" class="cd-search">
						<form action="#" method="post">
							<input name="Search" type="search" placeholder="Search..." required>
						</form>
					</div>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
                @yield('content');