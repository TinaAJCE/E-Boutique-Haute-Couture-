<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <!--Image Zoom -->
    <!-- <link rel="stylesheet" href="../../../customer/Touch-Friendly-Image-Zoom-jQuery-Enlarge/src/enlarge.css">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="../../../customer/Touch-Friendly-Image-Zoom-jQuery-Enlarge/src/enlarge.js"></script>
    <script src="../../../customer/Touch-Friendly-Image-Zoom-jQuery-Enlarge/src/enlarge.init.js"></script> -->

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.5/css/select2.css" />
    
    <!-- TESIZING THE TRIALING IMAGE -->
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <style>
  /* #resizable { width: 150px; height: 150px; padding: 0.5em; } */
  /* #resizable h3 { text-align: center; margin: 0; } */
  .ui-resizable-helper { border: 1px dotted gray; }
  </style>
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script>
  $( function() {
    $( "#ball").resizable({
      animate: true
    });
  } );
  </script>
    <!--  -->
    <!-- Title  -->
    <title></title>

    <!-- Favicon  -->
    <link rel="icon" href="../../../customer/img/core-img/favicon.ico">

    <!-- Core Style CSS -->
    <link rel="stylesheet" href="../../../customer/css/core-style.css">
    <link rel="stylesheet" href="../../../customer/style.css">

    <!-- Responsive CSS -->
    <link href="../../../customer/css/responsive.css" rel="stylesheet">
    <!--Multiple values upload -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
    <!-- <script src="//ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script> -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <style>
        h1
        {
            font-family:arizonia;
        }
        </style>
        <script
    src="component/payalord/xZoom/dist/xzoom.min.js"></script>
	
		<style>

form{
  width:700px;
  height:auto;
  border:2px solid green;
  background: #ffffff;
  display:none;

}
#form1
{
  width:700px;
  height:auto;
  border:2px solid #fc0c4c;
  background: #ffffff;
  display:none;

}

b{
  color:#000000;
}

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    font-family: Arial, Helvetica, sans-serif;
}

.header {
    text-align: center;
    padding: 32px;
}

.row {
    display: -ms-flexbox; /* IE 10 */
    display: flex;
    -ms-flex-wrap: wrap; /* IE 10 */
    flex-wrap: wrap;
    padding: 0 4px;
}

/* Create two equal columns that sits next to each other */
.column {
    -ms-flex: 50%; /* IE 10 */
    flex: 50%;
    padding: 0 4px;
}

.column img {
    margin-top: 8px;
    vertical-align: middle;
}

/* Style the buttons */
.btn {
    border: none;
    outline: none;
    padding: 10px 16px;
    background-color: #f1f1f1;
    cursor: pointer;
    font-size: 18px;
}

.btn:hover {
    background-color: #ddd;
}

.btn.active {
    background-color: #666;
    color: white;
}
.thumbnail
		{
			
			float:left;
			margin:10px;
			padding:10px;
			box-sizing:border-box;
			
			
		}
		button {
    width:300px;
	height:65px;
    padding: 15px;
    margin: 5px 0 22px 0;
    display: inline-block;
    border: none;
    
	border-radius: 12px;
}
.tooltip {
    position: relative;
    display: inline-block;
    border-bottom: 1px dotted black;
}

.tooltip .tooltiptext {
    visibility: hidden;
    width: 120px;
    background-color: black;
    color: #fff;
    text-align: center;
    border-radius: 6px;
    padding: 5px 0;

    /* Position the tooltip */
    position: absolute;
    z-index: 1;
}

.tooltip:hover .tooltiptext {
    visibility: visible;
}
input[type=text],input[type=textarea],input[type=password],input[type=number],input[type=email],input[type=date],textarea,select,button {
            width: 600px;
            padding: 15px;
            margin: 5px 0 22px 0;
            display: inline-block;
            border: none;
            background:#f2f2f2;
            border-radius: 12px;
           
            }
            .trial
            {
                display:none;
            }
/* wishlist css
input[type="checkbox"] {
    content: url('../../../admin/images/wishlist.png');
    display: block;
    width: 200px;
    height: 200px;
}
input[type="checkbox"]:checked {
     content: url('../../../admin/images/wishlist_fill.png'); 
}
.native-hidden {
    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
}*/


/* small dummy image */
.profile-pic {
    max-width: 200px;
    max-height: 200px;
    display: block;
}

.file-upload {
    display: none;
}
.circle {
    border-radius: 90px !important;
    overflow: hidden;
    width: 128px;
    height: 128px;
    /* border: 8px solid rgba(255, 255, 255, 0.7); */
    position: absolute;
    top: 50px;
    align:center;
    margin-left:268px;
    top: 45px;
}
img {
    max-width: 100%;
    height: auto;
}
.p-image {
  position: absolute;
  top: 140px;
  margin-left:390px;
  color: #666666;
  transition: all .3s cubic-bezier(.175, .885, .32, 1.275);
}
.p-image:hover {
  transition: all .3s cubic-bezier(.175, .885, .32, 1.275);
}
.upload-button {
  font-size: 1.2em;
}

.upload-button:hover {
  transition: all .3s cubic-bezier(.175, .885, .32, 1.275);
  color: #999;
}

/* medium size dummy */

.profile-pic-medium {
    max-width: 200px;
    max-height: 200px;
    display: block;
}

.file-upload2 {
    display: none;
}
.circle2 {
    border-radius: 90px !important;
    overflow: hidden;
    width: 128px;
    height: 128px;
    /* border: 8px solid rgba(255, 255, 255, 0.7); */
    position: absolute;
    top: 50px;
    align:center;
    margin-left:150px;
}
img {
    max-width: 100%;
    height: auto;
}
.p-image2 {
  position: absolute;
  top: 155px;
  margin-left:272px;
  color: #666666;
  transition: all .3s cubic-bezier(.175, .885, .32, 1.275);
}
.p-image2:hover {
  transition: all .3s cubic-bezier(.175, .885, .32, 1.275);
}
.upload-button2 {
  font-size: 1.2em;
}

.upload-button2:hover {
  transition: all .3s cubic-bezier(.175, .885, .32, 1.275);
  color: #999;
}

/* large dummy image */

.profile-pic3 {
    max-width: 200px;
    max-height: 200px;
    display: block;
}

.file-upload3 {
    display: none;
}
.circle3 {
    border-radius: 90px !important;
    overflow: hidden;
    width: 135px;
    height: 135px;
    /* border: 8px solid rgba(255, 255, 255, 0.7); */
    position: absolute;
    top: 50px;
    align:center;
    margin-left:245px;
}
img {
    max-width: 100%;
    height: auto;
}
.p-image3 {
  position: absolute;
  top: 155px;
  margin-left:360px;
  color: #666666;
  transition: all .3s cubic-bezier(.175, .885, .32, 1.275);
}
.p-image3:hover {
  transition: all .3s cubic-bezier(.175, .885, .32, 1.275);
}
.upload-button3 {
  font-size: 1.2em;
}

.upload-button3:hover {
  transition: all .3s cubic-bezier(.175, .885, .32, 1.275);
  color: #999;
}

	</style>


</head>

<body>

<div class="catagories-side-menu">
        <!-- Close Icon -->
        <div id="sideMenuClose">
            <i class="ti-close"></i>
        </div>
        <?php
                                        use App\Logs;
                                        $sess=session()->get('reg_id');
                                        //dd($sess);
                                        $spro=session()->get('product_id');
                
                                        $a=Logs::where('reg_id',$sess)->first();
                                        
                                            $log_id=$a->log_id;
                                            $reg_id=$a->reg_id;
                                            $email=$a->email;
                                        $user = DB::table('registers')->where('reg_id', $reg_id)->first();
                                        $name = DB::table('registers')->where('reg_id', $reg_id)->pluck('register_name');
                                       
                                    ?>
        <!--  Side Nav  -->
        <div class="nav-side-menu">
            <div class="menu-list">
            <h6>Categories</h6>
                <ul id="menu-content" class="menu-content collapse out">
                    <!-- Single Item -->
                    <li data-toggle="collapse" data-target="#women" class="collapsed active">
                        <a href="#">Woman wear <span class="arrow"></span></a>
                        <ul class="sub-menu collapse" id="women">
                            <li><a href="{{route('custproview', ['reg_id' => $reg_id])}}">All</a></li>
                            
                            <li><a href="/design_product">Designer Products</a></li>
                            <li><a href="{{route('prefered', ['reg_id' => $reg_id])}}">Wishlist</a></li>
                            <li><a href="{{route('cart_view', ['reg_id' => $reg_id])}}">Cart</a></li>
                        </ul>
                    </li>
                    <!-- Single Item -->
                    <li data-toggle="collapse" data-target="#orders" class="collapsed">
                        <a href="#">Orders <span class="arrow"></span></a>
                        <ul class="sub-menu collapse" id="orders">
                            <li><a href="{{route('order_status', ['reg_id' => $reg_id])}}">Order Status</a></li>
                            <li><a href="{{route('rtd', ['reg_id' => $reg_id])}}">Request To Designer</a></li>
                            <!-- <li><a href="">Replacement Requests</a></li>
                            <li><a href="">Return Requests</a></li> -->
                        </ul>
                    </li>
                    <!-- Single Item -->
                    <li data-toggle="collapse" data-target="#profile" class="collapsed">
                        <a href="#">Profile<span class="arrow"></span></a>
                        <ul class="sub-menu collapse" id="profile">
                            <li><a href="{{route('view_profile', ['reg_id' => $reg_id])}}">My Profile</a></li>
                            <li><a href="{{route('customer_change_password', ['reg_id' => $reg_id])}}">Change Password</a></li>
                        </ul>
                    </li>
                    
                 </ul>
            </div>
        </div>
    </div>
    
    <div id="wrapper">

        <!-- ****** Header Area Start ****** -->
        <header class="header_area">
            <!-- Top Header Area Start -->
            <div class="top_header_area">
                <div class="container h-100">
                    <div class="row h-100 align-items-center justify-content-end">

                        <div class="col-12 col-lg-7">
                            <div class="top_single_area d-flex align-items-center">
                                <!-- Logo Area -->
                                <div class="top_logo">
                                    <h1>Haute Couture</h1>
                                </div>
                                <!-- Cart & Menu Area -->
                                
                                <div class="header-cart-menu d-flex align-items-center ml-auto">
                                    <!-- Cart Area -->
                                    <div class="cart">
                                        
                                        <ul class="cart-list">
                                            <li>
                                                <a href="#" class="image"><img src="../../../customer/img/product-img/product-10.jpg" class="cart-thumb" alt=""></a>
                                                <div class="cart-item-desc">
                                                    <h6><a href="#">Women's Fashion</a></h6>
                                                    <p>1x - <span class="price">$10</span></p>
                                                </div>
                                                <span class="dropdown-product-remove"><i class="icon-cross"></i></span>
                                            </li>
                                            <li>
                                                <a href="#" class="image"><img src="../../../customer/img/product-img/product-11.jpg" class="cart-thumb" alt=""></a>
                                                <div class="cart-item-desc">
                                                    <h6><a href="#">Women's Fashion</a></h6>
                                                    <p>1x - <span class="price">$10</span></p>
                                                </div>
                                                <span class="dropdown-product-remove"><i class="icon-cross"></i></span>
                                            </li>
                                            <li class="total">
                                                <span class="pull-right">Total: $20.00</span>
                                                <a href="cart.html" class="btn btn-sm btn-cart">Cart</a>
                                                <a href="checkout-1.html" class="btn btn-sm btn-checkout">Checkout</a>
                                            </li>
                                        </ul>
                                    </div>
                                    
                                    <div class="header-right-side-menu ml-15">
                                        <a href="#" id="sideMenuBtn"><i class="ti-menu" aria-hidden="true"></i></a>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>

            <!-- Top Header Area End -->
            <div class="main_header_area">
                <div class="container h-100">
                    <div class="row h-100">
                        <div class="col-12 d-md-flex justify-content-between">
                        <div class="help-line">
                                <a href=""><i class="ti-headphone-alt"></i> +91-9207064521</a>

                            </div>
                            <div class="main-menu-area">
                                <nav class="navbar navbar-expand-lg align-items-start">

                                  
                                    <div>
                            	<ul class="navbar-nav animated" id="nav">
                                <li class="nav-item dropdown">
                                    		
                                     <a class="nav-link dropdown-toggle" href="#" id="karlDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="color:black;text-decoration:none;"><img src="../../../customer/images/user.png" style="width:45px; height:45px;"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{{Session::get('email')}}{{csrf_field()}}</a>
                                                <div class="dropdown-menu" aria-labelledby="karlDropdown">
                                                    <a class="dropdown-item" href="{{route('view_profile', ['reg_id' => $reg_id])}}"><i class="fa fa-user-circle fa-2x" aria-hidden="true"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Profile</a>

                                                    <a class="dropdown-item" href="{{route('prefered', ['reg_id' => $reg_id])}}"><i class="fa fa-heart-o fa-2x" aria-hidden="true"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Wishlist</a>
                                                    <a class="dropdown-item" href="{{route('cart_view', ['reg_id' => $reg_id])}}"><i class="fa fa-shopping-cart fa-2x" aria-hidden="true"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Cart</a>
                                                    <a class="dropdown-item" href="/logout"><i class="fa fa-sign-out fa-2x" aria-hidden="true"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Logout</a>

                                                    <!-- <a class="dropdown-item" href="checkout.html">Checkout</a> -->
                                                </div>
                                 </li>
                                
                                 <li><br>
                                 	
                                    
                                 </li> 
                                   <li></li>
                                   <li></li>            
                                  <li>
                                  <div>
                                        <?php
                                              $system=DB::table('carts')->where('reg_id',$reg_id)->where('status',1)->where('checked',0)->get();

                                              //$system=DB::table('products','wishlists')->select('product_id','product_name','product_price','product_color','product_description','cover_image')->where('products.product_id=wishlists.product_id','wishlists.reg_id',$reg_id)->get();
                                              // dd($system);
                                              // $systems= DB::table('logs')->select('id','email','login_status','login_type','reg_id')->where('login_type',2)->get();
                                              $count=$system->count();
                                              
                                        ?>      
                                        <a href="{{route('cart_view', ['reg_id' => $reg_id])}}">
                
									
                                        <img src="../../../customer/images/shopping-cart-icon_1245837.jpg" style="position:relative;width:50px;height:50px;border-radius:25px;">
										</a>	
									</div>
                                    
                                  </li>          
                                </ul>
                            </div>

                                </nav>
                            </div>
                            
                            <!-- Help Line -->
                            
                            
                            
                            
                            </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- ****** Header Area End ****** -->

        <!-- ****** Top Discount Area Start ****** -->
        <section class="top-discount-area d-md-flex align-items-center">
            <!-- Single Discount Area -->
            <div class="single-discount-area">
                <h5><a href="{{route('custhome', ['reg_id' => $reg_id])}}">HOME</a></h5>
                
            </div>
            <!-- Single Discount Area -->
            <div class="single-discount-area">
            <h5><a href="/design_product">DESIGNER PRODUCTS</a></h5>
            </div>
            <!-- Single Discount Area -->
            <div class="single-discount-area">
                <h5><a href="{{route('custproview', ['reg_id' => $reg_id])}}">CLOTHING</a></h5>
            </div>
        </section>
        <?php
                use App\Products;
                
                use App\ProductsCategory;
                use aPP\ProductsImages;
                
                //$sql = DB::select('SELECT * FROM products')->where('product_id',$sess);
               // $count=DB::select('SELECT * FROM products')->count();
                //$count = $sql->count();

                $sql =  DB::table('products');
                $sql->where('product_id', $spro);

                // Conditionally add another where
                //if($type) $query->where('type', 1);

                // Conditionally add another where
                //if($lang) $query->where('lang', 'EN');

                $rows = $sql->get();
                $count=$sql->count();
                
                $sql1=DB::table('products_images');
                $sql1->where('product_id',$spro);

                $imgrow=$sql1->get();
                $imgcount=$sql1->count();
                          

            
                          
        ?>        
        
 @if ($message = Session::get('success'))
<div class="alert alert-success alert-block">
	<button type="button" class="close" data-dismiss="alert">×</button>	
        <strong>{{ $message }}</strong>
</div>
@endif


@if ($message = Session::get('error'))
<div class="alert alert-danger alert-block">
	<button type="button" class="close" data-dismiss="alert">×</button>	
        <strong>{{ $message }}</strong>
</div>
@endif


@if ($message = Session::get('warning'))
<div class="alert alert-warning alert-block">
	<button type="button" class="close" data-dismiss="alert">×</button>	
	<strong>{{ $message }}</strong>
</div>
@endif


@if ($message = Session::get('info'))
<div class="alert alert-info alert-block">
	<button type="button" class="close" data-dismiss="alert">×</button>	
	<strong>{{ $message }}</strong>
</div>
@endif


@if ($errors->any())
<div class="alert alert-danger">
	<button type="button" class="close" data-dismiss="alert">×</button>	
	Please check the form below for errors
</div>
@endif
    
  					<div class="container" style="width:50%;position:relative;left:-300px;">
                      <table>
                          <tr>
                              <td>
                                  <?php
                                     if($imgcount!=0)
                                     {
                                        foreach($imgrow as $img)
                                        {
                                            // $img = $img->file_name;
                                              //echo $obj;
                                         
                                  ?>
                                  <table style="top:10px;">

                                      
                                                  <tr>
                                                          <td>
                                                              <div class="thumbnail" style="width:100px;">
                                                              
                                                              <img src="../../../storage/upload/<?php echo $img->file_name; ?>" onclick="myFunction(this)"  style="width:150px;height:150px;" draggable="false" /> 
                                                              </div>
                                                          </td>
                                                      </tr>
                                          <?php
                                              }
                                            }
                                          ?>
                                    <?php
                                    if($count!=0)
                                    
                                    {      
                                          foreach($rows as $object)
                                          {
                                             
                                             // $pic=$object->product_image;
                                              
                                  ?>
                                              <tr>
                                                  <td>
                                                      <div class="thumbnail" style="width:100px;">
                                                          <img src="../../../storage/upload/<?php echo $object->cover_image;?>" id="imge" onclick="myFunction(this)"  style="width:150px;height:150px;" draggable="false" />
                                                      </div>
                                                  </td>
                                              </tr>
                              <?php
                                          }
                                          ?>
                                  </table>
                              </td>
                              <td>
                              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                       
                              </td>
                                  
                      
                          
                            <td>
                                <div>
                                    <table>
                                        <tr>
                                          
                                            <td>
                                                <div class="w3-container" style="width:450px;" >
                                                    <div class="tiles" >
                                                        <div class="tile" data-scale="2.4" id="main">
                                                            <div class="enlarge_pane_contain">
                                                                <div class="enlarge_pane">
                                                                    <div class="enlarge inline-demo">
                                                                        <div class="enlarge_contain"  name="main">
                                                                           
                                                                            <img src="../../../storage/upload/<?php echo $object->cover_image;?>" style="width:600px;height:750px;" id="ball">
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                          
                                                          
                                                    </div>
                                                      
                                                </div>
                      
                                            </td>
                                              
                                        </tr>
                                          <?php
                                          }
                                          ?>
                                    </table>
                                </div>
                            </td>
                            <script>
                               
                                function myFunction(imgs) 
                                {
                                    
                                    var expandImg = document.getElementById("ball");                                    
                                    var hovImg = document.getElementById("hov-img");
                                    
                                    //alert(hovImg.href);
                                    //var imgText = document.getElementById("imgtext");
                                    expandImg.src = imgs.src;
                                    hovImg.src=imgs.src;
                                    expandImg.parentElement.style.display = "block";
                                }
                            </script>
                                                        
                              <td>
                              <?php

if($count!=0)
{
    foreach($rows as $a)
    {
        $p_id=$a->product_id;
        $p_name=$a->product_name;
        $p_price=$a->product_price;
        $p_color=$a->product_color;
        $p_stock=$a->product_stock;
        $p_desc=$a->product_description;
        $p_image=$a->cover_image;
        $p_status=$a->product_status;
        $p_catid=$a->category_id;
        $bsid=$a->bs_id;
        $fabid=$a->fab_id;
        $hid=$a->h_id;
        $lsizeid=$a->letter_size_id;
        $lid=$a->l_id;
        $nid=$a->n_id;

        $cat=DB::table('products_categories')->where('category_id',$p_catid)->first();

        $chest=DB::table('bust_sizes')->where('bs_id',$bsid)->first();

        $fabric=DB::table('fabrics')->where('fab_id',$fabid)->first();
        $fabfeature=DB::table('fabric_features')->where('fab_id',$fabid)->get();

        $hip=DB::table('hip_sizes')->where('h_id',$hid)->first();




?>

                           



















  
                             <!-- <a href="{{route('wishlist')}}"><img src="../../../admin/images/wishlist.png" id="imageOne" style="width:40px;height:40px;border-radius:20px;top:100%;" align="left"/></a>-->
                             
                             
                                <div style="height:750px;" id="wishdiv" onclick="submitform()">

                                    <?php
                                        $img=DB::table('wishlists')->where('product_id',$p_id)->get();

                                        $imgCount=$img->count();
                                        if($imgCount==0)
                                        {
                                    ?>
                                        <i class="fa fa-heart-o fa-3x" aria-hidden="true" id="myImage" name="myImage" align="right"></i>
                                    <!-- <img src="../../../admin/images/wishlist.png" id="myImage" name="myImage" style="width:40px;height:40px;top:100%;" align="left"/> -->
                                    <?php
                                        }
                                        else
                                        {
                                    ?>
                                    <!-- <i class="fa fa-heart-o fa-3x" style="background-color:#fc0c4c;" aria-hidden="true" id="myImage" name="myImage" align="right"></i> -->

                                    <img src="../../../admin/images/wish.png" id="myImage" name="myImage" style="width:40px;height:40px;top:100%;" align="left"/>

                                    <?php
                                        }
                                    ?>
                                
                                    <form method="post" action="{{route('wishlist')}}" name="wishlist" id="wishlist">
                                        <input type="hidden" name="_token" value="{{csrf_token()}}">
                                        @csrf

                                        
                                        <input type="hidden" id="reg_id" name="reg_id" value="<?php  echo $reg_id;?>">
                                        <input type="hidden" id="product_id" name="product_id" value="<?php echo $p_id;?>"> 
                                        <input type="hidden" id="wishlist" name="wishlist" value="../../../admin/images/wishlist.png">
                                        <button class="btn btn-primary"></button>
                                        
                                    </form>
                                </div>
                                <script>
                                function submitform()
                                {
                                document.getElementById("wishlist").submit();
                                //alert("your form submitted");
                                }
                            </script>
                                
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                       
                              </td>
                           
                            <td>
                                <div style="width:900px;height:50px;">
                                    
                                    <table>
                                          <tr>
                                                <th>Choose Your Size</th>
                                                
                                                <td>
                                                    <script src="../../../admin/js/jquery-1.12.4.min.js"></script>
                                                    <script type="text/javascript">
                                                        $(document).ready(function(){
                                                            $("select").change(function(){
                                                                $(this).find("option:selected").each(function(){
                                                                    var optionValue = $(this).attr("value");
                                                                    if(optionValue){
                                                                        $(".trial").not("." + optionValue).hide();
                                                                        $("." + optionValue).show();
                                                                    } else{
                                                                        $(".trial").hide();
                                                                    }
                                                                });
                                                            }).change();
                                                        });
                                                    </script>
                                                    <select id="trial" name="trial" required>
                                                        <option></option>
                                                        <option value="small">Small Size</option>
                                                        <option value="medium">Medium Size</option>
                                                        <option value="large">Large Size</option>
     
                                                    </select> 
                                                </td>
                                          </tr>
                                    </table>
                                </div>
                                <br><br><br>
                                <div>
                                    <table>
                                          <tr>
                                                






                                                <div class="small trial" id="trialsmall" name="trialsmall">




                                                <div class="row">
                                                    <div class="small-12 medium-2 large-2 columns">
                                                        <div class="circle">
                                                        <!-- User Profile Image -->
                                                        <img class="profile-pic" src="http://cdn.cutestpaw.com/wp-content/uploads/2012/07/l-Wittle-puppy-yawning.jpg">

                                                        <!-- Default Image -->
                                                        <!-- <i class="fa fa-user fa-5x"></i> -->
                                                        </div>
                                                        <div class="p-image">
                                                        <i class="fa fa-camera upload-button"></i>
                                                            <input class="file-upload" type="file" hidden accept="image/*"/>
                                                        </div>
                                                    </div>
                                                </div>

<script>
 $(document).ready(function() {

    
var readURL = function(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('.profile-pic').attr('src', e.target.result);
        }

        reader.readAsDataURL(input.files[0]);
    }
}


$(".file-upload").on('change', function(){
    readURL(this);
});

$(".upload-button").on('click', function() {
   $(".file-upload").click();
});
});



</script>

                                                    <img src="../../../admin/images/small.jpg" id="tsmall" name="tsmall"  id="gate" class="droppable">
                                                </div>
                                                <div class="medium trial" id="trialmedium" name="trialmedium">



                                                <div class="row">
                                                    <div class="small-12 medium-2 large-2 columns2">
                                                        <div class="circle2">
                                                        <!-- User Profile Image -->
                                                        <img class="profile-pic-medium" src="http://cdn.cutestpaw.com/wp-content/uploads/2012/07/l-Wittle-puppy-yawning.jpg">

                                                        <!-- Default Image -->
                                                        <!-- <i class="fa fa-user fa-5x"></i> -->
                                                        </div>
                                                        <div class="p-image2">
                                                        <i class="fa fa-camera upload-button2"></i>
                                                            <input class="file-upload2" type="file" hidden accept="image/*"/>
                                                        </div>
                                                    </div>
                                                </div>
                                                <script>
 $(document).ready(function() {

    
var readURL = function(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('.profile-pic-medium').attr('src', e.target.result);
        }

        reader.readAsDataURL(input.files[0]);
    }
}


$(".file-upload2").on('change', function(){
    readURL(this);
});

$(".upload-button2").on('click', function() {
   $(".file-upload2").click();
});
});



</script>

                                                    <img src="../../../admin/images/medium.jpg" id="tmedium" name="tmedium"  id="gate" class="droppable">
                                                </div>
                                                <div class="large trial" id="triallarge" name="triallarge">



                                                <div class="row">
                                                    <div class="small-12 medium-2 large-2 columns3">
                                                        <div class="circle3">
                                                        <!-- User Profile Image -->
                                                        <img class="profile-pic-large" src="http://cdn.cutestpaw.com/wp-content/uploads/2012/07/l-Wittle-puppy-yawning.jpg">

                                                        <!-- Default Image -->
                                                        <!-- <i class="fa fa-user fa-5x"></i> -->
                                                        </div>
                                                        <div class="p-image3">
                                                        <i class="fa fa-camera upload-button3"></i>
                                                            <input class="file-upload3" type="file" hidden accept="image/*"/>
                                                        </div>
                                                    </div>
                                                </div>
                                                <script>
 $(document).ready(function() {

    
var readURL = function(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('.profile-pic-large').attr('src', e.target.result);
        }

        reader.readAsDataURL(input.files[0]);
    }
}


$(".file-upload3").on('change', function(){
    readURL(this);
});

$(".upload-button3").on('click', function() {
   $(".file-upload3").click();
});
});



</script>
                                                    <img src="../../../admin/images/large.jpg" id="tlarge" name="tlarge"  id="gate" class="droppable">
                                                </div>
                                          </tr>

                                          <script>
    let currentDroppable = null;

    ball.onmousedown = function(event) {

      let shiftX = event.clientX - ball.getBoundingClientRect().left;
      let shiftY = event.clientY - ball.getBoundingClientRect().top;

      ball.style.position = 'absolute';
      ball.style.zIndex = 1000;
      document.body.append(ball);

      moveAt(event.pageX, event.pageY);

      function moveAt(pageX, pageY) {
        ball.style.left = pageX - shiftX + 'px';
        ball.style.top = pageY - shiftY + 'px';
      }

      function onMouseMove(event) {
        moveAt(event.pageX, event.pageY);

        ball.hidden = true;
        let elemBelow = document.elementFromPoint(event.clientX, event.clientY);
        ball.hidden = false;

        if (!elemBelow) return;

        let droppableBelow = elemBelow.closest('.droppable');
        if (currentDroppable != droppableBelow) {
          if (currentDroppable) { // null when we were not over a droppable before this event
            leaveDroppable(currentDroppable);
          }
          currentDroppable = droppableBelow;
          if (currentDroppable) { // null if we're not coming over a droppable now
            // (maybe just left the droppable)
            enterDroppable(currentDroppable);
          }
        }
      }

      document.addEventListener('mousemove', onMouseMove);

      ball.onmouseup = function() {
        document.removeEventListener('mousemove', onMouseMove);
        ball.onmouseup = null;
      };

    };

    function enterDroppable(elem) {
      elem.style.background = 'pink';
    }

    function leaveDroppable(elem) {
      elem.style.background = '';
    }

    ball.ondragstart = function() {
      return false;
    };
  </script>
































<!-- 
                                               <script>                                             
                                                    $(document).ready(function() {
                                                    
                                                    $('#trial').on('change', function() {
                                                    if ( ['small'].indexOf( this.value ) = 'small' )
                                                    {
                                                        $("#trialimg").src = "../../../admin/images/large.png"
                                                    }
                                                    else 
                                                    {
                                                        // $("#image").hide();
                                                    }
                                                    })
                                                    .change();
                                                    });
                                             </script>



 -->








                                          <!-- <script>
                                                function trialOnce()
                                                {
                                                    var selected=document.getElementById("trial").value;
                                                    var changed=document.getElementById("trialimg");
                                                    
                                                    if(selected == small)
                                                    {
                                                        changed.src="../../../admin/images/small.jpg"
                                                    }
                                                    else if (selected == medium) 
                                                    {
                                                        changed.src="../../../admin/images/medium.jpg"

                                                    }
                                                    else{
                                                        changed.src="../../../admin/images/large.png"

                                                    }
                                                }
                                               
                                          </script> -->
                                    </table>
                                </div>
                                


                                  



                            </td>
                            <?php
    }
}
?>
                          </tr>
                          
                      </table>

                  </div>
                    
    
               













                </div>                    
        	<div class="clearfix"> </div>
		</div>
		
				
        <!-- ****** Top Discount Area End ****** -->

        <!-- ****** Welcome Slides Area Start ****** -->
        
        <!-- ****** Top Catagory Area End ****** -->
<br><br>
            		
            <hr/>

        <!-- ****** Footer Area Start ****** -->
        
        <!-- ****** Footer Area End ****** -->
    </div>
    <!-- /.wrapper end -->

    <!-- jQuery (Necessary for All JavaScript Plugins) -->
    <script src="../../../customer/js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="../../../customer/js/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="../../../customer/js/bootstrap.min.js"></script>
    <!-- Plugins js -->
    <script src="../../../customer/js/plugins.js"></script>
    <!-- Active js -->
    <script src="../../../customer/js/active.js"></script>
    <!-- <script>
// Get the elements with class="column"
var elements = document.getElementsByClassName("column");

// Declare a loop variable
var i;

// Full-width images
function one() {
    for (i = 0; i < elements.length; i++) {
        elements[i].style.msFlex = "100%";  // IE10
        elements[i].style.flex = "100%";
    }
}

// Two images side by side
function two() {
    for (i = 0; i < elements.length; i++) {
        elements[i].style.msFlex = "50%";  // IE10
        elements[i].style.flex = "50%";
    }
}

// Four images side by side
function four() {
    for (i = 0; i < elements.length; i++) {
        elements[i].style.msFlex = "25%";  // IE10
        elements[i].style.flex = "25%";
    }
}

// Add active class to the current button (highlight it)
var header = document.getElementById("myHeader");
var btns = header.getElementsByClassName("btn");
for (var i = 0; i < btns.length; i++) {
  btns[i].addEventListener("click", function() {
    var current = document.getElementsByClassName("active");
    current[0].className = current[0].className.replace(" active", "");
    this.className += " active";
  });
}


$(document).ready(function() {
  $('.template-article img').each(function() {
      var currentImage = $(this);
      currentImage.wrap("<a class='image-link' href='" + currentImage.attr("src") + "'</a>");
  });
  $('.image-link').magnificPopup({type:'image'});  
});
</script> -->
</body>

</html>