
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title  -->
    

    <!-- Favicon  -->
    <link rel="icon" href="../../../customer/img/core-img/favicon.ico">

    <!-- Core Style CSS -->
    <link rel="stylesheet" href="../../../customer/css/core-style.css">
    <link rel="stylesheet" href="../../../customer/style.css">

    <!-- Responsive CSS -->
    <link href="../../../customer/css/responsive.css" rel="stylesheet">
    <link rel="stylesheet"
    href="component/payalord/xZoom/dist/xzoom.css">
<script
    src="component/payalord/xZoom/dist/xzoom.min.js"></script>
	<style>
		<style>
* {
    box-sizing: border-box;
}

body {
    margin: 0;
    font-family: Arial, Helvetica, sans-serif;
}

.header {
    text-align: center;
    padding: 32px;
}

.row {
    display: -ms-flexbox; /* IE 10 */
    display: flex;
    -ms-flex-wrap: wrap; /* IE 10 */
    flex-wrap: wrap;
    padding: 0 4px;
}

/* Create two equal columns that sits next to each other */
.column {
    -ms-flex: 50%; /* IE 10 */
    flex: 50%;
    padding: 0 4px;
}

.column img {
    margin-top: 8px;
    vertical-align: middle;
}

/* Style the buttons */
.btn {
    border: none;
    outline: none;
    padding: 10px 16px;
    background-color: #f1f1f1;
    cursor: pointer;
    font-size: 18px;
}

.btn:hover {
    background-color: #ddd;
}

.btn.active {
    background-color: #666;
    color: white;
}
.thumbnail
		{
			
			float:left;
			margin:10px;
			padding:10px;
			box-sizing:border-box;
			
			
		}
		button {
    width:300px;
	height:65px;
    padding: 15px;
    margin: 5px 0 22px 0;
    display: inline-block;
    border: none;
    
	border-radius: 12px;
}
.tooltip {
    position: relative;
    display: inline-block;
    border-bottom: 1px dotted black;
}

.tooltip .tooltiptext {
    visibility: hidden;
    width: 120px;
    background-color: black;
    color: #fff;
    text-align: center;
    border-radius: 6px;
    padding: 5px 0;

    /* Position the tooltip */
    position: absolute;
    z-index: 1;
}

.tooltip:hover .tooltiptext {
    visibility: visible;
}
	</style>
</head>

<body>
    <div class="catagories-side-menu">
        <!-- Close Icon -->
        <div id="sideMenuClose">
            <i class="ti-close"></i>
        </div>
        <!--  Side Nav  -->
        <div class="nav-side-menu">
            <div class="menu-list">
            <h6>Categories</h6>
                <ul id="menu-content" class="menu-content collapse out">
                    <!-- Single Item -->
                    <li data-toggle="collapse" data-target="#women" class="collapsed active">
                        <a href="#">Woman wear <span class="arrow"></span></a>
                        <ul class="sub-menu collapse" id="women">
                            <li><a href="{{route('custproview', ['reg_id' => $reg_id])}}">All</a></li>
                            
                            <li><a href="/design_product">Designer Products</a></li>
                            <li><a href="{{route('prefered', ['reg_id' => $reg_id])}}">Wishlist</a></li>
                            <li><a href="{{route('cart_view', ['reg_id' => $reg_id])}}">Cart</a></li>
                        </ul>
                    </li>
                    <!-- Single Item -->
                    <li data-toggle="collapse" data-target="#orders" class="collapsed">
                        <a href="#">Orders <span class="arrow"></span></a>
                        <ul class="sub-menu collapse" id="orders">
                            <li><a href="{{route('order_status', ['reg_id' => $reg_id])}}">Order Status</a></li>
                            <li><a href="{{route('rtd', ['reg_id' => $reg_id])}}">Request To Designer</a></li>
                            <!-- <li><a href="">Replacement Requests</a></li>
                            <li><a href="">Return Requests</a></li> -->
                        </ul>
                    </li>
                    <!-- Single Item -->
                    <li data-toggle="collapse" data-target="#profile" class="collapsed">
                        <a href="#">Profile<span class="arrow"></span></a>
                        <ul class="sub-menu collapse" id="profile">
                            <li><a href="{{route('view_profile', ['reg_id' => $reg_id])}}">My Profile</a></li>
                            <li><a href="{{route('customer_change_password', ['reg_id' => $reg_id])}}">Change Password</a></li>
                        </ul>
                    </li>
                    
                 </ul>
            </div>
        </div>
    </div>

    <div id="wrapper">

        <!-- ****** Header Area Start ****** -->
        <header class="header_area">
            <!-- Top Header Area Start -->
            <div class="top_header_area">
                <div class="container h-100">
                    <div class="row h-100 align-items-center justify-content-end">

                        <div class="col-12 col-lg-7">
                            <div class="top_single_area d-flex align-items-center">
                                <!-- Logo Area -->
                                <div class="top_logo">
                                    <a href="#"><h1>Haute Couture</h1></a>
                                </div>
                                <!-- Cart & Menu Area -->
                                
                                <div class="header-cart-menu d-flex align-items-center ml-auto">
                                    <!-- Cart Area -->
                                    <div class="cart">
                                        <!--<a href="#" id="header-cart-btn" target="_blank"><span class="cart_quantity">2</span> <i class="ti-bag"></i> Your Bag $20</a>-->
                                       
                                        <!-- Cart List Area Start-->
                                        <ul class="cart-list">
                                            <li>
                                                <a href="#" class="image"><img src="../../../customer/img/product-img/product-10.jpg" class="cart-thumb" alt=""></a>
                                                <div class="cart-item-desc">
                                                    <h6><a href="#">Women's Fashion</a></h6>
                                                    <p>1x - <span class="price">$10</span></p>
                                                </div>
                                                <span class="dropdown-product-remove"><i class="icon-cross"></i></span>
                                            </li>
                                            <li>
                                                <a href="#" class="image"><img src="../../../customer/img/product-img/product-11.jpg" class="cart-thumb" alt=""></a>
                                                <div class="cart-item-desc">
                                                    <h6><a href="#">Women's Fashion</a></h6>
                                                    <p>1x - <span class="price">$10</span></p>
                                                </div>
                                                <span class="dropdown-product-remove"><i class="icon-cross"></i></span>
                                            </li>
                                            <li class="total">
                                                <span class="pull-right">Total: $20.00</span>
                                                <a href="cart.html" class="btn btn-sm btn-cart">Cart</a>
                                                <a href="checkout-1.html" class="btn btn-sm btn-checkout">Checkout</a>
                                            </li>
                                        </ul>
                                    </div>
                                    
                                    <div class="header-right-side-menu ml-15">
                                        <a href="#" id="sideMenuBtn"><i class="ti-menu" aria-hidden="true"></i></a>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>

            <!-- Top Header Area End -->
            <div class="main_header_area">
                <div class="container h-100">
                    <div class="row h-100">
                        <div class="col-12 d-md-flex justify-content-between">
                        <div class="help-line">
                                <a href=""><i class="ti-headphone-alt"></i> +91-9207064521</a>

                            </div>
                            <div class="main-menu-area">
                                <nav class="navbar navbar-expand-lg align-items-start">

                                  
                                    <div>
                            	<ul class="navbar-nav animated" id="nav">
                                <li class="nav-item dropdown">
                                    		
                                     <a class="nav-link dropdown-toggle" href="#" id="karlDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><img src="../../../customer/images/user.png" style="width:45px; height:45px;"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{{Session::get('email')}}{{csrf_field()}}</a>
                                                <div class="dropdown-menu" aria-labelledby="karlDropdown">
                                                    <a class="dropdown-item" href="{{route('view_profile', ['reg_id' => $reg_id])}}"><i class="fa fa-user-circle fa-2x" aria-hidden="true"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Profile</a>

                                                    <a class="dropdown-item" href="{{route('prefered', ['reg_id' => $reg_id])}}"><i class="fa fa-heart-o fa-2x" aria-hidden="true"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Wishlist</a>
                                                    <a class="dropdown-item" href="{{route('cart_view', ['reg_id' => $reg_id])}}"><i class="fa fa-shopping-cart fa-2x" aria-hidden="true"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Cart</a>
                                                    <a class="dropdown-item" href="/logout"><i class="fa fa-sign-out fa-2x" aria-hidden="true"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Logout</a>

                                                    <!-- <a class="dropdown-item" href="checkout.html">Checkout</a> -->
                                                </div>
                                 </li>
                                
                                 <li><br>
                                 	
                                    
                                 </li> 
                                   <li></li>
                                   <li></li>            
                                  <li>
                                  <div>
                                  <a href="{{route('cart_view', ['reg_id' => $reg_id])}}">
                
									
                                <img src="../../../customer/images/shopping-cart-icon_1245837.jpg" style="position:relative;width:50px;height:50px;border-radius:25px;">   </a>	
									</div>
                                   
                                    
                                  </li>          
                                </ul>
                            </div>

                                </nav>
                            </div>
                            
                            <!-- Help Line -->
                            
                            
                            
                            
                            </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- ****** Header Area End ****** -->
	 <!-- ****** Top Discount Area Start ****** -->
        <section class="top-discount-area d-md-flex align-items-center">
            <!-- Single Discount Area -->
            <div class="single-discount-area">
                <h5><a href="/log">HOME</a></h5>
                
            </div>
            <!-- Single Discount Area -->
            <div class="single-discount-area">
            <h5><a href="/design_product">DESIGNER PRODUCTS</a></h5>
            </div>
            <!-- Single Discount Area -->
            <div class="single-discount-area">
                <h5><a href="/clothing">CLOTHING</a></h5>
            </div>
        </section> 
        
           <div id="page-wrapper" >
                <div id="page-inner" style="color:#000;">
                    <div class="row">
                     
                    </div>
                
                </div>
              
              
            </div>
                       
                    
                  
             
                  
             
         </div>        
                   
    </div>
     
    <!-- jQuery (Necessary for All JavaScript Plugins) -->
    <script src="../../../customer/js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="../../../customer/js/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="../../../customer/js/bootstrap.min.js"></script>
    <!-- Plugins js -->
    <script src="../../../customer/js/plugins.js"></script>
    <!-- Active js -->
    <script src="../../../customer/js/active.js"></script>
	<script>
	function bigImg(x) {
    x.style.height = "650px";
    x.style.width = "550px";
}

function normalImg(x) {
    x.style.height = "600px";
    x.style.width = "500px";
}
function myFunction(imgs) {
    var expandImg = document.getElementById("expandedImg");
    var imgText = document.getElementById("imgtext");
    expandImg.src = imgs.src;
    imgText.innerHTML = imgs.alt;
    expandImg.parentElement.style.display = "block";
}



zoom();
    function zoom(){
        $(".preview-image img").xzoom({
              // top, left, right, bottom, inside, lens, fullscreen, #ID
              position: 'right',
              // inside, fullscreen
              mposition: 'inside',
              // In the HTML structure, this option gives an ability to output xzoom element, to the end of the document body or relative to the parent element of main source image.
              rootOutput: true,
              // x/y offset
              /*Xoffset: 20,
              Yoffset: -45,*/
              Xoffset: 0,
              Yoffset: 0,
              // Fade in effect, when zoom is opening.
              fadeIn: true,
              // Fade transition effect, when switching images by clicking on thumbnails.
              fadeTrans: true,
              // Fade out effect, when zoom is closing.
             fadeOut: false,
              // Smooth move effect of the big zoomed image in the zoom output window.
              // The higher value will make movement smoother.
                  smoothZoomMove: 3,
              // Smooth move effect of lens.
              smoothLensMove: 1,
              // Smooth move effect of scale.
              smoothScale: 6,
              // From -1 to 1, that means -100% till 100% scale
              defaultScale: 0,
              // Scale on mouse scroll.
              scroll: true,
              // Tint color. Color must be provided in format like "#color".
              tint: false,
              // Tint opacity from 0 to 1.
              tintOpacity: 0.5,
              // Lens color. Color must be provided in format like "#color".
              lens: false,
              // Lens opacity from 0 to 1.
              lensOpacity: 0.5,
              // 'box', 'circle'
              lensShape: 'box',
              // Custom width of zoom window in pixels.
              //zoomWidth: '598',
              zoomWidth: '400',
              // Custom height of zoom window in pixels.
            zoomHeight: '300',
              // Class name for source "div" container.
              sourceClass: 'xzoom-sources',
              // Class name for loading "div" container that appear before zoom opens, when image is still loading.
              loadingClass: 'xzoom-loading',
              // Class name for lens "div".
              lensClass: 'xzoom-lens',
              // Class name for zoom window(div).
             zoomClass: 'xzoom-preview',
              // Class name that will be added to active thumbnail image.
              activeClass: 'xactive',
              // With this option you can make a selection action on thumbnail by hover mouse point on it.
              hover: false,
              // Adaptive functionality.
              adaptive: false,
              // When selected position "inside" and this option is set to true, the lens direction of moving will be reversed.
              lensReverse: false,
              // Same as lensReverse, but only available when adaptive is true.
              adaptiveReverse: false,
             //  Output title/caption of the image, in the zoom output window.
              title: false,
              // Class name for caption "div" container.
              titleClass: 'xzoom-caption',
              // Zoom image output as background
              bg: false
            });
    }
</script>
     
</body>

</html>