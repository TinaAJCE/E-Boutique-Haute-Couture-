<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <!--Image Zoom -->
    <!-- <link rel="stylesheet" href="../../../customer/Touch-Friendly-Image-Zoom-jQuery-Enlarge/src/enlarge.css">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="../../../customer/Touch-Friendly-Image-Zoom-jQuery-Enlarge/src/enlarge.js"></script>
    <script src="../../../customer/Touch-Friendly-Image-Zoom-jQuery-Enlarge/src/enlarge.init.js"></script> -->

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.5/css/select2.css" />
    <!-- Title  -->
    <title></title>

    <!-- Favicon  -->
    <link rel="icon" href="../../../customer/img/core-img/favicon.ico">

    <!-- Core Style CSS -->
    <link rel="stylesheet" href="../../../customer/css/core-style.css">
    <link rel="stylesheet" href="../../../customer/style.css">

    <!-- Responsive CSS -->
    <link href="../../../customer/css/responsive.css" rel="stylesheet">
    <!--Multiple values upload -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
    <!-- <script src="//ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script> -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <style>
        h1
        {
            font-family:arizonia;
        }
        </style>
        <script
    src="component/payalord/xZoom/dist/xzoom.min.js"></script>
	
		<style>

form{
  width:700px;
  height:auto;
  border:2px solid green;
  background: #ffffff;
  display:none;

}
#form1
{
  width:700px;
  height:auto;
  border:2px solid #fc0c4c;
  background: #ffffff;
  display:none;

}

b{
  color:#000000;
}

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    font-family: Arial, Helvetica, sans-serif;
}

.header {
    text-align: center;
    padding: 32px;
}

.row {
    display: -ms-flexbox; /* IE 10 */
    display: flex;
    -ms-flex-wrap: wrap; /* IE 10 */
    flex-wrap: wrap;
    padding: 0 4px;
}

/* Create two equal columns that sits next to each other */
.column {
    -ms-flex: 50%; /* IE 10 */
    flex: 50%;
    padding: 0 4px;
}

.column img {
    margin-top: 8px;
    vertical-align: middle;
}

/* Style the buttons */
.btn {
    border: none;
    outline: none;
    padding: 10px 16px;
    background-color: #f1f1f1;
    cursor: pointer;
    font-size: 18px;
}

.btn:hover {
    background-color: #ddd;
}

.btn.active {
    background-color: #666;
    color: white;
}
.thumbnail
		{
			
			float:left;
			margin:10px;
			padding:10px;
			box-sizing:border-box;
			
			
		}
		button {
    width:300px;
	height:65px;
    padding: 15px;
    margin: 5px 0 22px 0;
    display: inline-block;
    border: none;
    
	border-radius: 12px;
}
.tooltip {
    position: relative;
    display: inline-block;
    border-bottom: 1px dotted black;
}

.tooltip .tooltiptext {
    visibility: hidden;
    width: 120px;
    background-color: black;
    color: #fff;
    text-align: center;
    border-radius: 6px;
    padding: 5px 0;

    /* Position the tooltip */
    position: absolute;
    z-index: 1;
}

.tooltip:hover .tooltiptext {
    visibility: visible;
}
input[type=text],input[type=textarea],input[type=password],input[type=number],input[type=email],input[type=date],textarea,select,button {
            width: 100%;
            padding: 15px;
            margin: 5px 0 22px 0;
            display: inline-block;
            border: none;
            background:#f2f2f2;
            border-radius: 12px;
           
            }
/* wishlist css
input[type="checkbox"] {
    content: url('../../../admin/images/wishlist.png');
    display: block;
    width: 200px;
    height: 200px;
}
input[type="checkbox"]:checked {
     content: url('../../../admin/images/wishlist_fill.png'); 
}
.native-hidden {
    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
}*/


	</style>


</head>

<body>

<div class="catagories-side-menu">
        <!-- Close Icon -->
        <div id="sideMenuClose">
            <i class="ti-close"></i>
        </div>
        <?php
                                        use App\Logs;
                                        $sess=session()->get('reg_id');
                                        //dd($sess);
                                        $spro=session()->get('product_id');
                
                                        $a=Logs::where('reg_id',$sess)->first();
                                        
                                            $log_id=$a->log_id;
                                            $reg_id=$a->reg_id;
                                            $email=$a->email;
                                        $user = DB::table('registers')->where('reg_id', $reg_id)->first();
                                        $name = DB::table('registers')->where('reg_id', $reg_id)->pluck('register_name');
                                       
                                    ?>
        <!--  Side Nav  -->
        <div class="nav-side-menu">
            <div class="menu-list">
            <h6>Categories</h6>
                <ul id="menu-content" class="menu-content collapse out">
                    <!-- Single Item -->
                    <li data-toggle="collapse" data-target="#women" class="collapsed active">
                        <a href="#">Woman wear <span class="arrow"></span></a>
                        <ul class="sub-menu collapse" id="women">
                            <li><a href="{{route('custproview', ['reg_id' => $reg_id])}}">All</a></li>
                            
                            <li><a href="/design_product">Designer Products</a></li>
                            <li><a href="{{route('prefered', ['reg_id' => $reg_id])}}">Wishlist</a></li>
                            <li><a href="{{route('cart_view', ['reg_id' => $reg_id])}}">Cart</a></li>
                        </ul>
                    </li>
                    <!-- Single Item -->
                    <li data-toggle="collapse" data-target="#orders" class="collapsed">
                        <a href="#">Orders <span class="arrow"></span></a>
                        <ul class="sub-menu collapse" id="orders">
                            <li><a href="{{route('order_status', ['reg_id' => $reg_id])}}">Order Status</a></li>
                            <li><a href="{{route('rtd', ['reg_id' => $reg_id])}}">Request To Designer</a></li>
                            <!-- <li><a href="">Replacement Requests</a></li>
                            <li><a href="">Return Requests</a></li> -->
                        </ul>
                    </li>
                    <!-- Single Item -->
                    <li data-toggle="collapse" data-target="#profile" class="collapsed">
                        <a href="#">Profile<span class="arrow"></span></a>
                        <ul class="sub-menu collapse" id="profile">
                            <li><a href="{{route('view_profile', ['reg_id' => $reg_id])}}">My Profile</a></li>
                            <li><a href="{{route('customer_change_password', ['reg_id' => $reg_id])}}">Change Password</a></li>
                        </ul>
                    </li>
                    
                 </ul>
            </div>
        </div>
    </div>
    
    <div id="wrapper">

        <!-- ****** Header Area Start ****** -->
        <header class="header_area">
            <!-- Top Header Area Start -->
            <div class="top_header_area">
                <div class="container h-100">
                    <div class="row h-100 align-items-center justify-content-end">

                        <div class="col-12 col-lg-7">
                            <div class="top_single_area d-flex align-items-center">
                                <!-- Logo Area -->
                                <div class="top_logo">
                                    <h1>Haute Couture</h1>
                                </div>
                                <!-- Cart & Menu Area -->
                                
                                <div class="header-cart-menu d-flex align-items-center ml-auto">
                                    <!-- Cart Area -->
                                    <div class="cart">
                                        
                                        <ul class="cart-list">
                                            <li>
                                                <a href="#" class="image"><img src="../../../customer/img/product-img/product-10.jpg" class="cart-thumb" alt=""></a>
                                                <div class="cart-item-desc">
                                                    <h6><a href="#">Women's Fashion</a></h6>
                                                    <p>1x - <span class="price">$10</span></p>
                                                </div>
                                                <span class="dropdown-product-remove"><i class="icon-cross"></i></span>
                                            </li>
                                            <li>
                                                <a href="#" class="image"><img src="../../../customer/img/product-img/product-11.jpg" class="cart-thumb" alt=""></a>
                                                <div class="cart-item-desc">
                                                    <h6><a href="#">Women's Fashion</a></h6>
                                                    <p>1x - <span class="price">$10</span></p>
                                                </div>
                                                <span class="dropdown-product-remove"><i class="icon-cross"></i></span>
                                            </li>
                                            <li class="total">
                                                <span class="pull-right">Total: $20.00</span>
                                                <a href="cart.html" class="btn btn-sm btn-cart">Cart</a>
                                                <a href="checkout-1.html" class="btn btn-sm btn-checkout">Checkout</a>
                                            </li>
                                        </ul>
                                    </div>
                                    
                                    <div class="header-right-side-menu ml-15">
                                        <a href="#" id="sideMenuBtn"><i class="ti-menu" aria-hidden="true"></i></a>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>

            <!-- Top Header Area End -->
            <div class="main_header_area">
                <div class="container h-100">
                    <div class="row h-100">
                        <div class="col-12 d-md-flex justify-content-between">
                        <div class="help-line">
                                <a href=""><i class="ti-headphone-alt"></i> +91-9207064521</a>

                            </div>
                            <div class="main-menu-area">
                                <nav class="navbar navbar-expand-lg align-items-start">

                                  
                                    <div>
                            	<ul class="navbar-nav animated" id="nav">
                                <li class="nav-item dropdown">
                                    		
                                     <a class="nav-link dropdown-toggle" href="#" id="karlDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="color:black;text-decoration:none;"><img src="../../../customer/images/user.png" style="width:45px; height:45px;"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{{Session::get('email')}}{{csrf_field()}}</a>
                                                <div class="dropdown-menu" aria-labelledby="karlDropdown">
                                                    <a class="dropdown-item" href="{{route('view_profile', ['reg_id' => $reg_id])}}"><i class="fa fa-user-circle fa-2x" aria-hidden="true"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Profile</a>

                                                    <a class="dropdown-item" href="{{route('prefered', ['reg_id' => $reg_id])}}"><i class="fa fa-heart-o fa-2x" aria-hidden="true"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Wishlist</a>
                                                    <a class="dropdown-item" href="{{route('cart_view', ['reg_id' => $reg_id])}}"><i class="fa fa-shopping-cart fa-2x" aria-hidden="true"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Cart</a>
                                                    <a class="dropdown-item" href="/logout"><i class="fa fa-sign-out fa-2x" aria-hidden="true"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Logout</a>

                                                    <!-- <a class="dropdown-item" href="checkout.html">Checkout</a> -->
                                                </div>
                                 </li>
                                
                                 <li><br>
                                 	
                                    
                                 </li> 
                                   <li></li>
                                   <li></li>            
                                  <li>
                                  <div>
                                        <?php
                                              $system=DB::table('carts')->where('reg_id',$reg_id)->where('status',1)->where('checked',0)->get();

                                              //$system=DB::table('products','wishlists')->select('product_id','product_name','product_price','product_color','product_description','cover_image')->where('products.product_id=wishlists.product_id','wishlists.reg_id',$reg_id)->get();
                                              // dd($system);
                                              // $systems= DB::table('logs')->select('id','email','login_status','login_type','reg_id')->where('login_type',2)->get();
                                              $count=$system->count();
                                              
                                        ?>      
                                        <a href="{{route('cart_view', ['reg_id' => $reg_id])}}">
                
									
                                        <img src="../../../customer/images/shopping-cart-icon_1245837.jpg" style="position:relative;width:50px;height:50px;border-radius:25px;">
										</a>	
									</div>
                                    
                                  </li>          
                                </ul>
                            </div>

                                </nav>
                            </div>
                            
                            <!-- Help Line -->
                            
                            
                            
                            
                            </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- ****** Header Area End ****** -->

        <!-- ****** Top Discount Area Start ****** -->
        <section class="top-discount-area d-md-flex align-items-center">
            <!-- Single Discount Area -->
            <div class="single-discount-area">
                <h5><a href="{{route('custhome', ['reg_id' => $reg_id])}}">HOME</a></h5>
                
            </div>
            <!-- Single Discount Area -->
            <div class="single-discount-area">
            <h5><a href="/design_product">DESIGNER PRODUCTS</a></h5>
            </div>
            <!-- Single Discount Area -->
            <div class="single-discount-area">
                <h5><a href="{{route('custproview', ['reg_id' => $reg_id])}}">CLOTHING</a></h5>
            </div>
        </section>
        <?php
                use App\Products;
                
                use App\ProductsCategory;
                use aPP\ProductsImages;
                
                //$sql = DB::select('SELECT * FROM products')->where('product_id',$sess);
               // $count=DB::select('SELECT * FROM products')->count();
                //$count = $sql->count();

                $sql =  DB::table('products');
                $sql->where('product_id', $spro);

                // Conditionally add another where
                //if($type) $query->where('type', 1);

                // Conditionally add another where
                //if($lang) $query->where('lang', 'EN');

                $rows = $sql->get();
                $count=$sql->count();
                
                $sql1=DB::table('products_images');
                $sql1->where('product_id',$spro);

                $imgrow=$sql1->get();
                $imgcount=$sql1->count();
                          

            
                          
        ?>        
        
 @if ($message = Session::get('success'))
<div class="alert alert-success alert-block">
	<button type="button" class="close" data-dismiss="alert">×</button>	
        <strong>{{ $message }}</strong>
</div>
@endif


@if ($message = Session::get('error'))
<div class="alert alert-danger alert-block">
	<button type="button" class="close" data-dismiss="alert">×</button>	
        <strong>{{ $message }}</strong>
</div>
@endif


@if ($message = Session::get('warning'))
<div class="alert alert-warning alert-block">
	<button type="button" class="close" data-dismiss="alert">×</button>	
	<strong>{{ $message }}</strong>
</div>
@endif


@if ($message = Session::get('info'))
<div class="alert alert-info alert-block">
	<button type="button" class="close" data-dismiss="alert">×</button>	
	<strong>{{ $message }}</strong>
</div>
@endif


@if ($errors->any())
<div class="alert alert-danger">
	<button type="button" class="close" data-dismiss="alert">×</button>	
	Please check the form below for errors
</div>
@endif
    
  					<div class="container" style="width:50%;position:relative;left:-300px;">
                      <table>
                          <tr>
                              <td>
                                  <?php
                                     if($imgcount!=0)
                                     {
                                        foreach($imgrow as $img)
                                        {
                                            // $img = $img->file_name;
                                              //echo $obj;
                                         
                                  ?>
                                  <table style="top:10px;">

                                      
                                                  <tr>
                                                          <td>
                                                              <div class="thumbnail" style="width:100px;">
                                                              
                                                              <img src="../../../storage/upload/<?php echo $img->file_name; ?>" onclick="myFunction(this)"  style="width:150px;height:150px;" draggable="false" /> 
                                                              </div>
                                                          </td>
                                                      </tr>
                                          <?php
                                              }
                                            }
                                          ?>
                                    <?php
                                    if($count!=0)
                                    
                                    {      
                                          foreach($rows as $object)
                                          {
                                             
                                             // $pic=$object->product_image;
                                              
                                  ?>
                                              <tr>
                                                  <td>
                                                      <div class="thumbnail" style="width:100px;">
                                                          <img src="../../../storage/upload/<?php echo $object->cover_image;?>" id="imge" onclick="myFunction(this)"  style="width:150px;height:150px;" draggable="false" />
                                                      </div>
                                                  </td>
                                              </tr>
                              <?php
                                          }
                                          ?>
                                  </table>
                              </td>
                              <td>
                              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                       
                              </td>
                                  
                      
                          
                            <td>
                                <div>
                                    <table>
                                        <tr>
                                          
                                            <td>
                                                <div class="w3-container" style="width:450px;">
                                                    <div class="tiles">
                                                        <div class="tile" data-scale="2.4" id="main">
                                                            <div class="enlarge_pane_contain">
                                                                <div class="enlarge_pane">
                                                                    <div class="enlarge inline-demo">
                                                                        <div class="enlarge_contain"  name="main"  >
                                                                           
                                                                            <img src="../../../storage/upload/<?php echo $object->cover_image;?>" name="expandedImg" id="test-imgs" class="preview-image img" style="width:600px;height:750px;" >
                                                                           <!-- <a href="../../../storage/upload/<?php echo $object->cover_image;?>" class='image-link'  title="Toggle Zoom" hidden ></a>-->
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                          
                                                          
                                                    </div>
                                                      
                                                </div>
                      
                                            </td>
                                              
                                        </tr>
                                          <?php
                                          }
                                          ?>
                                    </table>
                                </div>
                            </td>
                            <script>
                               
                                function myFunction(imgs) 
                                {
                                    
                                    var expandImg = document.getElementById("test-imgs");                                    
                                    var hovImg = document.getElementById("hov-img");
                                    
                                    //alert(hovImg.href);
                                    //var imgText = document.getElementById("imgtext");
                                    expandImg.src = imgs.src;
                                    hovImg.src=imgs.src;
                                    expandImg.parentElement.style.display = "block";
                                }
                            </script>
                                                        
                              <td>
                              <?php

if($count!=0)
{
    foreach($rows as $a)
    {
        $p_id=$a->product_id;
        $p_name=$a->product_name;
        $p_price=$a->product_price;
        $p_color=$a->product_color;
        $p_stock=$a->product_stock;
        $p_desc=$a->product_description;
        $p_image=$a->cover_image;
        $p_status=$a->product_status;
        $p_catid=$a->category_id;
        $bsid=$a->bs_id;
        $fabid=$a->fab_id;
        $hid=$a->h_id;
        $lsizeid=$a->letter_size_id;
        $lid=$a->l_id;
        $nid=$a->n_id;

        $cat=DB::table('products_categories')->where('category_id',$p_catid)->first();

        $chest=DB::table('bust_sizes')->where('bs_id',$bsid)->first();

        $fabric=DB::table('fabrics')->where('fab_id',$fabid)->first();
        $fabfeature=DB::table('fabric_features')->where('fab_id',$fabid)->get();

        $hip=DB::table('hip_sizes')->where('h_id',$hid)->first();




?>

                           



















  
                             <!-- <a href="{{route('wishlist')}}"><img src="../../../admin/images/wishlist.png" id="imageOne" style="width:40px;height:40px;border-radius:20px;top:100%;" align="left"/></a>-->
                             
                             
                                <div style="height:750px;" id="wishdiv" onclick="submitform()">

                                    <?php
                                        $img=DB::table('wishlists')->where('product_id',$p_id)->get();

                                        $imgCount=$img->count();
                                        if($imgCount==0)
                                        {
                                    ?>
                                        <i class="fa fa-heart-o fa-3x" aria-hidden="true" id="myImage" name="myImage" align="right"></i>
                                    <!-- <img src="../../../admin/images/wishlist.png" id="myImage" name="myImage" style="width:40px;height:40px;top:100%;" align="left"/> -->
                                    <?php
                                        }
                                        else
                                        {
                                    ?>
                                    <!-- <i class="fa fa-heart-o fa-3x" style="background-color:#fc0c4c;" aria-hidden="true" id="myImage" name="myImage" align="right"></i> -->

                                    <img src="../../../admin/images/wish.png" id="myImage" name="myImage" style="width:40px;height:40px;top:100%;" align="left"/>

                                    <?php
                                        }
                                    ?>
                                
                                    <form method="post" action="{{route('wishlist')}}" name="wishlist" id="wishlist">
                                        <input type="hidden" name="_token" value="{{csrf_token()}}">
                                        @csrf

                                        
                                        <input type="hidden" id="reg_id" name="reg_id" value="<?php  echo $reg_id;?>">
                                        <input type="hidden" id="product_id" name="product_id" value="<?php echo $p_id;?>"> 
                                        <input type="hidden" id="wishlist" name="wishlist" value="../../../admin/images/wishlist.png">
                                        <button class="btn btn-primary"></button>
                                        
                                    </form>
                                </div>
                                <script>
                                function submitform()
                                {
                                document.getElementById("wishlist").submit();
                                //alert("your form submitted");
                                }
                            </script>
                                
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                       
                              </td>
                        
                              

                            
                            
                            
                            <td>
                                <div style="width:900px;">
                                    
                                    <h2><font face = "Bedrock" size = "6"><?php echo $p_name;?></font></h2>
                                    <hr/>
                                    <table>
                                          <tr>
                                                <th>price</th>
                                                <td><img src="../../../admin/images/black-rupee-money.jpg" style="width:20px;height:20px;border-radius:10px;"><?php echo $p_price;?></td>
                                          </tr>
                                          <tr>
                                                <th>Size Chart</th>
                                                <td><a href="../../../admin/images/size_chart.png"><img src="../../../admin/images/size_chart.png" style="width:450px;height:150px;"></a></td>
                                          </tr>
                                          <tr>
                                                
                                          <td colspan="2"><font color="#FF0000">Hurry..!!&nbsp; Only &nbsp;<?php echo $p_stock;?>&nbsp; left</font></td>
                                                
                                          </tr>
                                         
                                          <tr>
                                                <th>Category</th>
                                                <td><?php echo $cat->category_name;?></td>
                                                
                                          </tr>
                                          <tr>

                                                <th>Fabric Used</th>
                                                <td><?php echo $fabric->fab_name;?></td><br>

                                          </tr>
                                          <tr>
                                          <th></th>
                                          <td><img src="../../../storage/upload/<?php echo $fabric->fab_image;?>" class="preview-image img" id="test-img" onMouseOver="zoom(this)" style="width:100px;height:100px;border-radius:12px;"/></td>
                                        </tr>

                                          <tr>
                                                <th>Fabric Features</th>
                                                
                                                <td>
                                                <?php
                                                foreach($fabfeature as $ff)
                                                {
                                               ?><li>
                                                <?php echo $ff->features;?></li>
                                                <?php
                                                }
                                                ?>
                                                </td>
                                          </tr>
                                          
                                          <tr>
                                                <th>About Product</th>
                                                <td><?php echo $p_desc;?></td>
                                                
                                          </tr>
                                    </table>
                                </div>
                                
                                <br><br><br>
                                <button id="formButton1" style="background-color:green;color:white;width:250px;height:70px;"><img src="../../../admin/images/cart.png" style="width:50px;height:50px;border-radius:25px;">&nbsp;&nbsp;&nbsp;ADD TO CART</button>
                                <button  id="formButton"  style="background-color:#fc0c4c;color:white;width:300px;height:70px;right:150px;"><img src="../../../admin/images/designer.png" style="width:50px;height:50px;border-radius:25px;">&nbsp;&nbsp;&nbsp;REQUEST DESIGNER</button>
                                <a href="{{route('trial', ['product_id' => $p_id])}}"><button id="try" style="background-color:#cc33ff;color:white;width:200px;height:70px;"><img src="../../../admin/images/unnamed.jpg" style="width:50px;height:50px;border-radius:25px;">&nbsp;&nbsp;&nbsp;TRY IT ONCE</button></a>

                                
                                    <br><br>
                                    <form method="post" action="/cart" id="form2"  enctype="multipart/form-data" name="form2" >
                                        <input type="hidden" name="_token" value="{{csrf_token()}}">
                                        @csrf

                                            <div class="container" style="width:80%">
                                                <br><br>
                                                
                                                <label for="price"><b>Unit Price</b></label>
                                                    <input type="number" placeholder="Enter Price" value="<?php echo $p_price;?>" name="product_price" id="product_price" autocomplete="off" min="1" readonly style="width:100%;">
                                                    <label id="derror_price" style="color: red;"></label>
                                                <br>
                                                <label for="qty"><b>Quantity</b></label>
                                                    <input type="number" placeholder="Enter Quantity" name="qty" id="qty" oninput="calculates()" onchange="check()" autocomplete="off" min="1" style="width:100%;" required>
                                                    <label id="derror_qty" style="color: red;"></label>
                                                <br>
                                                <label for="total"><b>Total Amount</b></label>
                                                    <input type="number"  name="result" id="result" style="width:100%;" readonly>
                                                    <label id="derror_qty" style="color: red;"></label>
                                                    <br>

                                                <label for="color"><b>Product Color</b></label>
                                                <input type="text"  name="product_color" id="product_color" class="jscolor {width:200, height:150, position:'right'}" style="width: 100%;padding: 15px; margin: 5px 0 22px 0; display: inline-block;border: none; background: #f1f1f1;border-radius: 12px;">
                                                <script src="../../../admin/js/jscolor.js"></script>
                                                <br>
                                                
                                                <script>

                                                    function calculates() {
                                                            var myBox1 = document.getElementById('product_price').value;	
                                                            var myBox2 = document.getElementById('qty').value;
                                                            var result = document.getElementById('result');	
                                                            var myResult = myBox1 * myBox2;
                                                            result.value = myResult;
                                                        
                                                            
                                                        }
                                                </script>
                                                 <script>

                                                    function check() {
                                                            var myBox2 = parseFloat(document.getElementById('qty').value);
                                                            var val = "<?php echo $p_stock;?>";
                                                            
                                                            if( myBox2 > val ){
                                                                alert("Sorry...Only  "+ val + "  items left");
                                                                document.getElementById('qty').value='';
                                                                return false;                                                        
                                                            }
                                                            else{
                                                                document.getElementById('qty').value=myBox2;   
                                                            }
                                                           
                                                        }
                                                </script>
                                                
                                                <input type="hidden" id="reg_id" name="reg_id" value="<?php echo $reg_id;?>">
                                                
                                                <input type="hidden" id="product_id" name="product_id" value="<?php echo $p_id;?>">
                                                <input type="hidden" id="product_stock" name="product_stock" value="<?php echo $p_stock;?>">

                                                <a><button type="submit" id="submit" style="background-color:green;color:white;width:100%;height:70px;"><img src="../../../admin/images/cart.png" style="width:50px;height:50px;border-radius:25px;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ADD TO CART</button></a>
                                                <!-- <a><button type="submit" id="submit" style="background-color:green;color:white;width:300px;height:70px;right:150px;"><img src="../../../admin/images/designer.png" style="width:50px;height:50px;border-radius:25px;">&nbsp;&nbsp;&nbsp;REQUEST DESIGNER</button> -->

                    
                                            </div>
                                    </form>




                                    <form method="post" action="/requestdesigner" id="form1"  enctype="multipart/form-data" name="form1" >
                                        <input type="hidden" name="_token" value="{{csrf_token()}}">
                                        @csrf

                                            <div class="container" style="width:80%">
                                                <br><br>

                                                <?php
                                                $des=DB::table('registers')->select('registers.reg_id','registers.register_name','logs.email','logs.login_status','logs.login_type')
->join('logs','registers.reg_id','=','logs.reg_id')
->where(['login_status' => 1,'login_type'=>2])
->get();
                                                ?>
                                                <label for="designer"><b>Available Designers</b></label>
                                                    <select id="designer" name="designer" required>
                                                        <option></option>
                                                        <?php
                                                            foreach($des as $object)
                                                            {
                                                                $dreg_id=$object->reg_id;
                                                                
                                                                $dregister_name=$object->register_name;
                                                                echo"<option value='$dreg_id'>$dregister_name</option>";
                                                            }
                                                                
                                                        ?>
                                                        <label id="derror_lname"></label>     
                                                    </select>
                                                    <br>

                                                <label for="color"><b>Product Color</b></label>
                                                <input type="text"  name="product_color" id="product_color" class="jscolor {width:200, height:150, position:'right'}" style="width: 100%;padding: 15px; margin: 5px 0 22px 0; display: inline-block;border: none; background: #f1f1f1;border-radius: 12px;">
                                                <script src="../../../admin/js/jscolor.js"></script>
                                                <br>
                                                <label for="price"><b>Unit Price</b></label>
                                                    <input type="number" placeholder="Enter Price" value="<?php echo $p_price;?>" name="product_price" id="product_prices" autocomplete="off" min="1" readonly style="width:100%;">
                                                    <label id="derror_price" style="color: red;"></label>
                                                <br>
                                                <label for="qty"><b>Quantity</b></label>
                                                    <input type="number" placeholder="Enter Quantity" name="qty" id="qtys" oninput="calculate()" autocomplete="off" min="1" style="width:100%;" required>
                                                    <label id="derror_qty" style="color: red;"></label>
                                                <br>
                                                <label for="total"><b>Total Amount</b></label>
                                                    <input type="number"  name="result" id="results" style="width:100%;" readonly>
                                                    <label id="derror_qty" style="color: red;"></label>
                                                <br>
                                                
                                                <script>

                                                    function calculate() {
                                                            var myBox1 = document.getElementById('product_prices').value;	
                                                            var myBox2 = document.getElementById('qtys').value;
                                                            var results = document.getElementById('results');	
                                                            var myResult = myBox1 * myBox2;
                                                            results.value = myResult;
                                                        
                                                            
                                                        }
                                                </script>
                  
                    
                                                <?php
                                                $syst= DB::table('letter_sizes')->select('letter_size_id','letter_size')->get();
                                                ?>
                                                <label for="letter_size"><b>Size</b></label>
                                                    <select id="size" name="size" required>
                                                        <option></option>
                                                        <?php
                                                            foreach($syst as $object)
                                                            {
                                                                $l_id=$object->letter_size_id;
                                                                $l_size=$object->letter_size;
                                                                echo"<option value='$l_id'>$l_size</option>";
                                                            }
                                                                
                                                        ?>
                                                        <label id="derror_lname"></label>     
                                                    </select>
                                                    <br>

                    
                                                    <?php
                                                    $sys= DB::table('bust_sizes')->select('bs_id','bust_size')->get();
                                                    ?>
                                                    <label for="bust_size"><b>Chest Measurement</b></label>
                                                        <select id="b_size" name="b_size" required>
                                                            <option></option>
                                                            <?php
                                                                foreach($sys as $object)
                                                                {
                                                                    $b_id=$object->bs_id;
                                                                    $b_size=$object->bust_size;
                                                                    echo"<option value='$b_id'>$b_size</option>";
                                                                }
                                                                    
                                                            ?>
                                                        <label id="derror_bname"></label>     
                                                        </select>
                                                        <br>

                                                        <?php
                                                        $sysm= DB::table('natural_waists')->select('n_id','natural_waist_size')->get();
                                                        ?>
                                                        <label for="na_size"><b>Natural Waist Size</b></label>
                                                            <select id="n_size" name="n_size" required>
                                                                <option></option>
                                                                <?php
                                                                    foreach($sysm as $object)
                                                                    {
                                                                        $n_id=$object->n_id;
                                                                        $n_size=$object->natural_waist_size;
                                                                        echo"<option value='$n_id'>$n_size</option>";
                                                                    }
                                                                        
                                                                ?>
                                                                <label id="derror_nname"></label>     
                                                            </select>
                                                            <br>

                                                            <?php
                                                            $sysmt= DB::table('hip_sizes')->select('h_id','hip_size')->get();
                                                            ?>
                                                            <label for="hip_size"><b>Hip Size</b></label>
                                                                <select id="h_size" name="h_size" required>
                                                                    <option></option>
                                                                    <?php
                                                                        foreach($sysmt as $object)
                                                                        {
                                                                            $h_id=$object->h_id;
                                                                            $h_size=$object->hip_size;
                                                                            echo"<option value='$h_id'>$h_size</option>";
                                                                        }
                                                                            
                                                                    ?>
                                                                    <label id="derror_hname"></label>     
                                                                </select>
                                                                <br>
                                                                <?php
                                                                $sysms= DB::table('low_waists')->select('l_id','low_waist_size')->get();
                                                                ?>
                                                                <label for="l_size"><b>Low Waist Size</b></label>
                                                                    <select id="l_size" name="l_size" required>
                                                                        <option></option>
                                                                        <?php
                                                                            foreach($sysms as $object)
                                                                            {
                                                                                $l_id=$object->l_id;
                                                                                $l_size=$object->low_waist_size;
                                                                                echo"<option value='$l_id'>$l_size</option>";
                                                                            }
                                                                                
                                                                        ?>
                                                                        <label id="derror_lname"></label>     
                                                                    </select>     
                                                                    <br>

                                                                    <?php
                                                                    $fabs= DB::table('fabrics')->select('fab_id','fab_name','fab_image')->get();
                                                                    ?>
                                                                    <label for="fabs"><b>Available Fabrics</b></label>
                                                                    <select id="fabs" name="fabs" style="background: #f1f1f1;" required>
                                                                            <option></option>
                                                                            <?php
                                                                                foreach($fabs as $object)
                                                                                {
                                                                                    $f_id=$object->fab_id;
                                                                                    $fname=$object->fab_name;
                                                                                    $image=$object->fab_image;
                                                                                    echo"<option value='$f_id' data-img_src='../../../storage/upload/$image'>$fname</option>";
                                                                                }
                                                                                    
                                                                            ?>
                                                                            <label id="derror_lname"></label>     
                                                                    </select>
                                                                <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script> -->
                                                                <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.5/js/select2.js"></script> -->
                                                                <script src="../../../customer/js/jquery.min.js"></script>
                                                                <script src="../../../customer/js/select2.js"></script>

                                                                
                                                                <script type="text/javascript">
                                                                    function custom_template(obj){
                                                                            var data = $(obj.element).data();
                                                                            var text = $(obj.element).text();
                                                                            if(data && data['img_src']){
                                                                                img_src = data['img_src'];
                                                                                template = $("<div><img src=\"" + img_src + "\" style=\"width:65px;height:65px;border-radius:32.5px;\"/>" + text + "</div>");
                                                                                return template;
                                                                            }
                                                                        }
                                                                        var options = {
                                                                            'templateSelection': custom_template,
                                                                            'templateResult': custom_template,
                                                                        }
                                                                        $('#fabs').select2(options);
                                                                        $('.select2-container--default .select2-selection--single').css({'height': '70px','width' : '520px','background': '#f2f2f2','border-radius':'12px'});

                                                                </script>
                                                                <br>
                                                                <label for="add_features"><b>If any additional features needed ...Add Here..</b></label>
                                                                <br>
                                                                <div class="table-responsive">  
                                                                    <table class="table table-bordered" id="dynamic_field">  
                                                                    <tr>  
                                                                        <td><input type="text" name="name[]" placeholder="Add new feature" class="form-control name_list" /></td>  
                                                                        <td><button type="button" name="add" id="add" style="background-color:#fc0c4c;" class="btn btn-success">Add More</button></td>  
                                                                    </tr>  
                                                                </table>  
                                                                <!--<input type="button" name="submit" id="submit" class="btn btn-info" value="Submit" />  -->
                                                            </div>
<script type="text/javascript">
    $(document).ready(function(){      
      var postURL = "<?php echo url('addmore'); ?>";
      var i=1;  


      $('#add').click(function(){  
           i++;  
           $('#dynamic_field').append('<tr id="row'+i+'" class="dynamic-added"><td><input type="text" name="name[]" placeholder="Add new features" class="form-control name_list" /></td><td><button type="button" name="remove" id="'+i+'" class="btn btn-danger btn_remove" style="background-color:red;">X</button></td></tr>');  
      });  


      $(document).on('click', '.btn_remove', function(){  
           var button_id = $(this).attr("id");   
           $('#row'+button_id+'').remove();  
      });  


      $.ajaxSetup({
          headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
      });


      $('#submit').click(function(){            
           $.ajax({  
                url:postURL,  
                method:"POST",  
                data:$('#add_name').serialize(),
                type:'json',
                success:function(data)  
                {
                    if(data.error){
                        printErrorMsg(data.error);
                    }else{
                        i=1;
                        $('.dynamic-added').remove();
                        $('#add_name')[0].reset();
                        $(".print-success-msg").find("ul").html('');
                        $(".print-success-msg").css('display','block');
                        $(".print-error-msg").css('display','none');
                        $(".print-success-msg").find("ul").append('<li>Record Inserted Successfully.</li>');
                    }
                }  
           });  
      });  


      function printErrorMsg (msg) {
         $(".print-error-msg").find("ul").html('');
         $(".print-error-msg").css('display','block');
         $(".print-success-msg").css('display','none');
         $.each( msg, function( key, value ) {
            $(".print-error-msg").find("ul").append('<li>'+value+'</li>');
         });
      }
    });  
</script>

                                                                
                                        <input type="hidden" id="reg_id" name="reg_id" value="<?php echo $reg_id;?>">
                                        <input type="hidden" id="product_id" name="product_id" value="<?php echo $p_id;?>">
                                        <input type="hidden" id="product_stock" name="product_stock" value="<?php echo $p_stock;?>">

                                        <!-- <a><button type="submit" id="submit" style="background-color:green;color:white;width:100%;height:70px;"><img src="../../../admin/images/cart.png" style="width:50px;height:50px;border-radius:25px;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ADD TO CART</button></a> -->
                                        <a><button type="submit" id="submit" style="background-color:#fc0c4c;color:white;width:300px;height:70px;right:150px;"><img src="../../../admin/images/designer.png" style="width:50px;height:50px;border-radius:25px;">&nbsp;&nbsp;&nbsp;REQUEST DESIGNER</button>

                                    </form>


                                    <script src="../../../customer/js/jquery/jquery.min.js"></script>

	                            <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script> -->
                                <script>
                                $(document).ready(function(){
                                    $("#formButton").click(function(){
                                        $("#form1").toggle();
                                    });
                                });
                                </script>
                                <script>
                                $(document).ready(function(){
                                    $("#formButton1").click(function(){
                                        $("#form2").toggle();
                                    });
                                });
                                </script>



                            </td>
                            <?php
    }
}
?>
                          </tr>
                          
                      </table>

                  </div>
                    
    
                <script>
                    function bigImg(x) 
                    {
                        x.style.height = "635px";
                        x.style.width = "535px";
                    }

                    function normalImg(x) 
                    {
                        x.style.height = "625px";
                        x.style.width = "525px";
                    }
                    
                </script>













                </div>                    
        	<div class="clearfix"> </div>
		</div>
		
				
        <!-- ****** Top Discount Area End ****** -->

        <!-- ****** Welcome Slides Area Start ****** -->
        
        <!-- ****** Top Catagory Area End ****** -->
<br><br>
            		
            <hr/>

        <!-- ****** Footer Area Start ****** -->
        
        <!-- ****** Footer Area End ****** -->
    </div>
    <!-- /.wrapper end -->

    <!-- jQuery (Necessary for All JavaScript Plugins) -->
    <script src="../../../customer/js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="../../../customer/js/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="../../../customer/js/bootstrap.min.js"></script>
    <!-- Plugins js -->
    <script src="../../../customer/js/plugins.js"></script>
    <!-- Active js -->
    <script src="../../../customer/js/active.js"></script>
    <!-- <script>
// Get the elements with class="column"
var elements = document.getElementsByClassName("column");

// Declare a loop variable
var i;

// Full-width images
function one() {
    for (i = 0; i < elements.length; i++) {
        elements[i].style.msFlex = "100%";  // IE10
        elements[i].style.flex = "100%";
    }
}

// Two images side by side
function two() {
    for (i = 0; i < elements.length; i++) {
        elements[i].style.msFlex = "50%";  // IE10
        elements[i].style.flex = "50%";
    }
}

// Four images side by side
function four() {
    for (i = 0; i < elements.length; i++) {
        elements[i].style.msFlex = "25%";  // IE10
        elements[i].style.flex = "25%";
    }
}

// Add active class to the current button (highlight it)
var header = document.getElementById("myHeader");
var btns = header.getElementsByClassName("btn");
for (var i = 0; i < btns.length; i++) {
  btns[i].addEventListener("click", function() {
    var current = document.getElementsByClassName("active");
    current[0].className = current[0].className.replace(" active", "");
    this.className += " active";
  });
}


$(document).ready(function() {
  $('.template-article img').each(function() {
      var currentImage = $(this);
      currentImage.wrap("<a class='image-link' href='" + currentImage.attr("src") + "'</a>");
  });
  $('.image-link').magnificPopup({type:'image'});  
});
</script> -->
</body>

</html>