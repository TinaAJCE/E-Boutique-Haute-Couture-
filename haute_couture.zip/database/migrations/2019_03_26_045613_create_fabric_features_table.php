<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateFabricFeaturesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('fabric_features', function (Blueprint $table) {
            $table->bigIncrements('fab_fid');
           
            $table->bigInteger('fab_id')->unsigned();
            $table->foreign('fab_id')->references('fab_id')->on('fabrics');
            $table->string('features');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('fabric_features');
    }
}
