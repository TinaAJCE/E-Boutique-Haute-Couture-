<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCheckOrdersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('check_orders', function (Blueprint $table) {
            $table->bigIncrements('co_id');
            $table->bigInteger('order_id')->unsigned();
            $table->bigInteger('reg_id')->unsigned();
            $table->bigInteger('product_id')->unsigned();
            $table->string('product_color');
            $table->string('unit_price');
            $table->string('quantity');
            $table->string('total_amount');
            $table->string('status');
            $table->string('checked');
           
            $table->foreign('order_id')->references('order_id')->on('orders');
            $table->foreign('reg_id')->references('reg_id')->on('registers');
            $table->foreign('product_id')->references('product_id')->on('products');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('check_orders');
    }
}
