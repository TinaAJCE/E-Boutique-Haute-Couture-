<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateProductsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('products', function (Blueprint $table) {
            $table->bigIncrements('product_id');
            $table->string('product_name');
            $table->string('product_price');
            $table->string('product_color');
            $table->string('product_stock');
            $table->string('product_description');
            $table->string('cover_image');
            $table->string('product_designer');
            $table->string('product_status');
           

            $table->bigInteger('category_id')->unsigned();
            $table->bigInteger('bs_id')->unsigned();
            $table->bigInteger('fab_id')->unsigned();
            $table->bigInteger('h_id')->unsigned();
            $table->bigInteger('letter_size_id')->unsigned();
            $table->bigInteger('l_id')->unsigned();
            $table->bigInteger('n_id')->unsigned();
            $table->foreign('category_id')->references('category_id')->on('products_categories');
            $table->foreign('bs_id')->references('bs_id')->on('bust_sizes');
            $table->foreign('fab_id')->references('fab_id')->on('fabrics');
            $table->foreign('h_id')->references('h_id')->on('hip_sizes');
            $table->foreign('letter_size_id')->references('letter_size_id')->on('letter_sizes');
            $table->foreign('l_id')->references('l_id')->on('low_waists');
            $table->foreign('n_id')->references('n_id')->on('natural_waists');
            
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('products');
    }
}
