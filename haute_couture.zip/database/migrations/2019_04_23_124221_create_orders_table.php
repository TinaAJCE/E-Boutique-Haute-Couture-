<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateOrdersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('orders', function (Blueprint $table) {
            $table->bigIncrements('order_id');
            $table->bigInteger('reg_id')->unsigned();
            $table->string('net_amount');
            $table->string('tax');
            $table->string('discount');
            $table->string('grand_total');
            $table->string('order_date');
            $table->string('delivery_expected');
            $table->string('status');
            $table->string('checked');
            $table->foreign('reg_id')->references('reg_id')->on('registers');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('orders');
    }
}
