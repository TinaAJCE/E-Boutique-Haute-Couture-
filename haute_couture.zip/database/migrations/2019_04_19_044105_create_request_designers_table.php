<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateRequestDesignersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('request_designers', function (Blueprint $table) {
            $table->bigIncrements('rtd_id');
            $table->bigInteger('reg_id')->unsigned();
            $table->bigInteger('designer_id')->unsigned();
            $table->bigInteger('product_id')->unsigned();
            $table->string('product_color');
            $table->string('unit_price');
            $table->string('quantity');
            $table->string('total_amount');
            $table->bigInteger('letter_size_id')->unsigned();
            $table->bigInteger('bs_id')->unsigned();
            $table->bigInteger('n_id')->unsigned();
            $table->bigInteger('h_id')->unsigned();
            $table->bigInteger('l_id')->unsigned();
            $table->bigInteger('fab_id')->unsigned();

            $table->string('status');
            $table->string('checked');
           
            
            $table->foreign('reg_id')->references('reg_id')->on('registers');
            $table->foreign('designer_id')->references('reg_id')->on('registers');
            $table->foreign('product_id')->references('product_id')->on('products');
            $table->foreign('letter_size_id')->references('letter_size_id')->on('letter_sizes');
            $table->foreign('bs_id')->references('bs_id')->on('bust_sizes');
            $table->foreign('n_id')->references('n_id')->on('natural_waists');
            $table->foreign('h_id')->references('h_id')->on('hip_sizes');
            $table->foreign('l_id')->references('l_id')->on('low_waists');
            $table->foreign('fab_id')->references('fab_id')->on('fabrics');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('request_designers');
    }
}
