<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAdminRequestDesignersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('admin_request_designers', function (Blueprint $table) {
            
            $table->bigIncrements('ard_id');
            $table->string('order_id');
            $table->bigInteger('reg_id')->unsigned();
            $table->bigInteger('designer_id')->unsigned();
            $table->bigInteger('product_id')->unsigned();
            $table->string('product_color');
            $table->bigInteger('letter_size_id')->unsigned();
            $table->bigInteger('fab_id')->unsigned();
            $table->string('quantity');
            $table->string('status');
            $table->string('checked');

            $table->foreign('reg_id')->references('reg_id')->on('registers');
            $table->foreign('designer_id')->references('reg_id')->on('registers');
            $table->foreign('product_id')->references('product_id')->on('products');
            $table->foreign('letter_size_id')->references('letter_size_id')->on('letter_sizes');
            $table->foreign('fab_id')->references('fab_id')->on('fabrics');
           
           
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('admin_request_designers');
    }
}
