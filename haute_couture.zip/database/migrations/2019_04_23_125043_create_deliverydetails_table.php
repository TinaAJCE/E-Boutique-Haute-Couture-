<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateDeliverydetailsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('deliverydetails', function (Blueprint $table) {
            $table->bigIncrements('d_id');
            $table->bigInteger('reg_id')->unsigned();
            $table->bigInteger('order_id')->unsigned();
            $table->string('address');
            $table->string('payment_mode');
            $table->string('pincode');
            $table->string('status');

            $table->foreign('reg_id')->references('reg_id')->on('registers');
            $table->foreign('order_id')->references('order_id')->on('orders');







            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('deliverydetails');
    }
}
