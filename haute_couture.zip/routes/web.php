<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
//Route::get('home','HomeController@home');
//Route::get('/home', function () {
//    return view('welcome');
//});
Route::get('/home', function () {
    return view('welcome');
});
Route::get('homes', function () {
    return redirect('welcome');
});
Route::get('login1','LoginsController@login');
Route::get('/login1', function () {
    return view('logins/login');
});
Route::get('newuser','UserregisterController@register');
Route::get('/login1', function () {
    return view('logins/login');
});

Route::get('/customer', function () {
    return view('logins/customerregister');
});


Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
//Route::get('/newuser', 'CustomerregisterController@store');
//Route::post('/custreg', 'CustomerregisterController@store')->name('home');

Route::post('/registers', 'RegistersController@register')->name('home');
Route::post('/reg', 'RegistersController@store')->name('home');

Route::post('/designReg', 'RegistersController@designerstore')->name('home');

Route::post('/distributorReg', 'RegistersController@distributorstore')->name('home');

Route::any('/log', 'LogsController@login');
//Route::post('/logout', 'LogsController@logout');
//Route::get('logout','LogsController@logout');

Route::group(['middleware' => 'preventbackbutton','auth'],function(){
    
    Route::get('/home', 'HomeController@index');
  });


Route::post('/registers', 'RegistersController@register')->name('home');
Route::any('/designerProducts', 'LogsController@designerProducts')->name('home');

Route::get('/profile/{reg_id}', [
    'as' => 'logs', 'uses' => 'LogsController@profile'
]);
Route::get('/profile_edit/{reg_id}',    [
    'as' => 'profile_edit', 'uses' => 'LogsController@profile_edit'
]);

Route::post('/profile_update', 'LogsController@admin_profile_update');
//Route::any('/profile_update/{reg_id}', [
  //  'as' => 'admin_profile_update', 'uses' => 'LogsController@profile_update'
//]);


Route::get('/home', 'HomeController@index')->name('home');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
Route::get('/logout', '\App\Http\Controllers\LogsController@logout');


Route::get('/admin/profile', 'LogsController@profile');
Route::get('/product_type', 'ProductsCategoryController@product_type');
Route::post('/product_type_add','ProductsCategoryController@product_type_add');

Route::get('/new_product', 'ProductsController@new_product');
Route::post('/new_product_add', 'ProductsController@new_product_add');

//Route::get('/product_view/{reg_id}', 'ProductsController@product_view');
Route::get('/product_view/{reg_id}',    [
    'as' => 'view', 'uses' => 'ProductsController@product_view'
]);

Route::get('/image_view/{product_id}',    [
    'as' => 'imgview', 'uses' => 'ProductsController@imageview'
]);
//Route::get('/profile_edit', 'LogsController@admin_profile_update')->name('home');




Route::get('/view_products/{reg_id}',    [
    'as' => 'viewpro', 'uses' => 'ProductsController@view_products'
]);

Route::get('/prodelete/{product_id}',    [
    'as' => 'delpro', 'uses' => 'ProductsController@delete_products'
]);



Route::get('/view_categories/{reg_id}',    [
    'as' => 'catview', 'uses' => 'ProductsController@view_categories']);

Route::get('/view_productcategories/{reg_id}',    [
    'as' => 'viewprocat', 'uses' => 'ProductsController@view_productcategories']);

Route::get('/catdelete/{category_id}',    [
        'as' => 'delcat', 'uses' => 'ProductsController@delete_productscategory'
    ]);


Route::get('/view_fabrics/{reg_id}',    [
        'as' => 'viewfabrics', 'uses' => 'ProductsController@view_fabrics']);
Route::get('/fabdelete/{fab_id}',    [
            'as' => 'delfab', 'uses' => 'ProductsController@delete_fabrics'
        ]);
//Route::get('/addnew_fabric', 'ProductsController@add_fabric');
Route::get('/addnew_fabric/{reg_id}',    [
    'as' => 'addnew_fabric', 'uses' => 'ProductsController@add_fabric'
]);
Route::post('/new_fabric_add','ProductsController@new_fabric_add');

Route::get('/size_chart/{reg_id}',    [
            'as' => 'size_chart', 'uses' => 'ProductsController@size_chart'
        ]);

Route::get('/customer/{reg_id}',    [
            'as' => 'customer', 'uses' => 'RegistersController@customer'
        ]);

Route::get('/update_status/{id}',    [
            'as' => 'update_status', 'uses' => 'RegistersController@update_status'
        ]);
        
Route::get('/designer/{reg_id}',    [
            'as' => 'designer', 'uses' => 'RegistersController@designer'
        ]);
Route::get('/update_designer_status/{id}',    [
            'as' => 'update_designer_status', 'uses' => 'RegistersController@update_designer_status'
        ]);

Route::get('/distributor/{reg_id}',    [
            'as' => 'distributor', 'uses' => 'RegistersController@distributor'
        ]);
Route::get('/update_distributor_status/{id}',    [
            'as' => 'update_distributor_status', 'uses' => 'RegistersController@update_distributor_status'
        ]);
Route::any('/req_from_cust','CartController@request_from_customer');       

Route::post('/admin_request_designer','AdminRequestDesignerController@admin_request_designer');
//Customer SECTION

Route::get('/customer_home/{reg_id}',    [
    'as' => 'custhome', 'uses' => 'ProductsController@customer_home'
]);

Route::get('/view_all_products/{reg_id}',    [
    'as' => 'custproview', 'uses' => 'ProductsController@view_all_products'
]);
Route::get('/view_all_products/{product_id}/{reg_id}',    [
    'as' => 'custproimgview', 'uses' => 'ProductsController@view_img_products'
]);

Route::post('/requestdesigner', 'RequestDesignerController@designer_request');
Route::post('/cart', 'CartController@add_to_cart');

Route::post('/wishlist',    [
    'as' => 'wishlist', 'uses' => 'WishlistController@wishlist'
]);


// sidebar cart and wishlist

Route::get('/wishlist-products/{reg_id}',    [
    'as' => 'prefered', 'uses' => 'WishlistController@wishlist_products'
]);

Route::get('/delete/{product_id}',    [
    'as' => 'delete', 'uses' => 'WishlistController@wishlist_delete'
]);

Route::get('/cart-view/{reg_id}',    [
    'as' => 'cart_view', 'uses' => 'CartController@cart_view'
]);
Route::get('/delete_cart/{product_id}/{product_color}',    [
    'as' => 'delete_from_cart', 'uses' => 'CartController@delete_from_cart'
]);
Route::post('/update_cart', 'CartController@update_cart');
Route::get('/request_to_designer/{reg_id}',    [
    'as' => 'rtd', 'uses' => 'RequestDesignerController@rtd_view'
]);

Route::get('/delete_from_design_request/{rtd_id}/{product_id}',    [
    'as' => 'delete_from_design_request', 'uses' => 'RequestDesignerController@delete_from_design_request'
]);
Route::get('/trial/{product_id}',    [
    'as' => 'trial', 'uses' => 'RequestDesignerController@trial'
]);
// buy now
Route::get('/buynow/{reg_id}/{img_name}',    [
    'as' => 'buynow', 'uses' => 'OrderController@store_order'
]);
Route::any('/delivery_address', 'DeliverydetailsController@add_delivery_address');

Route::any('/card_payment', 'CardDetailsController@card_payment');


// DESIGNER PATHS

Route::get('/upload_designs','ProductsController@view_upload_page');
Route::post('/designs_upload','ProductsController@designs_upload');
Route::get('/designer_home/{reg_id}',    [
    'as' => 'deshome', 'uses' => 'ProductsController@designer_home'
]);
Route::get('/designer_products','ProductsController@view_designer_products');
Route::get('/design_approve/{product_id}',    [
    'as' => 'design_approve', 'uses' => 'ProductsController@design_approve'
]);
Route::get('/design_product','ProductsController@designer_products');

Route::get('/admin_request/{reg_id}',    [
    'as' => 'admin_request', 'uses' => 'ProductsController@admin_request'
]);
Route::get('/complete_admin_request/{product_id}/{product_color}',    [
    'as' => 'complete_admin_request', 'uses' => 'ProductsController@complete_admin_request'
]);
Route::get('/customer_request/{reg_id}',    [
    'as' => 'customer_request', 'uses' => 'ProductsController@customer_request'
]);
Route::get('/completed_request/{reg_id}',    [
    'as' => 'completed_request', 'uses' => 'ProductsController@completed_request'
]);
Route::get('/my_products/{reg_id}',    [
    'as' => 'my_products', 'uses' => 'ProductsController@my_products'
]);
Route::get('/view_product/{product_id}',    [
    'as' => 'viewproduct', 'uses' => 'ProductsController@viewproduct'
]);
Route::get('/complete_customer_request/{product_id}/{product_color}',    [
    'as' => 'complete_customer_request', 'uses' => 'ProductsController@complete_customer_request'
]);
Route::get('/change_customer_request/{product_id}/{product_color}',    [
    'as' => 'change_customer_request', 'uses' => 'ProductsController@change_customer_request'
]);
Route::get('/designer_products_image_view/{product_id}',    [
    'as' => 'desproimgview', 'uses' => 'ProductsController@desproimgview'
]);
Route::get('/my_profile/{reg_id}',    [
    'as' => 'my_profile', 'uses' => 'ProductsController@profile_view'
]);
Route::post('/upload_profile_photo/{reg_id}',    [
    'as' => 'upload_profile_photo', 'uses' => 'ProductsController@upload_profile_photo'
]);
Route::get('/edit_profile/{reg_id}',    [
    'as' => 'edit_profile', 'uses' => 'ProductsController@edit_profile'
]);
Route::post('/update_details','ProductsController@update_details');
Route::get('/change_password/{reg_id}',    [
    'as' => 'change_password', 'uses' => 'ProductsController@change_password'
]);
Route::post('/update_password/{reg_id}',    [
    'as' => 'update_password', 'uses' => 'ProductsController@update_password'
]);

Route::get('/completed_admin_request','ProductsController@completed_admin_request');
Route::any('/request_distributor/{ard_id}',    [
    'as' => 'request_distributor', 'uses' => 'ProductsController@request_distributor'
]);
Route::get('/completed_customer_request','ProductsController@completed_customer_request');

Route::any('/request_cust_distributor/{rtd_id}',    [
    'as' => 'request_cust_distributor', 'uses' => 'ProductsController@request_cust_distributor'
]);
Route::get('/dispatched_orders','ProductsController@dispatched_orders');
Route::get('/dashboard','ProductsController@dashboard');

Route::get('/distribution','ProductsController@distribution');
Route::any('/distribu/{ard_id}',    [
    'as' => 'delivered', 'uses' => 'ProductsController@distributor'
]);

Route::get('/designer_product','ProductsController@designer_product');

Route::get('/notify_customer','ProductsController@notification');
Route::any('/notif_customer/{rtd_id}',    [
    'as' => 'notification_for_customer', 'uses' => 'ProductsController@notif_customer'
]);
Route::get('/purchasenow/{rtd_id}/{img_name}',    [
    'as' => 'purchasenow', 'uses' => 'OrderController@purchase_order'
]);
Route::any('/designer_delivery_address', 'DeliverydetailsController@add_designer_delivery_address');
Route::any('/dd_card_payment', 'CardDetailsController@dd_card_payment');
Route::get('/view_profile/{reg_id}',    [
    'as' => 'view_profile', 'uses' => 'LogsController@view_customer_profile'
]);
Route::get('/recieve_money/{reg_id}',    [
    'as' => 'recieve_money', 'uses' => 'ProductsController@recieve_money'
]);

Route::post('/upload_profile_customer_photo/{reg_id}',    [
    'as' => 'upload_profile_customer_photo', 'uses' => 'ProductsController@upload_profile_customer_photo'
]);
Route::any('/edit_customer_profile/{reg_id}',    [
    'as' => 'edit_customer_profile', 'uses' => 'ProductsController@edit_customer_profile'
]);
Route::post('/update_customer_details','ProductsController@update_customer_details');
Route::get('/order_status/{reg_id}',    [
    'as' => 'order_status', 'uses' => 'OrderController@order_status'
]);
Route::get('/customer_change_password/{reg_id}',    [
    'as' => 'customer_change_password', 'uses' => 'ProductsController@customer_change_password'
]);
Route::post('/customer_update_password/{reg_id}',    [
    'as' => 'customer_update_password', 'uses' => 'ProductsController@customer_update_password'
]);
Route::any('/distribu_designer/{rtd_id}',    [
    'as' => 'delivered_designer', 'uses' => 'ProductsController@distributor_designer'
]);
Route::get('/delivered_products','ProductsController@delivered_products');
Route::get('/delivered_orders','ProductsController@delivered_orders');
Route::post('/upload_profile_admin_photo/{reg_id}',    [
    'as' => 'upload_profile_admin_photo', 'uses' => 'ProductsController@upload_profile_admin_photo'
]);