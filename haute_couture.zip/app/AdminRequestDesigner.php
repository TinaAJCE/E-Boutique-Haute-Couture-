<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AdminRequestDesigner extends Model
{
    public $fillable=['order_id','reg_id','designer_id','product_id','product_color','letter_size_id','fab_id','quantity','status','checked'];
}
