<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Low_waist extends Model
{
    //
}
