<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CheckOrder extends Model
{
    public $fillable=['order_id','reg_id','product_id','product_color','unit_price','quantity','total_amount','status','checked'];
}
