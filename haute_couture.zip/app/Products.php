<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Products extends Model
{
    public $fillable=['product_name','product_price','product_color','product_stock','product_description','cover_image','product_designer','product_status','category_id','bs_id','fab_id','h_id','letter_size_id','l_id','n_id'];
}
