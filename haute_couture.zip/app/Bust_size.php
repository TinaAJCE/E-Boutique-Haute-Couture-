<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Bust_size extends Model
{
    //
}
