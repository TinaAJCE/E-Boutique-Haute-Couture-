<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AdditionalFeatures extends Model
{
    public $fillable=['rtd_id','features'];

}
