<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class letter_size extends Model
{
    //
}
