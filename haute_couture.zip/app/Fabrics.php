<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Fabrics extends Model
{
    public $fillable=['fab_name','seller','fab_image','fab_status'];
}
