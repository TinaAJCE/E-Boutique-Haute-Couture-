<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Fabric_features extends Model
{
    public $fillable=['fab_id','features'];

}
