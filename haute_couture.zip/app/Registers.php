<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Registers extends Model
{
    public $fillable=['register_name','register_phone'];
}
