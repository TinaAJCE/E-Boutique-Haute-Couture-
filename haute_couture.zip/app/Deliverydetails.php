<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Deliverydetails extends Model
{
    public $fillable=['reg_id','order_id','address','payment_mode','pincode','status'];
}
