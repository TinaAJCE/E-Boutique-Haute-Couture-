<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Hip_size extends Model
{
    //
}
