<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Customerregister extends Model
{
    public $fillable=['name'];
}
