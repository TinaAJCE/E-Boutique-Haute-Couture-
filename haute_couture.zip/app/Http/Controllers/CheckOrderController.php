<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CheckOrderController extends Controller
{
    //
}
