<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use DB;
use App\Registers;
use App\ProductsCategory;

class ProductsCategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }
    public function product_type(Request $request)
    {
        //$request->session()->put('reg_id',$reg_id); 
        return view('admin.new_product_type');

    }
    public function product_type_add(Request $request)
    {
        $new_product=$request->input('new_product');

        $check=DB::table('products_categories')->where(['category_name'=>$new_product])->get();
        if(count($check)==0)
        {
            $productstype=new ProductsCategory(['category_name'=>$request->get('new_product'),'category_status'=>1]);
            $productstype->save();
            return redirect()->back() ->with('alert', 'Added the product successfully!');
            //return view('admin.admin');
        }
        else
        {
            return redirect()->back() ->with('alert', 'Already Exist!');
        }
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
