<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use DB;
use App\Registers;
use App\ProductsCategory;
use App\Products;
use App\ProductsImages;
use App\Fabrics;
use App\Fabric_features;
class ProductsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    public function new_product(Request $request)
    {
        $reg_id=DB::table('logs')->where('email','tinajose1996@gmail.com')->first();
        $request->session()->put('reg_id',$reg_id->reg_id); 
        return view('admin.new_product');

    }
    public function new_product_add(Request $request)
    {
        $product_name=$request->input('product_name');
        $category_id=$request->input('p_category');
        $check=DB::table('products')->where(['product_name'=>$product_name])->get();
        if(count($check)==0)
        {
            $cover_photo=$request->pic->getClientOriginalName();
            $request->pic->storeAs('public/upload',$cover_photo);
            $newproduct=new Products(['product_name'=>$request->get('product_name'),'product_price'=>$request->get('product_price'),'product_color'=>$request->get('product_color'),'product_stock'=>$request->get('product_stock'),'product_description'=>$request->get('product_desc'),'cover_image'=>$cover_photo,'product_status'=>1,'category_id'=>$category_id,'bs_id'=>$request->get('b_size'),'fab_id'=>$request->get('fabs'),'h_id'=>$request->get('h_size'),'letter_size_id'=>$request->get('size'),'l_id'=>$request->get('l_size'),'n_id'=>$request->get('n_size'),]);
            $newproduct->save();

                $id=products::max('product_id');
               
            
            if($request->hasfile('files'))
             {
    
                foreach($request->file('files') as $image)
                {
                    $name=$image->getClientOriginalName();
                    $image->move('storage/upload', $name); 
                    $form= new ProductsImages();
                    $form->file_name=$name;
                    $form->product_id=$id;
                    $form->save(); 
                    
                }
                return redirect()->back() ->with('alert', 'Added the product successfully!');
             }
    
             
    
           
        
				
            //echo"uploaded";
        }
        else
        {
            return redirect()->back() ->with('alert', 'Already Exist!');
        }

        


    return redirect('redirecting page');
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function update_status(Request $request,$id)
    {

                   $systems= DB::table('logs')->select('id','email','login_status','reg_id');
                   $systems->where('login_status', 0);
                   $rows = $systems->get();
                   $count=$systems->count();
                   if($count!=0)
                   {
                       foreach($rows as $g)
                       {
                           $id=$g->id;
                       
                           DB::table('logs')->where('id', $id)->update(['login_status' => 1]);
                           return view('admin.customer_report');
                       }
                   }
       
    }
     
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    public function product_view(Request $request,$reg_id){ 
        $request->session()->put('reg_id',$reg_id); 
        return view('admin.product_view');  
    }
    public function imageview(Request $request,$p_id) 
    {
        $request->session()->put('product_id',$p_id); 
        return view('admin.imageview');

    }
    public function view_fabrics(Request $request,$reg_id){ 
        $request->session()->put('reg_id',$reg_id); 
        return view('admin.fabrics_view');  
    }

    public function view_products(Request $request,$reg_id){ 
        $request->session()->put('reg_id',$reg_id); 
        return view('admin.view_products');  
    }

    public function delete_products(Request $request,$product_id)
    {
        $sys= DB::table('products')->where('product_id', $product_id)->update(['product_status' => 0]);
        
        return view('admin.view_products');
            
    }
    
    
    public function delete_fabrics(Request $request,$fab_id)
    {
        $sys= DB::table('fabrics')->where('fab_id', $fab_id)->update(['fab_status' => 0]);
        
        return view('admin.fabrics_view');
            
    }
    
    public function delete_productscategory(Request $request,$category_id)
    {
        $sys= DB::table('products_categories')->where('category_id', $category_id)->update(['category_status' => 0]);
        
        return view('admin.product_categories');
            
    }
    public function view_categories(Request $request,$reg_id){ 
        $request->session()->put('reg_id',$reg_id); 
        return view('admin.view_categories');  
    }
    
    public function view_productcategories(Request $request,$reg_id){ 
        $request->session()->put('reg_id',$reg_id); 
        return view('admin.product_categories');  
    }

    public function size_chart(Request $request,$reg_id){ 
        $request->session()->put('reg_id',$reg_id); 
        return view('admin.size_chart');  
    }



    public function add_fabric(Request $request,$reg_id)
    {
        $request->session()->put('reg_id',$reg_id); 
        return view('admin.add_fabric');

    }

    

    public function new_fabric_add(Request $request)
    {
        
        $fab_name=$request->input('fabric_name');
        $seller=$request->input('seller');
        
        //dd($fab_name);
        $check=DB::table('fabrics')->where(['fab_name'=>$fab_name])->get();
        if(count($check)==0)
        {
            if($request->input('seller')==$seller)
            {
                $seller=$request->input('sell');
                //dd($seller);
            }
           
            $seller=$request->input('seller');
                //dd($seller);
            
            $fab_image=$request->pic->getClientOriginalName();
            $request->pic->storeAs('public/upload',$fab_image);
            
             $newfab=new Fabrics(['fab_name'=>$fab_name,'seller'=>$seller,'fab_image'=>$fab_image,'fab_status'=>1,]);

           
           $newfab->save();

            $id=fabrics::max('fab_id');
            //dd($id);
            $features=$request->input('fabric_features');
           
            $newfab_feature=new Fabric_features(['fab_id'=>$id,'features'=>$features,]);
            //dd($newfab_feature);
            $newfab_feature->save();
            
           return redirect()->back() ->with('alert', 'Added the product successfully!');
           
        }
        else
        {
            return redirect()->back() ->with('alert', 'Already Exist!');
        }

        


    return redirect('redirecting page');
    }


    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }


    //Customer Section

    public function view_all_products(Request $request,$reg_id){ 
        $request->session()->put('reg_id',$reg_id); 
        return view('customer.allproducts');  
    }
    public function customer_home(Request $request,$reg_id){ 
        $request->session()->put('reg_id',$reg_id); 
        return view('customer.customer');  
    }
    public function designer_home(Request $request,$reg_id){ 
        $request->session()->put('reg_id',$reg_id); 
        return view('designer.designer');  
    }
    public function view_img_products(Request $request,$product_id,$reg_id){ 
        $request->session()->put('product_id',$product_id);
        $request->session()->put('reg_id',$reg_id);  
        return view('customer.imageproducts');  
    }
    public function view_upload_page(Request $request){
        return view('designer.upload_designs'); 
    }
    public function view_designer_products(Request $request){
        return view('admin.designer_products'); 
    }
    public function designs_upload(Request $request){

        $designer_id=$request->input('designer_id');
       // dd($designer_id);
        $product_name=$request->input('product_name');
        $category_id=$request->input('p_category');
        $check=DB::table('products')->where(['product_name'=>$product_name])->get();
        if(count($check)==0)
        {
            $cover_photo=$request->pic->getClientOriginalName();
            $request->pic->storeAs('public/upload',$cover_photo);
            $newproduct=new Products(['product_name'=>$request->get('product_name'),'product_price'=>$request->get('product_price'),'product_color'=>$request->get('product_color'),'product_stock'=>$request->get('product_stock'),'product_description'=>$request->get('product_desc'),'cover_image'=>$cover_photo,'product_designer'=>$designer_id,'product_status'=>0,'category_id'=>$category_id,'bs_id'=>$request->get('b_size'),'fab_id'=>$request->get('fabs'),'h_id'=>$request->get('h_size'),'letter_size_id'=>$request->get('size'),'l_id'=>$request->get('l_size'),'n_id'=>$request->get('n_size'),]);
            //dd($newproduct);
            $newproduct->save();

                $id=products::max('product_id');
               
            
            if($request->hasfile('files'))
             {
    
                foreach($request->file('files') as $image)
                {
                    $name=$image->getClientOriginalName();
                    $image->move('storage/upload', $name); 
                    $form= new ProductsImages();
                    $form->file_name=$name;
                    $form->product_id=$id;
                    $form->save(); 
                    
                }
                return redirect()->back() ->with('alert', 'Added the product successfully!');
             }
    
             
    
           
        
				
            //echo"uploaded";
        }
        else
        {
            return redirect()->back() ->with('alert', 'Already Exist!');
        }

        


    return redirect('redirecting page');

    }

    public function design_approve(Request $request,$product_id)
    {
        DB::table('products')->where('product_id',$product_id)->update(['product_status' => 1]);
        return view('admin.designer_products');
    }
    public function designer_products(Request $request)
    {
        // DB::table('products')->where('product_id',$product_id)->update(['product_status' => 1]);
        return view('customer.design_products');
    }
    public function admin_request(Request $request,$reg_id)
    {
        $request->session()->put('reg_id',$reg_id); 
        return view('designer.admin_request');
    }
    public function complete_admin_request(Request $request,$product_id,$product_color)
    {
        $m=DB::table('admin_request_designers')->where('product_id',$product_id)->where('product_color',$product_color)->update(['status'=>0]);
        // $sys= DB::table('fabrics')->where('fab_id', $fab_id)->update(['fab_status' => 0]);
        
        return view('designer.admin_request');
            
    }
    public function customer_request(Request $request,$reg_id)
    {
        $request->session()->put('reg_id',$reg_id); 
        return view('designer.customer_request');
    }
    public function completed_request(Request $request,$reg_id)
    {
        $request->session()->put('reg_id',$reg_id); 
        return view('designer.completed_request');
    }
    public function my_products(Request $request,$reg_id)
    {
        $request->session()->put('reg_id',$reg_id); 
        return view('designer.my_products');
    }
    public function viewproduct(Request $request,$product_id)
    {
        //dd('jkkld');
        $request->session()->put('product_id',$product_id); 
        return view('designer.viewproducts');
    }
    public function complete_customer_request(Request $request,$product_id,$product_color)
    {
        //dd('hggvgh');
        $gj=DB::table('request_designers')->where('product_id',$product_id)->where('product_color',$product_color)->update(['status'=>0]);
        
        return view('designer.customer_request');
            
    }
    public function change_customer_request(Request $request,$product_id,$product_color)
    {
        //dd('hggvgh');
        $gj=DB::table('request_designers')->where('product_id',$product_id)->where('product_color',$product_color)->update(['status'=>2]);
        
        return view('designer.customer_request');
            
    }
    public function desproimgview(Request $request,$product_id)
    {
        $request->session()->put('product_id',$product_id);
        return view('designer.desproimgview');
    }
    public function profile_view(Request $request,$reg_id)
    {
        $request->session()->put('reg_id',$reg_id);
        return view('designer.my_profile');
    }
    public function upload_profile_photo(Request $request,$reg_id)
    {
        $cover_photo=$request->pic->getClientOriginalName();
        $request->pic->storeAs('public/upload',$cover_photo);
        // dd($cover_photo);
        $t=DB::table('registers')->where('reg_id',$reg_id)->update(['register_photo'=>$cover_photo]);
        
        return view('designer.my_profile');
           

    }
    public function edit_profile(Request $request,$reg_id)
    {
        $request->session()->put('reg_id',$reg_id);
        return view('designer.edit_profile');
    }
    public function update_details(Request $request)
    {
        $reg_id=$request->input('reg_id');
        $name=$request->input('reg_name');
        $phone=$request->input('phone');
        $address=$request->input('address');
        $cname=$request->input('cname');
        
        $o=DB::table('registers')->where('reg_id',$reg_id)->update(['register_name'=>$name,'register_phone'=>$phone,'register_company_name'=>$cname,'register_address'=>$address]);
        return view('designer.my_profile');
    }
    public function change_password(Request $request,$reg_id)
    {
        $request->session()->put('reg_id',$reg_id);
        return view('designer.change_password');
    }
    public function update_password(Request $request,$reg_id)
    {
        $pswd=$request->input('password');
        $npswd=$request->input('newpassword');
        $cpswd=$request->input('cpassword');
        
        $o=DB::table('logs')->where('reg_id',$reg_id)->first();
        if($o->password==$pswd)
        {
            if($npswd==$cpswd)
            {
                $jk=DB::table('logs')->where('reg_id',$reg_id)->update(['password'=>$npswd]);
            }
            else
            {
                return redirect()->back() ->with('alert', 'Password Doenot Match!');
            }
        }
        else
        {
            return redirect()->back() ->with('alert', 'Given Password Is Not Correct!');
        }
        return redirect()->back() ->with('alert', 'Updated Successfully!');
    }
    public function completed_admin_request(Request $request)
    {
        return view('admin.completed_admin_requests');
    }
    public function request_distributor(Request $request,$ard_id)
    {
        $did=$request->input('distributor');
       // dd($did);
       $mno=DB::table('admin_request_designers')->where('ard_id',$ard_id)->update(['status'=>2,'distributor_id'=>$did]); 
       return view('admin.completed_admin_requests');
    }
    public function request_cust_distributor(Request $request,$rtd_id)
    {
        $did=$request->input('distributor');
       // dd($did);
       $mno=DB::table('request_designers')->where('rtd_id',$rtd_id)->update(['status'=>3,'distributor_id'=>$did]); 
       return view('admin.completed_customer_request');
    }
    public function completed_customer_request(Request $request)
    {
        return view('admin.completed_customer_request');
    }
    public function dispatched_orders(Request $request)
    {
        return view('admin.dispatched_orders');
    }
    public function dashboard(Request $request)
    {
        return view('admin.admin');
    }
    public function distribution(Request $request)
    {
        return view('distributor.distribution');
    }
    public function distributor(Request $request,$ard_id)
    {
        
        $f=DB::table('admin_request_designers')->where('ard_id',$ard_id)->update(['status'=>'delivered']);
        // return view('distributor.distribution');
        return redirect()->back() ->with('alert', 'Updated Successfully!');

    }
    public function distributor_designer(Request $request,$rtd_id)
    {
        
        $f=DB::table('request_designers')->where('rtd_id',$rtd_id)->update(['status'=>'delivered']);
        // return view('distributor.distribution');
        return redirect()->back() ->with('alert', 'Updated Successfully!');

    }
    public function recieve_money(Request $request,$rtd_id)
    {
        $n=DB::table('request_designers')->where('rtd_id',$rtd_id)->first();
        $k=DB::table('banks')->where('email','tinajose1996@gmail.com')->first();
        $balance=$k->balance_amount+$n->total_amount;
        // dd($n->total_amount);
        // dd($k->balance_amount);
        // dd($balance);
        // DB::table('banks')->where('email','tinajose1996@gmail.com')->update(['balance_amount'=>$balance]);
        DB::table('request_designers')->where('rtd_id',$rtd_id)->update(['checked'=>'paid','status'=>'delivered']);

        return redirect()->back() ->with('alert', 'Payment processed Successfully!');

    }
    public function notification(Request $request)
    {
        
        return view('admin.notify_customer_for_designs');

    }
    public function notif_customer(Request $request,$rtd_id)
    {
        
        $o=DB::table('request_designers')->where('rtd_id',$rtd_id)->update(['checked'=>2]);
        
        return redirect()->back() ->with('alert', 'Send Notification Successfully!');

    }
    public function upload_profile_customer_photo(Request $request,$reg_id)
    {
        $cover_photo=$request->pic->getClientOriginalName();
        $request->pic->storeAs('public/upload',$cover_photo);
        // dd($cover_photo);
        $t=DB::table('registers')->where('reg_id',$reg_id)->update(['register_photo'=>$cover_photo]);
        
        return view('customer.profile_view');
    }
    public function upload_profile_admin_photo(Request $request,$reg_id)
    {
        $cover_photo=$request->pic->getClientOriginalName();
        $request->pic->storeAs('public/upload',$cover_photo);
        // dd($cover_photo);
        $t=DB::table('registers')->where('reg_id',$reg_id)->update(['register_photo'=>$cover_photo]);
        
        return view('admin.profile');
    }
    public function edit_customer_profile(Request $request,$reg_id)
    {
        $request->session()->put('reg_id',$reg_id);
        return view('customer.profile_view_edit');
    }
    public function update_customer_details(Request $request)
    {
        $reg_id=$request->input('reg_id');
        $name=$request->input('reg_name');
        $phone=$request->input('phone');
        $address=$request->input('address');
        $cname=$request->input('cname');
        
        $o=DB::table('registers')->where('reg_id',$reg_id)->update(['register_name'=>$name,'register_phone'=>$phone,'register_company_name'=>$cname,'register_address'=>$address]);
        return view('customer.profile_view');
    }
    public function customer_change_password(Request $request,$reg_id)
    {
        $request->session()->put('reg_id',$reg_id);
        return view('customer.customer_change_password');
    }
    public function customer_update_password(Request $request,$reg_id)
    {
        $pswd=$request->input('password');
        $npswd=$request->input('newpassword');
        $cpswd=$request->input('cpassword');
        
        $o=DB::table('logs')->where('reg_id',$reg_id)->first();
        if($o->password==$pswd)
        {
            if($npswd==$cpswd)
            {
                $jk=DB::table('logs')->where('reg_id',$reg_id)->update(['password'=>$npswd]);
            }
            else
            {
                return redirect()->back() ->with('alert', 'Password Doenot Match!');
            }
        }
        else
        {
            return redirect()->back() ->with('alert', 'Given Password Is Not Correct!');
        }
        return redirect()->back() ->with('alert', 'Updated Successfully!');
    }
    public function delivered_products(Request $request)
    {
        return view('distributor.delivered_products');

    }
    public function delivered_orders(Request $request)
    {
        return view('admin.delivered_orders');

    }
}

