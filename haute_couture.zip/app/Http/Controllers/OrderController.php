<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use DB;
use App\Registers;
use App\Order;
use App\CheckOrder;
class OrderController extends Controller
{
    
   public function store_order(Request $request,$reg_id,$img_name)
   {
      // dd($img_name);
        $m=DB::table('carts')->where('reg_id',$reg_id)->where('status',1)->where('checked',0)->get();
        $c=$m->count();
        $total_amount=0;
        
        if($c!=0)
        {
            foreach($m as $item)
            {

                $total_amount=$total_amount+$item->total_amount;
            }
        }
        if($img_name=='excellent')
        {
            $discount=($total_amount * 10)/100;
            //dd($discount);
        }
        else if($img_name=='satisfactory')
        {
            $discount=($total_amount * 5)/100; 
            // dd($discount);
        }
        else if($img_name=='not_interested')
        {
            $discount=($total_amount * 2)/100;
            // dd($discount);
        }
        $tax=50;
        $grand_total=($total_amount + $tax) - $discount;
        // dd($grand_total);
        // $order_date=date('Y-m-d H:i:s');
        $order_date=date("Y/m/d");
        $d_expected=date('Y/m/d', strtotime($order_date. ' + 5 days'));
        // dd($order_date);
        // dd($d_expected);
        $orders=new Order(['reg_id'=>$reg_id,'net_amount'=>$total_amount,'tax'=>$tax,'discount'=>$discount,'grand_total'=>$grand_total,'order_date'=>$order_date,'delivery_expected'=>$d_expected,'status'=>1,'checked'=>0]);
        $orders->save();
        //dd('success');
        $o_id=order::max('order_id');
        // dd($o_id);

        if($c!=0)
        {
            foreach($m as $co)
            {
               
                $checkorders=new CheckOrder(['order_id'=>$o_id,'reg_id'=>$reg_id,'product_id'=>$co->product_id,'product_color'=>$co->product_color,'unit_price'=>$co->unit_price,'quantity'=>$co->quantity,'total_amount'=>$total_amount,'status'=>1,'checked'=>0]);
                $checkorders->save();
            }
        }
       // dd('echo');
        $request->session()->put('order_id',$o_id);
        $request->session()->put('reg_id',$reg_id); 
        return view('customer.delivery_details');

   }
   public function purchase_order(Request $request,$rtd_id,$img_name)
   {
       $b=DB::table('request_designers')->where('rtd_id',$rtd_id)->first();
       if($img_name=='excellent')
        {
            $discount=($b->total_amount * 10)/100;
            //dd($discount);
        }
        else if($img_name=='satisfactory')
        {
            $discount=($b->total_amount * 5)/100; 
            // dd($discount);
        }
        else if($img_name=='not_interested')
        {
            $discount=($b->total_amount * 2)/100;
            // dd($discount);
        }
        $tax=50;
        $total_amount=$b->quantity * $b->total_amount;
        $order_date=date("Y/m/d");
        $d_expected=date('Y/m/d', strtotime($order_date. ' + 5 days'));
        // dd($total_amount);
        $grand_total=($b->total_amount + $tax) - $discount;
        $orders=new Order(['reg_id'=>$b->reg_id,'net_amount'=>$total_amount,'tax'=>$tax,'discount'=>$discount,'grand_total'=>$grand_total,'order_date'=>$order_date,'delivery_expected'=>$d_expected,'status'=>1,'checked'=>0]);
        $orders->save();

        $o_id=order::max('order_id');
        DB::table('request_designers')->where('rtd_id',$rtd_id)->update(['order_id'=>$o_id]);
        $request->session()->put('rtd_id',$rtd_id);
        $request->session()->put('order_id',$o_id);
        $request->session()->put('reg_id',$b->reg_id); 
        return view('customer.customer_delivery_address');

   }
   public function order_status(Request $request,$reg_id)
   {
    $request->session()->put('reg_id',$reg_id); 
    
    return view('customer.order_status');
   }
}
