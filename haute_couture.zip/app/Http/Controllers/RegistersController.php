<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Registers;
class RegistersController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $unm=$request->input('email');
        $check=DB::table('logs')->where(['email'=>$unm])->get();
        if(count($check)==0)
        {
            $users=new Registers(['register_name'=>$request->get('name')]);
            $users->save();
            //$insertedId = $users->reg_id;
            $unm=$request->input('email');
            
            $pwd=$request->input('password');
            $cpwd=$request->input('cpassword'); 
            $insertedId=registers::max('reg_id');
            //dd($insertedId);
            if($pwd==$cpwd)
            {
            $result=DB::insert("insert into logs(email,password,login_online,login_status,login_type,remember_token,reg_id) values(?,?,?,?,?,?,?)",[$unm,$pwd,0,0,1,'null',$insertedId]);
            return view('logins.login');
            }
            else
            {
                echo"failed";
            }
        }
    }


    public function designerstore(Request $request)
    {
        $unm=$request->input('email');
       // $phone=$request->input('phone');
        $check=DB::table('logs')->where(['email'=>$unm])->get();
        if(count($check)==0)
        {
            $users=new Registers(['register_name'=>$request->get('name'),'register_phone'=>$request->get('phone')]);
            $users->save();
            //$insertedId = $users->reg_id;
            $unm=$request->input('email');
            $pwd=$request->input('password');
            $cpwd=$request->input('cpassword'); 
            //$cpwd=$request->input('phone');
            $insertedId=registers::max('reg_id');
            //dd($insertedId);
            if($pwd==$cpwd)
            {
            $result=DB::insert("insert into logs(email,password,login_online,login_status,login_type,remember_token,reg_id) values(?,?,?,?,?,?,?)",[$unm,$pwd,0,0,2,'null',$insertedId]);
            return view('logins.login');
            }
            else
            {
                echo"failed";
            }
        }
    }

    
    public function distributorstore(Request $request)
    {
        $unm=$request->input('email');
       // $phone=$request->input('phone');
        $check=DB::table('logs')->where(['email'=>$unm])->get();
        if(count($check)==0)
        {
            $users=new Registers(['register_name'=>$request->get('name'),'register_phone'=>$request->get('phone'),'register_company_name'=>$request->get('companyname')]);
            $users->save();
            //$insertedId = $users->reg_id;
            $unm=$request->input('email');
            $pwd=$request->input('password');
            $cpwd=$request->input('cpassword'); 
            //$cpwd=$request->input('phone');
            $insertedId=registers::max('reg_id');
            //dd($insertedId);
            if($pwd==$cpwd)
            {
            $result=DB::insert("insert into logs(email,password,login_online,login_status,login_type,remember_token,reg_id) values(?,?,?,?,?,?,?)",[$unm,$pwd,0,0,3,'null',$insertedId]);
            return view('logins.login');
            }
            else
            {
                echo"failed";
            }
        }
    }
    public function customer(Request $request,$reg_id)
    {
        $request->session()->put('reg_id',$reg_id); 
        return view('admin.customereport');

    }


    public function update_status(Request $request,$id)
    {
        
        $log=DB::table('logs')->where('id', $id)->first();
        
        $status=$log->login_status;
        
        if($status==0)
        {
            DB::table('logs')->where('id', $id)->update(['login_status' => 1]);
        }
        if($status==1)
        {
            DB::table('logs')->where('id', $id)->update(['login_status' => 0]);

        }
       //return view('admin.customer_report');
        return redirect()->back() ->with('alert', 'Updated successfully!');
    }

    public function designer(Request $request,$reg_id)
    {
        $request->session()->put('reg_id',$reg_id); 
        return view('admin.designereport');

    }

    public function update_designer_status(Request $request,$id)
    {
        
        $log=DB::table('logs')->where('id', $id)->first();
        
        $status=$log->login_status;
        
        if($status==0)
        {
            DB::table('logs')->where('id', $id)->update(['login_status' => 1]);
        }
        if($status==1)
        {
            DB::table('logs')->where('id', $id)->update(['login_status' => 0]);

        }
       //return view('admin.customer_report');
        return redirect()->back() ->with('alert', 'Updated successfully!');
    }


    public function distributor(Request $request,$reg_id)
    {
        $request->session()->put('reg_id',$reg_id); 
        return view('admin.distributoreport');

    }

    public function update_distributor_status(Request $request,$id)
    {
        
        $log=DB::table('logs')->where('id', $id)->first();
        
        $status=$log->login_status;
        
        if($status==0)
        {
            DB::table('logs')->where('id', $id)->update(['login_status' => 1]);
        }
        if($status==1)
        {
            DB::table('logs')->where('id', $id)->update(['login_status' => 0]);

        }
       //return view('admin.customer_report');
        return redirect()->back() ->with('alert', 'Updated successfully!');
    }

   
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
