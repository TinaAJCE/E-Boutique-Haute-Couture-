<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use DB;
use App\Registers;
use App\ProductsCategory;
use App\Products;
use App\ProductsImages;
use App\Fabrics;
use App\AdditionalFeatures;
use App\Cart;
use App\RequestDesigner;
use Validator;
class  RequestDesignerController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    public function designer_request(Request $request)
    {
        //dd($request);
        $product_id=$request->input('product_id');
        $stock=$request->input('product_stock');

        $reg_id=$request->input('reg_id');
        // dd($reg_id);
        $designer_id=$request->input('designer');
        $product_color=$request->input('product_color');
       
        $unit_price=$request->input('product_price');
      
        $qty=$request->input('qty');

        $tot_amt=$request->input('result');
        
       
        $letter_size_id=$request->input('size');
        $bs_id=$request->input('b_size');
        $n_id=$request->input('n_size');
        $h_id=$request->input('h_size');
        $l_id=$request->input('l_size');
        $fab_id=$request->input('fabs');
            
            $designer=new RequestDesigner(['reg_id'=>$reg_id,'designer_id'=>$designer_id,'product_id'=>$product_id,'product_color'=>$product_color,'unit_price'=>$unit_price,'quantity'=>$qty,'total_amount'=>$tot_amt,'letter_size_id'=>$letter_size_id,'bs_id'=>$bs_id,'n_id'=>$n_id,'h_id'=>$h_id,'l_id'=>$l_id,'fab_id'=>$fab_id,'status'=>1,'checked'=>0,]);
            // dd('polich');
            $designer->save();

            $id=RequestDesigner::max('rtd_id');

            $rules = [];


            foreach($request->input('name') as $key => $value) {
                $rules["name.{$key}"] = 'required';
            }
    
    
            $validator = Validator::make($request->all(), $rules);
    
    
            if ($validator->passes()) {
    
    
                foreach($request->input('name') as $key => $value) {
                    AdditionalFeatures::create(['rtd_id'=>$id,'features'=>$value]);
                }
                
                return redirect()->back() ->with('alert', 'Added to cart successfully!');
               // return response()->json(['success'=>'done']);
            }
    
    
            return response()->json(['error'=>$validator->errors()->all()]);
               
            //dd('success');
            
               // return redirect()->back() ->with('alert', 'Added the product successfully!');
    }
    public function cart_view(Request $request,$reg_id)
    {
        $request->session()->put('reg_id',$reg_id); 
        return view('customer.cart');
        // $sql=DB::table('carts')->where('reg_id',$reg_id)->where('status',1)->get();
        // dd($sql);
    }
    public function rtd_view(Request $request,$reg_id)
    {
        $request->session()->put('reg_id',$reg_id); 
        return view('customer.request_to_designer');
        // $sql=DB::table('carts')->where('reg_id',$reg_id)->where('status',1)->get();
        // dd($sql);
    }
    public function delete_from_design_request(Request $request,$rtd_id,$product_id)
    {   
        
        
        DB::table('additional_features')->where('rtd_id', '=', $rtd_id)->delete();

        DB::table('request_designers')->where('product_id', '=', $product_id)->where('rtd_id', '=', $rtd_id)->delete();
        // dd('deleted');
        return redirect()->back();
    }
    public function trial(Request $request,$product_id)
    {
        $request->session()->put('product_id',$product_id); 
        return view('customer.trial_once'); 
    }
        
}

