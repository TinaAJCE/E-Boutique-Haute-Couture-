<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Registers;
use App\Cart;
use App\CardDetails;
use App\ProductsCategory;
use App\Products;
use App\ProductsImages;
use App\Fabrics;
use App\Bank;
use App\AdditionalFeatures;
class CardDetailsController extends Controller
{
    public function card_payment(Request $request)
    {
        $order_id=$request->input('order_id');
        $g_total=$request->input('g_total');
        $email=$request->input('email');
        $reg_id=$request->input('reg_id');
        $bank_id=$request->input('bank_id');
        $card_holder_name=$request->input('card_name');
        $card_number=$request->input('ccn');
        $card_type=$request->input('payment');
        $cvv=$request->input('cvv');
        $card_expiry_year=$request->input('year');
        $card_expiry_monthr=$request->input('month');
        $status= 1;

       

        $card=DB::table('card_details')->where(['card_number'=>$card_number,'card_type'=>$card_type,'cvv'=>$cvv])->first();
        if(count($card)==0)
        {
           // return view('customer.cart');
            return view('customer.payment')->with('successMsg','Invalid Card Details .');

        }
        else
        {
            //$carddetails=new CardDetails(['reg_id'=>$reg_id,'bank_id'=>$bank_id,'card_holder_name'=>$card_holder_name,'card_type'=>$card_type,'cvv'=>$cvv,'card_expiry_month'=>$card_expiry_month,'card_expiry_year'=>$card_expiry_year,'status'=>$status]);
                    
            //$carddetails->save();
            //$a=DB::table('banks')->where('email',$email)->first();
                 $g=$card->card_balance;
                    $total=$g - $g_total;
//                    dd($total);
                $b=DB::table('banks')->where('email','tinajose1996@gmail.com')->first();
                    $c=$b->balance_amount;
                    $d=$c + $g_total;
  //                  dd($d);
            
            DB::table('card_details')->where('card_number', $card_number)->update(['card_balance' => $total]);
            DB::table('banks')->where('email', $b->email)->update(['balance_amount' => $d]);
            DB::table('carts')->where('status', 1)->update(['status' => 0,'checked'=> 1]);
            DB::table('orders')->where('order_id',$order_id)->where('status', 1)->update(['status' => 0,'checked'=> 1]);
            DB::table('deliverydetails')->where('status', 1)->update(['status' => 0]);
            $e=DB::table('check_orders')->where('order_id',$order_id)->get();
            foreach($e as $i)
            {
                $products=DB::table('products')->where('product_id',$i->product_id)->first();
                $stock=$products->product_stock - $i->quantity;
                //dd($stock);
                DB::table('products')->where('product_id',$i->product_id)->update(['product_stock'=>$stock]);
            }
            return view('customer.customer')->with('successMsg','Your Order Has Been Placed Successfully...Please Track your Order .');
        }
        
    }
    public function dd_card_payment(Request $request)
    {
        $rtd_id=$request->input('rtd_id');
        $g_total=$request->input('g_total');
        $email=$request->input('email');
        $reg_id=$request->input('reg_id');
        $bank_id=$request->input('bank_id');
        $card_holder_name=$request->input('card_name');
        $card_number=$request->input('ccn');
        $card_type=$request->input('payment');
        $cvv=$request->input('cvv');
        $card_expiry_year=$request->input('year');
        $card_expiry_monthr=$request->input('month');
        $status= 1;

       

        $card=DB::table('card_details')->where(['card_number'=>$card_number,'card_type'=>$card_type,'cvv'=>$cvv])->first();
        if(count($card)==0)
        {
           // return view('customer.cart');
            return view('customer.customer_payment')->with('successMsg','Invalid Card Details .');

        }
        else
        {
            //$carddetails=new CardDetails(['reg_id'=>$reg_id,'bank_id'=>$bank_id,'card_holder_name'=>$card_holder_name,'card_type'=>$card_type,'cvv'=>$cvv,'card_expiry_month'=>$card_expiry_month,'card_expiry_year'=>$card_expiry_year,'status'=>$status]);
                    
            //$carddetails->save();
            //$a=DB::table('banks')->where('email',$email)->first();
                 $g=$card->card_balance;
                    $total=$g - $g_total;
//                    dd($total);
                $b=DB::table('banks')->where('email','tinajose1996@gmail.com')->first();
                    $c=$b->balance_amount;
                    $d=$c + $g_total;
  //                  dd($d);
            
            DB::table('card_details')->where('card_number', $card_number)->update(['card_balance' => $total]);
            DB::table('banks')->where('email', $b->email)->update(['balance_amount' => $d]);
            // DB::table('carts')->where('status', 1)->update(['status' => 0,'checked'=> 1]);
            DB::table('orders')->where('status', 1)->update(['status' => 0,'checked'=> 1]);
            DB::table('deliverydetails')->where('status', 1)->update(['status' => 0]);
            DB::table('request_designers')->where('rtd_id',$rtd_id)->update(['checked'=>'paid_by_card']);
            return view('customer.customer')->with('successMsg','Your Order Has Been Placed Successfully...Please Track your Order .');
        }
        
    

    }

}
