<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Deliverydetails;
class DeliverydetailsController extends Controller
{
    public function add_delivery_address(Request $request)
    {
        $reg_id=$request->input('reg_id');
        $order_id=$request->input('order_id');
        $address=$request->input('address');
        $payment=$request->input('payment');
        // dd($payment);
        $pincode=$request->input('pincode');

        $status=1;
        
        $address=new Deliverydetails(['reg_id'=>$reg_id,'order_id'=>$order_id,'address'=>$address,'payment_mode'=>$payment,'pincode'=>$pincode,'status'=>$status,]);
        $address->save();
        
        if($payment=='card')
        {
            $request->session()->put('order_id',$order_id);
            // $request->session()->put('rtd_id',$rtd_id);
        return view('customer.payment');
        }
        else if($payment=='cash')
        {
             DB::table('carts')->where('status', 1)->update(['status' => 0,'checked'=> 0]);
            DB::table('orders')->where('status', 1)->update(['status' =>0,'checked'=> 0]);
            DB::table('deliverydetails')->where('status', 1)->update(['status' => 0]);
            $request->session()->put('order_id',$order_id);
             

            return view('customer.deliveryreport');
        }


    }
    public function add_designer_delivery_address(Request $request)
    {
        $rtd_id=$request->input('rtd_id');

        $reg_id=$request->input('reg_id');
        $order_id=$request->input('order_id');
        $address=$request->input('address');
        $payment=$request->input('payment');
        // dd($payment);
        $pincode=$request->input('pincode');

        $status=1;
        
        $address=new Deliverydetails(['reg_id'=>$reg_id,'order_id'=>$order_id,'address'=>$address,'payment_mode'=>$payment,'pincode'=>$pincode,'status'=>$status,]);
        $address->save();
        
        if($payment=='card')
        {
            $request->session()->put('order_id',$order_id);
            $request->session()->put('rtd_id',$rtd_id);


        return view('customer.customer_payment');
        }
        else if($payment=='cash')
        { 
            // DB::table('carts')->where('status', 1)->update(['status' => 0,'checked'=> 0]);
            DB::table('orders')->where('order_id', $order_id)->update(['status' =>0,'checked'=> 0]);
            DB::table('deliverydetails')->where('status', 1)->where('order_id',$order_id)->update(['status' => 0]);
            DB::table('request_designers')->where('rtd_id',$rtd_id)->update(['checked'=>'paid_by_cash']);
            $request->session()->put('order_id',$order_id);
             
            $request->session()->put('rtd_id',$rtd_id);

            return view('customer.customer_delivery_report');
        }


    }

}
