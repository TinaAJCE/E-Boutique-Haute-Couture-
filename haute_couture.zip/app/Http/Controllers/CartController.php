<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use DB;
use App\Registers;
use App\ProductsCategory;
use App\Products;
use App\ProductsImages;
use App\Fabrics;
use App\AdditionalFeatures;
use App\Cart;
use Validator;
class CartController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    public function add_to_cart(Request $request)
    {
        
        $product_id=$request->input('product_id');
        $product_color=$request->input('product_color');
        $check=DB::table('carts')->where(['product_id'=>$product_id,'product_color'=>$product_color,'status'=>1,'checked'=>0])->get();
        if(count($check)==0)
        {
                $stock=$request->input('product_stock');

                $reg_id=$request->input('reg_id');
                $product_color=$request->input('product_color');
            
                $unit_price=$request->input('product_price');
            
                $qty=$request->input('qty');

                $tot_amt=$request->input('result');
                
                    
                    $cart=new Cart(['reg_id'=>$reg_id,'product_id'=>$product_id,'product_color'=>$product_color,'unit_price'=>$unit_price,'quantity'=>$qty,'total_amount'=>$tot_amt,'status'=>1,'checked'=>0,]);
                    
                    $cart->save();
                    return redirect()->back()->with('alert', 'Added the product successfully!');
        }
        else
        {
            $qty=$request->input('qty');
            $tot_amt=$request->input('result');
            $sy= DB::table('carts')->select('quantity','total_amount')->where('product_id', $product_id)->get();
            foreach($sy as $a)
            {
                $qty=$a->quantity + $qty;
                $tot_amt=$a->total_amount + $tot_amt;

                DB::table('carts')->where('product_id', $product_id)->update(['quantity' => $qty,'total_amount'=> $tot_amt]);
                return redirect()->back()->with('alert', 'Added the product successfully!');

            }
        }
    }
    public function cart_view(Request $request,$reg_id)
    {
        // dd($reg_id);
        $request->session()->put('reg_id',$reg_id); 
        return view('customer.cart');
        // $sql=DB::table('carts')->where('reg_id',$reg_id)->where('status',1)->get();
        // dd($sql);
    }
    public function delete_from_cart(Request $request,$product_id,$product_color)
    {
        DB::table('carts')->where('product_id', '=', $product_id)->where('product_color', '=',$product_color)->delete();
        
        return redirect()->back();
    }

    public function update_cart(Request $request)
    {
      
        $cart_id=$request->input('cart_id');
        $product_id=$request->input('product_id');
        $unit_price=$request->input('product_price');
        $quantity=$request->input('quantity');
        
        $total_amount=$request->input('total_amount');
        DB::table('carts')->where('cart_id', $cart_id)->update(['quantity' => $quantity,'total_amount'=> $total_amount]);

        // DB::table('carts')->where('product_id', $product_id)->where('cart_id',$cart_id)->update(['quantity' => $quantity,'total_amount'=> $total_amount]);
        return("ok");
    }
    public function request_from_customer(Request $request)
    {
        // $request->session()->put('reg_id',$reg_id);
        return view('admin.customer_requests');
    }
}

