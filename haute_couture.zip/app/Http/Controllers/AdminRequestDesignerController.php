<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\AdminRequestDesigner;
use App\Registers;
use App\Logs;
class AdminRequestDesignerController extends Controller
{
    public function admin_request_designer(Request $request)
    {
        //return $request->user_email;
        $o_id=$request->input('order_id');

        $co_id=$request->input('check_cart');
        $product_id=$request->input('product_id');
        $uemail=$request->input('user_email');
        //$product_id=$request->input('product_name');
        $pcolor=$request->input('product_color');
        $qty=$request->input('quantity');
        $lsize=$request->input('letter_size');
        $fname=$request->input('fname');
        $designer=$request->input('designer');
        //return($co_id);
        DB::table('check_orders')->where('status', 1)->where('co_id',$co_id)->update(['status' => 0]);

       $adrd=new AdminRequestDesigner(['order_id'=>$o_id,'reg_id'=>$uemail,'designer_id'=>$designer,'product_id'=>$product_id,'product_color'=>$pcolor,'letter_size_id'=>$lsize,'fab_id'=>$fname,'quantity'=>$qty,'status'=>1,'checked'=>0]);
       $adrd->save();
       
       //DB::table('carts')->where('product_id', $product_id)->update(['quantity' => $qty,'total_amount'=> $tot_amt]);
       // DB::delete('update check_orders set status=0 where = ?',)
       echo($adrd);
    }
}
