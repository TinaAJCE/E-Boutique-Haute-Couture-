<?php

namespace App\Http\Controllers;
use Session;
use Redirect;
use Auth;

use Illuminate\Http\Request;
use DB;
use App\Registers;
//use Illuminate\Contracts\Auth\Guard as GuardContract;
class LogsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function login(Request $request)
    {
        session_start();
        $unm=$request->input('email');
        $pwd=$request->input('password');
        //$cpwd=$request->input('cpassword');
        
        $checkLogin1=DB::table('logs')->where(['email'=>$unm,'password'=>$pwd,'login_type'=>1,'login_status'=>1])->get();//Customer
        $checkLogin2=DB::table('logs')->where(['email'=>$unm,'password'=>$pwd,'login_type'=>2,'login_status'=>1])->get();//Designer
        $checkLogin3=DB::table('logs')->where(['email'=>$unm,'password'=>$pwd,'login_type'=>3,'login_status'=>1])->get();//Distributor
        $checkLogin4=DB::table('logs')->where(['email'=>$unm,'password'=>$pwd,'login_type'=>0,'login_status'=>1])->get();//admin

            //dd($unm);
            //dd($pwd);
            foreach($checkLogin4 as $object)
            {
                $id=$object->id;
                $email=$object->email;
                $reg_id=$object->reg_id;
            }
        




       if(count($checkLogin1)>0)
        {
            
            $request->session()->put('email',$unm);
            return view('customer.customer');
            
        }
        
        else if(count($checkLogin2)>0)
        {
            

            $request->session()->put('email', $unm);
            return view('designer.designer');
        }
        
        if(count($checkLogin3)>0)
        {
           

            $request->session()->put('email', $unm);
            return view('distributor.distributor');
        }
        
        else if(count($checkLogin4)>0)
        {
            
           

           $request->session()->put('email', $unm);
           
            return view('admin.admin');
        } 
        else
        {
            return redirect()->back() ->with('alert', 'Inavalid Username or password! OR your account is in verification stage');
        }
        
    }

    public function profile(Request $request,$reg_id){ 
        $request->session()->put('reg_id',$reg_id); 
        return view('admin.profile');
     }

     public function profile_edit(Request $request,$reg_id){ 
        $request->session()->put('reg_id',$reg_id); 
        
        $edit = DB::table('registers')->where('reg_id', $reg_id);
        return view('admin.profile_edit',compact($edit));
     }
     
     public function admin_profile_update(Request $request){ 
       
        $reg_id=$request->input('id');
        $register_name=$request->input('name');
        $register_phone=$request->input('phone');
        $register_company_name=$request->input('company_name');
        
        
        $register_address=$request->input('address');
        $createdat=$request->input('created');
        $updatedat=$request->input('updated');

        // $register_photo=$request->image->getClientOriginalName();
        // $request->image->storeAs('public/upload',$register_photo);
        
        DB::table('registers')->where('reg_id', $reg_id)->update(['register_name' => $register_name,'register_phone' => $register_phone,'register_company_name' => $register_company_name,'register_address' => $register_address]);
       
        return view('admin.profile');
     }
    
    public function index()
    {
        //
    }
    public function designerProducts()
    {
        return view('customer.designerProducts');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
    public function logout(Request $request) {
        //session_start();
        //session_destroy();
        //session()->flush();
        //return redirect('/login1');
        session_start();
        session_destroy();
        return redirect('/login1');

       // header("location:login.php");

		exit;
        //Auth::logout(); // logout user
        //Session::flush();
        //Redirect::back();
        //return Redirect::to('/login1'); //redirect back to login
    }
    public function view_customer_profile(Request $request,$reg_id)
    {
        $request->session()->put('reg_id', $reg_id);
        return view('customer.profile_view');  
    }
}
