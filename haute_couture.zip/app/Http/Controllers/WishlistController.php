<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Wishlist;
class WishlistController extends Controller
{
    public function wishlist(Request $request)
    {
        
        $reg_id=$request->input('reg_id');
        $product_id=$request->input('product_id');
        $img_url=$request->input('wishlist');



        $check=DB::table('wishlists')->where(['product_id'=>$product_id])->get();
       
       $product=DB::table('products')->where(['product_id'=>$product_id])->first();

        if(count($check)==0)
        {
        $wishlist = new Wishlist;

        $wishlist->reg_id = $reg_id;
        $wishlist->product_id = $product_id;
        $wishlist->status=1;

  
        $wishlist->save();
        return back()->with('success','Item, '. $product->product_name.' Added to your wishlist.');
        
         }
        else if(count($check)!=0)
        {
            foreach($check as $wishlist)
            {
            $id=$wishlist->id;
            DB::table('wishlists')->delete($id);
            
            return back()->with('info',$product->product_name.'  removed from the wishlist!');
              
            }      
        }

    }
    public function wishlist_products(Request $request,$reg_id)
    {
        $request->session()->put('reg_id',$reg_id); 
        return view('customer.wishlist'); 
    }   
    public function wishlist_delete(Request $request,$product_id)
    {
        DB::table('wishlists')->where('product_id', '=', $product_id)->delete();
        // dd('deleted');
        return redirect()->back();
    }      

}
