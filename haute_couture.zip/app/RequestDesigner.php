<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RequestDesigner extends Model
{
    public $fillable=['reg_id','designer_id','product_id','product_color','unit_price','quantity','total_amount','letter_size_id','bs_id','n_id','h_id','l_id','fab_id','status','checked'];

}
