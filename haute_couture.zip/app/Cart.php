<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cart extends Model
{
    public $fillable=['reg_id','product_id','product_color','unit_price','quantity','total_amount','status','checked'];
}
