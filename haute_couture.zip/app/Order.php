<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    public $fillable=['reg_id','net_amount','tax','discount','grand_total','order_date','delivery_expected','status','checked'];
}
