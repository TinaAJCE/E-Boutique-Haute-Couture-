<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CardDetails extends Model
{
    public $fillable=['card_holder_name','card_number','card_type','cvv','card_expiry_month','card_expiry_year','card_balance','status'];

}
