<!--
	Author: W3layouts
	Author URL: http://w3layouts.com
	License: Creative Commons Attribution 3.0 Unported
	License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html lang="zxx">

<head>
	
	<!-- Meta tag Keywords -->
   
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<!--<meta name="keywords" content="Wedding Ceremony web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design"
	/>-->
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<script type="application/x-javascript">
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<!--// Meta tag Keywords -->
	<!-- css files -->
	<link rel="stylesheet" href="css/bootstrap.css" type="text/css" media="all">
	<!-- Bootstrap-Core-CSS -->
	<link rel="stylesheet" href="css/font-awesome.css" type="text/css" media="all">
	<!-- Font-Awesome-Icons-CSS -->
	<link rel="stylesheet" href="css/lightbox.css" type="text/css" media="all">
	<link href="css/easy-responsive-tabs.css" rel="stylesheet" type="text/css" media="all" />
	<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
	<!-- Style-CSS -->
	<!-- //css files -->
	<!-- web fonts -->
	<link href="//fonts.googleapis.com/css?family=Arizonia&amp;subset=latin-ext" rel="stylesheet">
	<link href="//fonts.googleapis.com/css?family=Droid+Sans:400,700" rel="stylesheet">
	<style>
		.emsg{
    		color: red;
		}
		.hidden {
    		 visibility:hidden;
		}
	
</style>

	<!-- //web fonts -->
</head>

<div class="w3l-main" id="home">
		<!--navigation-->
		<div class="header-w3">
			<div class="header-top-agile">
				<div class="social-icons-agileits">
					<ul>
						<!--<li><span class="glyphicon glyphicon-envelope" aria-hidden="true"></span> <a href="mailto:info@example.com">info@example.com</a></li>
						<li><span class="glyphicon glyphicon-earphone" aria-hidden="true"></span> +141 587 426 825</li>-->
					</ul>
				</div>
				<div class="social">
					<!--<ul>
						<li><a href="#" class="link facebook" target="_parent"><span class="fa fa-facebook-square"></span></a></li>
						<li><a href="#" class="link twitter" target="_parent"><span class="fa fa-twitter"></span></a></li>
						<li><a href="#" class="link google-plus" target="_parent"><span class="fa fa-google-plus-square"></span></a></li>
					</ul>-->
				</div>
				<div class="clearfix"></div>
			</div>
			<div class="header-bottom-agile">
				<div class=" navigation">
					<nav class="navbar navbar-default cl-effect-16" id="cl-effect-16">
						<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
						
												
						<a href="" class="nav navbar-nav" style="font-family:Baskerville, 'Palatino Linotype', Palatino, 'Century Schoolbook L', 'Times New Roman', serif; font-size:25px;">Haute Couture</a>
                        
                        
						<div id="navbar" class="navbar-collapse navbar-right collapse hover-effect">
                        
							<ul class="nav navbar-nav">
                            
								<li class="active"><a href="/" data-hover="Home">Home</a></li>
								<li><a href="/login1" data-hover="Login">Login</a></li>
								<!--<li><a href="#about" data-hover="About Us" class="scroll">About Us</a></li>
								<li><a href="#events" data-hover="Events" class="scroll">Events</a></li>-->
								<li><a href="#customer" data-hover="Customer" class="scroll">Customer</a></li>
								<li><a href="#designer" data-hover="Designer" class="scroll">Designer</a></li>
								<li><a href="#distributor" data-hover="Distributor" class="scroll">Distributor</a></li>
							</ul>
						</div>
					</nav>
				</div>
				<!--<div class="w3ls_search">
					<div class="cd-main-header">
						<ul class="cd-header-buttons">
							<li><a class="cd-search-trigger" href="#cd-search"> <span></span></a></li>
						</ul>
						 cd-header-buttons
					</div>
					<div id="cd-search" class="cd-search">
						<form action="#" method="post">
							<input name="Search" type="search" placeholder="Search..." required>
						</form>
					</div>
				</div> -->
				<div class="clearfix"></div>
			</div>
		</div>
        
		
	</div>
	<!-- about -->
	
	<div class="banner" id="customer">
			<div data-vide-bg="video/marriage">
				<div class="center-container">
					<div class="banner-text">
						<div id="top" class="callbacks_container">
							<br><br><br><br><br>
							<div class="main-agileinfo">
								<div class="agileits-top">
								
									<form action="/reg" method="post" id="regcust" autocomplete="off" novalidate>
										@csrf
										<input type="hidden" name="_token" value="{{csrf_token()}}">
										<i class="fa fa-user-o" aria-hidden="true"></i>
										<input class="text" type="text" id="name" name="name"  pattern="[A-Za-z]" placeholder="Name" autocomplete="off">
										<label id="error_name" style="color: red;"></label>
									

									
										<input class="text email"  type="email" name="email" id="email" autocomplete="off" onblur="myFunction()" placeholder="Email" onblur="myFunction()" onchange="Validem();">
										<label id="error_email" style="color: red;"></label>
										<script>
										var input = document.getElementById('email');

										input.onkeyup = function(){
    								this.value = this.value.toLowerCase();
										}
										</script>
										<input class="text" type="password" name="password" id="pswd" placeholder="Password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}">
										<label id="error_pswd" style="color: red;"></label>
										<input class="text w3lpass" type="password" name="cpassword" placeholder="Confirm Password" required>
										<div class="wthree-text">
											<br>  
											<!-- <label class="anim">
												<input type="checkbox" class="checkbox" required>
												<span>I Agree To The Terms & Conditions</span> 
											</label>   -->
											<div class="clear"> </div>
										</div> 
										<br>  
										<input type="submit" id="submit-email" value="Register Customer Here...">
										
									</form>
																 
							</div>
								</div>
				       <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
						</div>
					</div>
				</div>
			</div>
			<div class="we-po-head">
				<img src="images/m1.png" alt=" ">
			</div>
		</div>
		
		<div class="banner" id="designer">
			<div data-vide-bg="video/marriage">
				<div class="center-container">
					<div class="banner-text">
						<div id="top" class="callbacks_container">
							<br><br><br><br><br>
							<div class="main-agileinfo">
								<div class="agileits-top"> 
									<form action="/designReg" method="post" novalidate> 
										@csrf
										<input type="hidden" name="_token" value="{{csrf_token()}}">
										<i class="fa fa-user-o" aria-hidden="true"></i>
										<input class="text" type="text" id="dname" name="name"  pattern="[A-Za-z]" placeholder="Name"  autocomplete="off" required>
										
										<label id="derror_name" style="color: red;"></label>
										<input class="text email"  type="email" name="email" id="demail" autocomplete="off" placeholder="Email" onblur="myFunction()" onchange="Validem();" required>
										<label id="derror_email" style="color: red;"></label>	
										<script>
										var input = document.getElementById('demail');

										input.onkeyup = function(){
    								this.value = this.value.toLowerCase();
										}
										</script>									
										<input class="text" type="password" name="password" id="dpswd" placeholder="Password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" required>
										<label id="derror_pswd" style="color: red;"></label>
										<input class="text w3lpass" type="password" name="cpassword" placeholder="Confirm Password" required>
										<input class="text" type="text" name="phone" id="dphone" maxlength="10" placeholder="Phone Number"  required>
										<label id="derror_phone" style="color: red;"></label>
										<div class="wthree-text">
											<br>  
											<!-- <label class="anim">
												<input type="checkbox" class="checkbox" required>
												<span>I Agree To The Terms & Conditions</span> 
											</label>   -->
											<div class="clear"> </div>
										</div> 
										<br>  
										<input type="submit" id="dsubmit-email" value="Register Designer Here...">
									</form>
									
								</div>	
								</div>

								<br><br><br><br><br><br><br><br><br><br><br><br>	
						</div>
					</div>
				</div>
			</div>
			<div class="we-po-head">
				<img src="images/m1.png" alt=" ">
			</div>
		</div>

		<div class="banner" id="distributor">
			<div data-vide-bg="video/marriage">
				<div class="center-container">
					<div class="banner-text">
						<div id="top" class="callbacks_container">
							<br><br><br><br><br>
							<div class="main-agileinfo">
								<div class="agileits-top"> 
									<form action="/distributorReg" method="post" novalidate>
										@csrf
										<input type="hidden" name="_token" value="{{csrf_token()}}"> 
										<i class="fa fa-user-o" aria-hidden="true"></i>
										<input class="text" type="text" name="name" id="diename" placeholder="Name" required>
										<label id="dierror_name" style="color: red;"></label>
										<input class="text email"  type="email" name="email" id="diemail"autocomplete="off" placeholder="Email" onblur="myFunction()" onchange="Validem();" required>
										<label id="dierror_email" style="color: red;"></label>	
										<script>
										var input = document.getElementById('diemail');

										input.onkeyup = function(){
    								this.value = this.value.toLowerCase();
										}
										</script>
										<input class="text" type="password" name="password" id="dipswd" placeholder="Password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" required>
										<label id="dierror_pswd" style="color: red;"></label>
										<input class="text w3lpass" type="password" name="cpassword" placeholder="Confirm Password" required>
										<input class="text" type="text" name="phone" id="diphone" maxlength="10" placeholder="Phone Number"  required>
										<label id="dierror_phone" style="color: red;"></label>
										<input class="text" type="text" name="companyname" id="diecompany" placeholder="Company Name" required>
										<label id="dierror_comp" style="color: red;"></label>
										<div class="wthree-text">
											<br>  
											<!-- <label class="anim">
												<input type="checkbox" class="checkbox" required>
												<span>I Agree To The Terms & Conditions</span> 
											</label>   -->
											<div class="clear"> </div>
										</div> 
										<br>  
										<input type="submit" id="disubmit-email" value="Distributor Register Here...">
									</form>
								</div>	 
							</div>
							<br><br><br><br><br><br><br><br><br><br><br><br>	
						</div>
					</div>
				</div>
			</div>
			<div class="we-po-head">
				<img src="images/m1.png" alt=" ">
			</div>
		</div>
		

	


	<!-- js -->
	<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.js"></script>
	<!-- Necessary-JavaScript-File-For-Bootstrap -->
	<!-- //js -->
	<!--  light box js -->
	<script src="js/lightbox-plus-jquery.min.js">
	</script>
	<!-- //light box js-->

	<!-- video-js -->
	<script src="js/jquery.vide.min.js"></script>
	<!-- //video-js -->


	<!-- Baneer-js -->
	<!--responsive slider-->
	<script src="js/responsiveslides.min.js"></script>
	<!--//responsive slider-->

	<!--banner Slider starts Here-->
	<script>
	function myFunction() {
  var x = document.getElementById("email");
  x.value = x.value.toLowerCase();
}
		// You can also use "$(window).load(function() {"
		$(function () {
			// Slideshow 3
			$("#slider3").responsiveSlides({
				auto: true,
				pager: false,
				nav: true,
				speed: 500,
				namespace: "callbacks",
				before: function () {
					$('.events').append("<li>before event fired.</li>");
				},
				after: function () {
					$('.events').append("<li>after event fired.</li>");
				}
			});

		});
	</script>


<script>


$("#name").keyup(function(){
     var name = $("#name").val();
     var filter = /[a-zA-z]/;
     if (!filter.test(name)) {
       //alert('Please provide a valid email address');
       $("#error_name").text(name+" is not a valid name");
      name.focus;
       //return false;
    } else {
        $("#error_name").text("");
    }
 });

 $("#submit-email").click(function(){
    var name = $("#name").val();
    var filter = /[a-zA-Z]/;
    if (!filter.test(name)) {
       alert('The name is a mandatory field');
       $("#name").focus();
       return false;
    } else {
       
    }
 });
 
 </script>






	<script>
function myFunction() {
  var x = document.getElementById("email");
  x.value = x.value.toLowerCase();
}

$("#email").keyup(function(){
     var email = $("#email").val();
     var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
     if (!filter.test(email)) {
       //alert('Please provide a valid email address');
       $("#error_email").text(email+" is not a valid email");
       email.focus;
       //return false;
    } else {
        $("#error_email").text("");
    }
 });

 $("#submit-email").click(function(){
    var email = $("#email").val();
    var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    if (!filter.test(email)) {
       alert('Email:Mandatory Field');
       $("#email").focus();
       return false;
    } else {
       
    }
 });

 </script>


<script>
function myFunction() {
  var x = document.getElementById("demail");
  x.value = x.value.toLowerCase();
}

$("#demail").keyup(function(){
     var demail = $("#demail").val();
     var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
     if (!filter.test(demail)) {
       //alert('Please provide a valid email address');
       $("#derror_email").text(demail+" is not a valid email");
       demail.focus;
       //return false;
    } else {
        $("#derror_email").text("");
    }
 });

 $("#dsubmit-email").click(function(){
    var demail = $("#demail").val();
    var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    if (!filter.test(demail)) {
       alert('Email:Mandatory Field');
       $("#demail").focus();
       return false;
    } else {
       
    }
 });
 

 </script>
<!--distributor-->

<script>
function myFunction() {
  var x = document.getElementById("diemail");
  x.value = x.value.toLowerCase();
}

$("#diemail").keyup(function(){
     var diemail = $("#diemail").val();
     var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
     if (!filter.test(diemail)) {
       //alert('Please provide a valid email address');
       $("#dierror_email").text(diemail+" is not a valid email");
       diemail.focus;
       //return false;
    } else {
        $("#dierror_email").text("");
    }
 });

 $("#disubmit-email").click(function(){
    var diemail = $("#diemail").val();
    var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    if (!filter.test(diemail)) {
       alert('Email:Mandatory Field');
       $("#diemail").focus();
       return false;
    } else {
       
    }
 });
 

 </script>
<script>
	$("#pswd").keyup(function(){
     var pswd = $("#pswd").val();
     var filter =  /(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}/;
     if (!filter.test(pswd)) {
       //alert('Please provide a valid email address');
       $("#error_pswd").text(pswd+" is not a valid Password(matches a string of six or more characters(1 number[0-9],1 upper and lower case letters))");
       pswd.focus;
       //return false;
    } else {
        $("#error_pswd").text("");
    }
 });

 $("#submit-email").click(function(){
    var pswd = $("#pswd").val();
    var filter = /(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}/;
    if (!filter.test(pswd)) {
       alert('Password:Mandatory Field');
       $("#pswd").focus();
       return false;
    } else {
       
    }
 });
 
</script>



	<!--//End-slider-script-->

	<!-- //Baneer-js -->
	<!-- search-jQuery -->
	<script src="js/main.js"></script>
	<!-- //search-jQuery -->

	<!-- required-js-files-->
	<link href="css/owl.carousel.css" rel="stylesheet">
	<script src="js/owl.carousel.js"></script>
	<script>
		$(document).ready(function () {
			$("#owl-demo").owlCarousel({
				items: 1,
				itemsDesktop: [768, 4],
				itemsDesktopSmall: [414, 3],
				lazyLoad: true,
				autoPlay: true,
				navigation: true,

				navigationText: false,
				pagination: true,

			});

		});
	</script>
	<!--//required-js-files-->

	<!-- script for responsive tabs -->
	<script src="js/easy-responsive-tabs.js"></script>
	<script>
		$(document).ready(function () {
			$('#horizontalTab').easyResponsiveTabs({
				type: 'default', //Types: default, vertical, accordion           
				width: 'auto', //auto or any width like 600px
				fit: true, // 100% fit in a container
				closed: 'accordion', // Start closed if in accordion view
				activate: function (event) { // Callback function if tab is switched
					var $tab = $(this);
					var $info = $('#tabInfo');
					var $name = $('span', $info);
					$name.text($tab.text());
					$info.show();
				}
			});
			$('#verticalTab').easyResponsiveTabs({
				type: 'vertical',
				width: 'auto',
				fit: true
			});
		});
	</script>
	<!-- start-smooth-scrolling -->
	<script type="text/javascript" src="js/move-top.js"></script>
	<script type="text/javascript" src="js/easing.js"></script>
	<script type="text/javascript">
		jQuery(document).ready(function ($) {
			$(".scroll").click(function (event) {
				event.preventDefault();

				$('html,body').animate({
					scrollTop: $(this.hash).offset().top
				}, 1000);
			});
		});
	</script>
	<!-- //end-smooth-scrolling -->
	<!-- smooth scrolling -->
	<script src="js/SmoothScroll.min.js"></script>
	<!-- //smooth scrolling 
	<script src="{{ asset('js/validate/jquery.js') }}"></script>
    <script src="{{ asset('js/validate/bootstrap.min.js') }}"></script>
    <script src="{{ asset('js/validate/jquery.validate.min.js') }}"></script>
    <script src="{{ asset('js/validate/additional-methods.min.js') }}"></script>
    <script src="../../../js/validations.js"></script>-->




<script>


$("#diename").keyup(function(){
     var diename = $("#diename").val();
     var filter = /([A-Z]{1})([a-z]+{2,})(\s)([A-Z]{1})([a-z]+){2,}/;
     if (!filter.test(diename)) {
       //alert('Please provide a valid email address');
       $("#dierror_name").text(diename+" is not a valid name..Must start with capital letter");
       diename.focus;
       //return false;
    } else {
        $("#dieerror_name").text("");
    }
 });

 $("#disubmit-email").click(function(){
    var diename = $("#diename").val();
    var filter = /([A-Z]{1})([a-z]+{2,})(\s)([A-Z]{1})([a-z]+){2,}/;
    if (!filter.test(diename)) {
       alert('Name: Mandatory Field');
       $("#diename").focus();
       return false;
    } else {
       
    }
 });
 
 </script>

<!--password validfation -->

<script>

 $("#dipswd").keyup(function(){
     var dipswd = $("#dipswd").val();
     var filter =  /(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}/;
     if (!filter.test(dipswd)) {
       //alert('Please provide a valid email address');
       $("#dierror_pswd").text(dipswd+" is not a valid Password(matches a string of six or more characters(1 number[0-9],1 upper and lower case letters))");
       dipswd.focus;
       //return false;
    } else {
        $("#dierror_pswd").text("");
    }
 });

 $("#disubmit-email").click(function(){
    var dipswd = $("#dipswd").val();
    var filter = /(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}/;
    if (!filter.test(dipswd)) {
       alert('Password: Mandatory Field');
       $("#dipswd").focus();
       return false;
    } else {
       
    }
 });
 

 </script>

<!--password verification-->
<script>


$("#diphone").keyup(function(){
     var diphone = $("#diphone").val();
     var filter = /[7-9]{1}[0-9]{9}/;
     if (!filter.test(diphone)) {
       //alert('Please provide a valid email address');
       $("#dierror_phone").text(diphone+" is not a valid Phone number(Format:10 digits)");
       diphone.focus;
       //return false;
    } else {
        $("#dierror_phone").text("");
    }
 });

 $("#disubmit-email").click(function(){
    var diphone = $("#diphone").val();
    var filter =/[7-9]{1}[0-9]{9}/;
    if (!filter.test(diphone)) {
       alert('The phone number :Mandatory Field');
       $("#diphone").focus();
       return false;
    } else {
       
    }
 });
 </script>


<!--company name-->

<script>


$("#dname").keyup(function(){
     var dname = $("#dname").val();
     var filter = /[a-zA-z]/;
     if (!filter.test(dname)) {
       //alert('Please provide a valid email address');
       $("#derror_name").text(dname+" is not a valid name");
       dname.focus;
       //return false;
    } else {
        $("#derror_name").text("");
    }
 });

 $("#dsubmit-email").click(function(){
    var dname = $("#dname").val();
    var filter = /[a-zA-z]/;
    if (!filter.test(dname)) {
       alert('The name : Mandatory Field');
       $("#dname").focus();
       return false;
    } else {
       
    }
 });
 </script>
 <script>
	$("#dpswd").keyup(function(){
     var dpswd = $("#dpswd").val();
     var filter =  /(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}/;
     if (!filter.test(dpswd)) {
       //alert('Please provide a valid email address');
       $("#derror_pswd").text(dpswd+" is not a valid Password(matches a string of six or more characters(1 number[0-9],1 upper and lower case letters))");
      dpswd.focus;
       //return false;
    } else {
        $("#derror_pswd").text("");
    }
 });

 $("#dsubmit-email").click(function(){
    var dpswd = $("#dpswd").val();
    var filter = /(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}/;
    if (!filter.test(dpswd)) {
       alert('The password :Mandatory Field');
       $("#dpswd").focus();
       return false;
    } else {
       
    }
 });
 </script>
 <script>
 $("#dphone").keyup(function(){
     var dphone = $("#dphone").val();
     var filter = /[7-9]{1}[0-9]{9}/;
     if (!filter.test(dphone)) {
       //alert('Please provide a valid email address');
       $("#derror_phone").text(dphone+" is not a valid Phone number(Format:10 digits)");
       dphone.focus;
       //return false;
    } else {
        $("#derror_phone").text("");
    }
 });

 $("#dsubmit-email").click(function(){
    var dphone = $("#dphone").val();
    var filter =/[7-9]{1}[0-9]{9}/;
    if (!filter.test(dphone)) {
       alert('The phone number : Mandatory Field');
       $("#dphone").focus();
       return false;
    } else {
       
    }
 });
 </script>

</body>

</html>