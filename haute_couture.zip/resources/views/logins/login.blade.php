<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->

<!DOCTYPE html>
<html>
<head>
	
	<!-- Meta tag Keywords -->
   
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<!--<meta name="keywords" content="Wedding Ceremony web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design"
	/>-->
	<script type="application/x-javascript">
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<!--// Meta tag Keywords -->
	<!-- css files -->
	<link rel="stylesheet" href="css/bootstrap.css" type="text/css" media="all">
	<!-- Bootstrap-Core-CSS -->
	<link rel="stylesheet" href="css/font-awesome.css" type="text/css" media="all">
	<!-- Font-Awesome-Icons-CSS -->
	<link rel="stylesheet" href="css/lightbox.css" type="text/css" media="all">
	<link href="css/easy-responsive-tabs.css" rel="stylesheet" type="text/css" media="all" />
	<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
	<!-- Style-CSS -->
	<!-- //css files -->
	<!-- web fonts -->
	<link href="//fonts.googleapis.com/css?family=Arizonia&amp;subset=latin-ext" rel="stylesheet">
	<link href="//fonts.googleapis.com/css?family=Droid+Sans:400,700" rel="stylesheet">
	<!-- //web fonts -->
</head>

<div class="w3l-main" id="home">
		<!--navigation-->
		<div class="header-w3">
			<div class="header-top-agile">
				<div class="social-icons-agileits">
					<ul>
						<!--<li><span class="glyphicon glyphicon-envelope" aria-hidden="true"></span> <a href="mailto:info@example.com">info@example.com</a></li>
						<li><span class="glyphicon glyphicon-earphone" aria-hidden="true"></span> +141 587 426 825</li>-->
					</ul>
				</div>
				<div class="social">
					<!--<ul>
						<li><a href="#" class="link facebook" target="_parent"><span class="fa fa-facebook-square"></span></a></li>
						<li><a href="#" class="link twitter" target="_parent"><span class="fa fa-twitter"></span></a></li>
						<li><a href="#" class="link google-plus" target="_parent"><span class="fa fa-google-plus-square"></span></a></li>
					</ul>-->
				</div>
				<div class="clearfix"></div>
			</div>
			<div class="header-bottom-agile" style="background-color:white;">
				<div class=" navigation">
					<nav class="navbar navbar-default cl-effect-16" id="cl-effect-16">
						<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
						
												
						<a href="" class="nav navbar-nav" style="font-family:Baskerville, 'Palatino Linotype', Palatino, 'Century Schoolbook L', 'Times New Roman', serif; font-size:25px;">Haute Couture</a>
                        
                        
						<div id="navbar" class="navbar-collapse navbar-right collapse hover-effect">
                        
							<ul class="nav navbar-nav">
                            
                        <li  class="active"><a href="/" data-hover="Home">Home</a></li>
								<li><a href="/login1" data-hover="Login">Login</a></li>
                        <li><a href="/newuser" data-hover="Registration">Registration</a></li>
								<!--<li><a href="#contact" data-hover="Contact Us" class="scroll">Contact Us</a></li>-->
							</ul>
						</div>
					</nav>
				</div>
				<div class="w3ls_search">
					<div class="cd-main-header">
						<ul class="cd-header-buttons">
							<!--<li><a class="cd-search-trigger" href="#cd-search"> <span></span></a></li>-->
						</ul>
						<!-- cd-header-buttons -->
					</div>
					<div id="cd-search" class="cd-search">
						<form action="#" method="post">
							<input name="Search" type="search" placeholder="Search..." required>
						</form>
					</div>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
               
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Awesome Register Form template Responsive, Login form web template,Flat Pricing tables,Flat Drop downs  Sign up Web Templates, Flat Web Templates, Login sign up Responsive web template, SmartPhone Compatible web template, free web designs for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Custom Theme files -->
<link href="login/css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- //Custom Theme files -->
<!-- web font --> 
<link href="//fonts.googleapis.com/css?family=Poiret+One&amp;subset=cyrillic,latin-ext" rel="stylesheet">
<link href="//fonts.googleapis.com/css?family=Josefin+Sans:100,100i,300,300i,400,400i,600,600i,700,700i&amp;subset=latin-ext" rel="stylesheet">
<!-- //web font -->
</head>
<body data-vide-bg="login/video/awesome">
	<!-- main -->
	
	<div>
		<div class="main-w3layouts center-container">
		<h1>Login</h1>
			<div class="main-agileinfo">
				
				<div class="agileits-top"> 
			
					<form action="/log" method="post"> 
						<input type="hidden" name="_token" value="csrf_token()}}">
						@csrf
						<i class="fa fa-user-o" aria-hidden="true"></i>
						<!--<input class="text" type="text" name="Username" placeholder="Username" required>-->
						<input class="text email" type="email" name="email" id="email" placeholder="Email" onblur="myFunction()" onchange="Validem();" required>
						<label id="error_email" style="color: red;"></label>
						<input class="text" type="password" name="password" placeholder="Password" required>
						<!--<input class="text w3lpass" type="password" name="password" placeholder="Confirm Password" required>-->
						<div class="wthree-text">  
							<!--<label class="anim">
								<input type="checkbox" class="checkbox" required>
								<span>I Agree To The Terms & Conditions</span> 
							</label>-->  
							<div class="clear"> </div>
						</div>   
						<input type="submit" id="submit-email" value="Login">

						@if (Route::has('password.request'))
										<a class="btn btn-link" style="color:white;" href="{{ route('password.request') }}">
											{{ __('Forgot Your Password?') }}
										</a>
						@endif				
					</form>
				</div>	 
			</div>	
		<!-- copyright -->
		<div class="w3copyright-agile">
			<h2>New User Register Here..<a href="/newuser">Register</a></h2>
		</div>
		<!--//copyright -->	
		</div>	
	</div>	
	<!-- //main --> 
	<!-- js -->
<script type="text/javascript" src="login/js/jquery-2.1.4.min.js"></script>
<script src="login/js/jquery.vide.min.js"></script>
<!-- //js -->
</body>
<script>
function myFunction() {
  var x = document.getElementById("email");
  x.value = x.value.toLowerCase();
}

$("#email").keyup(function(){
     var email = $("#email").val();
     var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
     if (!filter.test(email)) {
       //alert('Please provide a valid email address');
       $("#error_email").text(email+" is not a valid email");
       email.focus;
       //return false;
    } else {
        $("#error_email").text("");
    }
 });

//  $("#submit-email").click(function(){
//     var email = $("#email").val();
//     var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
//     if (!filter.test(email)) {
//        alert('The email address you provide is not valid');
//        $("#email").focus();
//        return false;
//     } else {
       
//     }
//  });
 $("#email").keyup(function(){
     var email = $("#email").val();
     var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
     if (!filter.test(email)) {
       //alert('Please provide a valid email address');
       $("#error_email").text(email+" is not a valid email");
       email.focus;
       //return false;
    } else {
        $("#error_email").text("");
    }
 });
$("#submit-email").click(function(){
    var email = $("#email").val();
    var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    if (!filter.test(email)) {
       alert('Please fill the form with valid email and password');
       $("#email").focus();
       return false;
    } else {
        
    }
});

 </script>
 <script>
            var msg = '{{Session::get('alert')}}';
            var exist = '{{Session::has('alert')}}';
            if(exist){
            alert(msg);
             }
        </script>	

</html>

