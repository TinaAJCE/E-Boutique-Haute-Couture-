<!--
	Author: W3layouts
	Author URL: http://w3layouts.com
	License: Creative Commons Attribution 3.0 Unported
	License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html lang="zxx">

<head>
	
	<!-- Meta tag Keywords -->
   
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<!--<meta name="keywords" content="Wedding Ceremony web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design"
	/>-->
	<script type="application/x-javascript">
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<!--// Meta tag Keywords -->
	<!-- css files -->
	<link rel="stylesheet" href="css/bootstrap.css" type="text/css" media="all">
	<!-- Bootstrap-Core-CSS -->
	<link rel="stylesheet" href="css/font-awesome.css" type="text/css" media="all">
	<!-- Font-Awesome-Icons-CSS -->
	<link rel="stylesheet" href="css/lightbox.css" type="text/css" media="all">
	<link href="css/easy-responsive-tabs.css" rel="stylesheet" type="text/css" media="all" />
	<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
	<!-- Style-CSS -->
	<!-- //css files -->
	<!-- web fonts -->
	<link href="//fonts.googleapis.com/css?family=Arizonia&amp;subset=latin-ext" rel="stylesheet">
	<link href="//fonts.googleapis.com/css?family=Droid+Sans:400,700" rel="stylesheet">
	<!-- //web fonts -->
</head>

<body>
	<div class="w3l-main" id="home">
		<!--navigation-->
		<div class="header-w3">
			<div class="header-top-agile">
				<div class="social-icons-agileits">
					<ul>
						<!--<li><span class="glyphicon glyphicon-envelope" aria-hidden="true"></span> <a href="mailto:info@example.com">info@example.com</a></li>
						<li><span class="glyphicon glyphicon-earphone" aria-hidden="true"></span> +141 587 426 825</li>-->
					</ul>
				</div>
				<div class="social">
					<!--<ul>
						<li><a href="#" class="link facebook" target="_parent"><span class="fa fa-facebook-square"></span></a></li>
						<li><a href="#" class="link twitter" target="_parent"><span class="fa fa-twitter"></span></a></li>
						<li><a href="#" class="link google-plus" target="_parent"><span class="fa fa-google-plus-square"></span></a></li>
					</ul>-->
				</div>
				<div class="clearfix"></div>
			</div>
			<div class="header-bottom-agile">
				<div class=" navigation">
					<nav class="navbar navbar-default cl-effect-16" id="cl-effect-16">
						<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
						
												
						<a href="" class="nav navbar-nav" style="font-family:Baskerville, 'Palatino Linotype', Palatino, 'Century Schoolbook L', 'Times New Roman', serif; font-size:25px;">Haute Couture</a>
                        
                        
						<div id="navbar" class="navbar-collapse navbar-right collapse hover-effect">
                        
							<ul class="nav navbar-nav">
                            
								<li class="active"><a href="/" data-hover="Home">Home</a></li>
								<li><a href="#about" data-hover="About Us" class="scroll">About Us</a></li>
								<!--<li><a href="#events" data-hover="Events" class="scroll">Events</a></li>-->
								<li><a href="#gallery" data-hover="Products" class="scroll">Products</a></li>
								<li><a href="/login1" data-hover="Login">Login</a></li>
								<li><a href="#contact" data-hover="Contact Us" class="scroll">Contact Us</a></li>
							</ul>
						</div>
					</nav>
				</div>
				<!-- <div class="w3ls_search">
					<div class="cd-main-header">
						<ul class="cd-header-buttons">
							<li><a class="cd-search-trigger" href="#cd-search"> <span></span></a></li>
						</ul>
						cd-header-buttons 
					</div>
					<div id="cd-search" class="cd-search">
						<form action="#" method="post">
							<input name="Search" type="search" placeholder="Search..." required>
						</form>
					</div>
				</div>-->
				<div class="clearfix"></div>
			</div>
		</div>
		<!--//navigation-->
		<!--banner-->
		<div class="banner">
			<div data-vide-bg="video/marriage">
				<div class="center-container">
					<div class="banner-text">
						<div id="top" class="callbacks_container">
							<ul class="rslides" id="slider3">
								<li>
									<div class="banner-text-info">
										<h3 class="bnr-title">Our Wedding!</h3>
										<p> welcome to the best day in our lives</p>
									</div>
								</li>
								<li>
									<div class="banner-text-info">
										<h3 class="bnr-title">Happy Couple</h3>
										<p>We create Your Special day</p>
									</div>
								</li>
								<li>
									<div class="banner-text-info">
										<h3 class="bnr-title">Quality Bridal</h3>
										<p>Express your love in the most special way </p>
									</div>
								</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
			<div class="we-po-head">
				<img src="images/m1.png" alt=" ">
			</div>
		</div>
		<!--//banner-->
	</div>
	<!-- about -->
	<!--<div class="about_section" id="about">
		<div class="container">
			<h2 class="wthree_title_agile"><span>O</span>ur <span>S</span>tory</h2>
			<div class="inner_w3l_agile_grids">
				 Bottom to top
				<div class="col-md-5 team-grid">
					normal 
					<div class="ih-item circle effect10 bottom_to_top">
						<div class="img"><img src="images/a2.png" alt="img" /></div>
					</div>
					 end normal
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed efficitur velit ac fringilla fermentum.</p>
					<div class="icons">
						<ul>
							<li><a href="#"><i class="fa fa-facebook"></i></a></li>
							<li class="team-twitter"><a href="#"><i class="fa fa-twitter"></i></a></li>
							<li><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
						</ul>
					</div>
				</div>
				<div class="col-md-2 team-grid">
				 normal 
					<div class="info">
						<h3>Smith</h3>
						<div class="arrow-container animated fadeInDown">
							<a href="#home" class="arrow-2 scroll">
							<i class="fa fa-heart-o" aria-hidden="true"></i>
						</a>
							<div class="arrow-1 animated hinge infinite zoomIn"></div>
						</div>
						<h4>Rosee</h4>
					</div>
				</div>
				<div class="col-md-5 team-grid">
					normal 
					<div class="ih-item circle effect10 bottom_to_top">
						<div class="img"><img src="images/a1.png" alt="img" /></div>
					</div>
					end normal 
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed efficitur velit ac fringilla fermentum.</p>
					<div class="icons">
						<ul>
							<li><a href="#"><i class="fa fa-facebook"></i></a></li>
							<li class="team-twitter"><a href="#"><i class="fa fa-twitter"></i></a></li>
							<li><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
						</ul>
					</div>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
		<div class="banner-bottom">
			//screen-gallery
			<div class="inner_w3l_agile_grids">
				<div class="sreen-gallery-cursual">
					<div id="owl-demo" class="owl-carousel">
						<div class="item-owl">
							<div class="test-review">
								<img src="images/s2.jpg" alt="" />
							</div>
						</div>
						<div class="item-owl">
							<div class="test-review">
								<img src="images/s1.jpg" alt="" />
							</div>
						</div>
						<div class="item-owl">
							<div class="test-review">
								<img src="images/s3.jpg" alt="" />
							</div>
						</div>
						<div class="item-owl">
							<div class="test-review">
								<img src="images/s7.jpg" alt="" />
							</div>
						</div>
						<div class="item-owl">
							<div class="test-review">
								<img src="images/s5.jpg" alt="" />
							</div>
						</div>
						<div class="item-owl">
							<div class="test-review">
								<img src="images/s8.jpg" alt="" />
							</div>
						</div>
						<div class="item-owl">
							<div class="test-review">
								<img src="images/s6.jpg" alt="" />
							</div>
						</div>
						<div class="item-owl">
							<div class="test-review">
								<img src="images/s4.jpg" alt="" />
							</div>
						</div>
					</div>
				</div>
			</div>
			//screen-gallery
		</div>
		//story
		<div class="w3l-poi">
			<img src="images/a3.png" alt=" ">
		</div>
	</div>
	 //about -->
	<!-- who we are -->
	<div class="sect-main-con"  id="about">
		<h3 class="wthree_title_agile"><span>W</span>ho <span>W</span>e <span>A</span>re</h3>
		<div class="w3l-mo">
			<div class="col-md-5 service-1" style="width:100%;">
				<h4>Few Words About</h4>
				<h6>Haute Couture</h6>
				<p>A woman’s wardrobe is her opportunity to stand out and make a lasting first impression. Launched in 2012, Haute Couture Online Boutique offers a wide range of apparel to fit any woman’s unique sense of style. Our clothings are carefully curated to provide our customers the latest fashions. To keep our customers in style we post new arrivals daily, as well as offer stylist picks to help any indecisive shoppers. Haute Couture Online Boutique is a fashionista’s best place to create the perfect wardrobe. Beyond helping you look your best, Haute Couture Online Boutique strives to make every purchase a positive experience. Our top priorities are excellent customer service, exceptionally quick order processing, ultra fast shipping times, and a hassle-free return policy. We value your feedback, whether positive or constructive and we are continuously working to improve your experience. If you are a first-time visitor or long-standing customer, we hope you will be thrilled with every aspect of yourHaute Couture Online Boutique shopping experience.</p>
				<!--<img src="images/well.jpg" alt=" ">-->
				<!--<h5><a href="#" class="view rew3" data-toggle="modal" data-target="#myModal"><span class="glyphicon glyphicon-hand-right" aria-hidden="true"></span>Learn More</a></h5>-->
			</div>
			<!--<div class="col-md-2 service-2">
				<h4>We Best In</h4>
				<a href="#">Bridal boudoir</a>
				<a href="#">Wedding Cakes</a>
				<a href="#">Wedding favors</a>
				<a href="#">Guest services</a>
				<a href="#">Hair &amp; beauty</a>
				<a href="#">Music</a>
				<a href="#">Fireworks</a>
			</div>-->
			<!-- Services -->
			<!--<div class="col-md-5 service" id="services">
				<h4>Services</h4>
				<div class="serve-grids-top">
					<div class="service-box wow fadeInDown" data-wow-duration=".8s" data-wow-delay=".3s">
						<div class="hi-icon-effect-6">
							<a href="#set-6" class="hi-icon fa fa-briefcase"></a>
						</div>
						<div class="hi-text">
							<h5>wedding management</h5>
							<p>Sed ut perspiciis iste natus error sit voluptatem accusantium.</p>
						</div>
						<div class="clearfix"></div>
					</div>
					<div class="service-box wow fadeInDown" data-wow-duration=".8s" data-wow-delay=".3s">
						<div class=" hi-icon-effect-6">
							<a href="#set-6" class="hi-icon fa fa-map"></a>
						</div>
						<div class="hi-text">
							<h5>Wedding venues</h5>
							<p>Sed ut perspiciis iste natus error sit voluptatem accusantium.</p>
						</div>
						<div class="clearfix"></div>
					</div>
					<div class="service-box wow fadeInUp" data-wow-duration="1s" data-wow-delay=".3s">
						<div class=" hi-icon-effect-6">
							<a href="#set-6" class="hi-icon fa fa-glass"></a>
						</div>
						<div class="hi-text">
							<h5>celebrations</h5>
							<p>Sed ut perspiciis iste natus error sit voluptatem accusantium.</p>
						</div>
						<div class="clearfix"></div>
					</div>
					<div class="service-box wow fadeInUp" data-wow-duration="1s" data-wow-delay=".3s">
						<div class=" hi-icon-effect-6">
							<a href="#set-6" class="hi-icon fa fa-music"></a>
						</div>
						<div class="hi-text">
							<h5>Wedding Music</h5>
							<p>Sed ut perspiciis iste natus error sit voluptatem accusantium.</p>
						</div>
						<div class="clearfix"></div>
					</div>
					<div class="clearfix"> </div>
				</div>
			</div>-->
			<div class="clearfix"> </div>
			<!-- //Services -->
			<!-- Modal5 -->
			<div class="modal fade" id="myModal" tabindex="-1" role="dialog">
				<div class="modal-dialog">
					<!-- Modal content-->
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal">&times;</button>
							<h4>Wedding Ceremony</h4>
							<img src="images/n1.jpg" alt="blog-image" />
							<span>Lorem ipsum dolor sit amet, Sed ut perspiciatis unde omnis iste natus error sit voluptatem , eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.accusantium doloremque laudantium, totam rem aperiamconsectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</span>
						</div>
					</div>
				</div>
			</div>
			<!-- //Modal5 -->
		</div>
	</div>
	<!-- //who we are -->
	<!-- news -->
	
	<!-- //Modal2 -->
	<!-- Modal3 -->
	<div class="modal fade" id="myModal3" tabindex="-1" role="dialog">
		<div class="modal-dialog">
			<!-- Modal content-->
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4>Latest Event</h4>
					<img src="images/n3.jpg" alt="blog-image" />
					<span>Lorem ipsum dolor sit amet, Sed ut perspiciatis unde omnis iste natus error sit voluptatem , eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.accusantium doloremque laudantium, totam rem aperiamconsectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</span>
				</div>
			</div>
		</div>
	</div>
	<!-- //Modal3 -->
	<!-- news -->
	<!-- Gallery -->
	<div id="gallery" class="gallery">
		<div class="container">
			<h3 class="wthree_title_agile"><span>O</span>ur <span>P</span>roducts</h3>
			<div class="gallery-w3lsrow">

			<?php
				$sql = DB::table('products')->where('product_status',1)->get();
               // $count=DB::select('SELECT * FROM products')->count();
                $count = DB::table('products')->count();

				//$sql="select * from approved_designer_items";
				//$img="select photo from registration where r_type=2";
						//echo $sql;
				//$result=mysqli_query($con,$sql);
						
				//$rowcount=mysqli_num_rows($result);
                if($count!=0)
	            {
                    foreach($sql as $a)
                    {
                        $p_id=$a->product_id;
                        $p_name=$a->product_name;
                        $p_price=$a->product_price;
                        $p_color=$a->product_color;
                        $p_stock=$a->product_stock;
                        $p_desc=$a->product_description;
                        $p_image=$a->cover_image;
                        $p_status=$a->product_status;
                        $p_catid=$a->category_id;
                        $bsid=$a->bs_id;
                        $fabid=$a->fab_id;
                        $lsizeid=$a->letter_size_id;
                        $lid=$a->l_id;
                        $nid=$a->n_id;
                        
                        
                    
		           		
                        
                        ?>
                        
				<div class="row" style="width:400px;height:400px;float:left">
					<div class="w3ls-hover">
						<a href="../../../storage/upload/<?php echo $p_image; ?>" data-lightbox="example-set" data-title="{{$p_desc}}">
						<img src="../../../storage/upload/<?php echo $p_image; ?>" class="img-responsive zoom-img" alt=""/>
						<div class="view-caption">
							<h5>{{$p_name}}</h5>
							<span class="fa fa-heart"></span>
						</div>
					</a>
					</div>
				</div>
				
				<?php
					}
				}
				?>
				
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
	<!-- //gallery -->
	<!-- team -->
	<div class="team" id="team">
		<div class="container">
			<h3 class="wthree_title_agile"><span>O</span>ur <span>D</span>esigners</h3>
			<div class="agile_team_grids">
			<?php
				$designer=DB::table('logs')->where('login_type',2)->get();
				foreach($designer as $d)
				{
					$g=DB::table('registers')->where('reg_id',$d->reg_id)->first();
					
			?>
				<div class="col-md-3 agile_team_grid team-left-w3l-agile" style="float:left">
					<div class="agile_team_grid_main">
						<img src="../../../storage/upload/{{$g->register_photo}}" alt=" " class="img-responsive" />
						
					</div>
					<div class="agile_team_grid1">
						<h3>{{$g->register_name}}</h3>
						<p>{{$g->register_company_name}}</p>
					</div>
				</div>
				<?php
				}
				?>
				<div class="clearfix"> </div>
				
			</div>
		</div>
	</div>
	<!-- //team -->
	<!--/counter-->
	<!-- <div class="agileinfo_counter_section">
		<div class="container">
			<h3>Wedding Ceremony</h3>
			<p class="sub_para two">consectetur adipiscing elit, sed do eiusmod</p>
			<h5><a href="#contact" class="view rew3 scroll"><span class="glyphicon glyphicon-hand-right" aria-hidden="true"></span>Contact Us</a></h5>
		</div>
	</div>
	 -->


	<!-- js -->
	<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.js"></script>
	<!-- Necessary-JavaScript-File-For-Bootstrap -->
	<!-- //js -->
	<!--  light box js -->
	<script src="js/lightbox-plus-jquery.min.js">
	</script>
	<!-- //light box js-->

	<!-- video-js -->
	<script src="js/jquery.vide.min.js"></script>
	<!-- //video-js -->


	<!-- Baneer-js -->
	<!--responsive slider-->
	<script src="js/responsiveslides.min.js"></script>
	<!--//responsive slider-->

	<!--banner Slider starts Here-->
	<script>
		// You can also use "$(window).load(function() {"
		$(function () {
			// Slideshow 3
			$("#slider3").responsiveSlides({
				auto: true,
				pager: false,
				nav: true,
				speed: 500,
				namespace: "callbacks",
				before: function () {
					$('.events').append("<li>before event fired.</li>");
				},
				after: function () {
					$('.events').append("<li>after event fired.</li>");
				}
			});

		});
	</script>
	<!--//End-slider-script-->

	<!-- //Baneer-js -->
	<!-- search-jQuery -->
	<script src="js/main.js"></script>
	<!-- //search-jQuery -->

	<!-- required-js-files-->
	<link href="css/owl.carousel.css" rel="stylesheet">
	<script src="js/owl.carousel.js"></script>
	<script>
		$(document).ready(function () {
			$("#owl-demo").owlCarousel({
				items: 1,
				itemsDesktop: [768, 4],
				itemsDesktopSmall: [414, 3],
				lazyLoad: true,
				autoPlay: true,
				navigation: true,

				navigationText: false,
				pagination: true,

			});

		});
	</script>
	<!--//required-js-files-->

	<!-- script for responsive tabs -->
	<script src="js/easy-responsive-tabs.js"></script>
	<script>
		$(document).ready(function () {
			$('#horizontalTab').easyResponsiveTabs({
				type: 'default', //Types: default, vertical, accordion           
				width: 'auto', //auto or any width like 600px
				fit: true, // 100% fit in a container
				closed: 'accordion', // Start closed if in accordion view
				activate: function (event) { // Callback function if tab is switched
					var $tab = $(this);
					var $info = $('#tabInfo');
					var $name = $('span', $info);
					$name.text($tab.text());
					$info.show();
				}
			});
			$('#verticalTab').easyResponsiveTabs({
				type: 'vertical',
				width: 'auto',
				fit: true
			});
		});
	</script>
	<!-- start-smooth-scrolling -->
	<script type="text/javascript" src="js/move-top.js"></script>
	<script type="text/javascript" src="js/easing.js"></script>
	<script type="text/javascript">
		jQuery(document).ready(function ($) {
			$(".scroll").click(function (event) {
				event.preventDefault();

				$('html,body').animate({
					scrollTop: $(this.hash).offset().top
				}, 1000);
			});
		});
	</script>
	<!-- //end-smooth-scrolling -->
	<!-- smooth scrolling -->
	<script src="js/SmoothScroll.min.js"></script>
	<!-- //smooth scrolling -->



</body>

</html>