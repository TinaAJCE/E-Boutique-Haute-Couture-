
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title  -->
    <!-- image slideshow -->
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">


    <!-- Favicon  -->
    <link rel="icon" href="../../../customer/img/core-img/favicon.ico">

    <!-- Core Style CSS -->
    <link rel="stylesheet" href="../../../designer/css/core-style.css">
    <link rel="stylesheet" href="../../../designer/style.css">

    <!-- Responsive CSS -->
    <link href="../../../designer/css/responsive.css" rel="stylesheet">
	<style>
        <style>
        .mySlides {display:none;}

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    font-family: Arial, Helvetica, sans-serif;
}
h1{
    font-family:arizonia;
}

.header {
    text-align: center;
    padding: 32px;
}

.row {
    display: -ms-flexbox; /* IE 10 */
    display: flex;
    -ms-flex-wrap: wrap; /* IE 10 */
    flex-wrap: wrap;
    padding: 0 4px;
}

/* Create two equal columns that sits next to each other */
.column {
    -ms-flex: 50%; /* IE 10 */
    flex: 50%;
    padding: 0 4px;
}

.column img {
    margin-top: 8px;
    vertical-align: middle;
}

/* Style the buttons */
.btn {
    border: none;
    outline: none;
    padding: 10px 16px;
    background-color: #f1f1f1;
    cursor: pointer;
    font-size: 18px;
}

.btn:hover {
    background-color: #ddd;
}

.btn.active {
    background-color: #666;
    color: white;
}
.image-upload>input {
  display: none;
}
tr
{
    height:50px;
}
input[type=text],input[type=submit],input[type=textarea],input[type=password],input[type=number],input[type=email],input[type=date],textarea,select,button {
            width: 100%;
            padding: 15px;
            margin: 5px 0 22px 0;
            display: inline-block;
            border: none;
            background:#f2f2f2;
            border-radius: 12px;
           
            }
	</style>
</head>

<body>
<?php

                                                       
$reg=Session::get('email');
$register=DB::table('logs')->where('email',$reg)->first();
$reg_id=$register->reg_id;

?>
    <div class="catagories-side-menu">
        <!-- Close Icon -->
        <div id="sideMenuClose">
            <i class="ti-close"></i>
        </div>
        <!--  Side Nav  -->
        <div class="nav-side-menu">
            <div class="menu-list">
                <h6>Categories</h6>
                <ul id="menu-content" class="menu-content collapse out">
                    <!-- Single Item -->
                    <li data-toggle="collapse" data-target="#women" class="collapsed active">
                        <a href="#">Designer<span class="arrow"></span></a>
                        <ul class="sub-menu collapse" id="women">
                        <li><a href="/upload_designs">Upload My Designs</a></li>
                            <li><a href="{{route('admin_request', ['reg_id' => $reg_id])}}">Admin Requests</a></li>
                            <li><a href="{{route('customer_request', ['reg_id' => $reg_id])}}">Customer Requests</a></li>
                            <li><a href="{{route('completed_request', ['reg_id' => $reg_id])}}">Completed Requests</a></li>
                            <li><a href="{{route('my_products', ['reg_id' => $reg_id])}}">My Products</a></li>
                           
                           
                        </ul>
                    </li>
                    <!-- Single Item -->
                    
                    <!-- Single Item -->
                    <li data-toggle="collapse" data-target="#profile" class="collapsed">
                        <a href="#">Profile<span class="arrow"></span></a>
                        <ul class="sub-menu collapse" id="profile">
                            <li><a href="{{route('my_profile', ['reg_id' => $reg_id])}}">My Profile</a></li>
                            <li><a href="{{route('change_password', ['reg_id' => $reg_id])}}">Change Password</a></li>
                            
                        </ul>
                    </li>
                    
                 </ul>
            </div>
        </div>
    </div>

    <div id="wrapper">

        <!-- ****** Header Area Start ****** -->
        <header class="header_area">
            <!-- Top Header Area Start -->
            <div class="top_header_area">
                <div class="container h-100">
                    <div class="row h-100 align-items-center justify-content-end">

                        <div class="col-12 col-lg-7">
                            <div class="top_single_area d-flex align-items-center">
                                <!-- Logo Area -->
                                <div class="top_logo">
                                    <a href="#"><h1>Haute Couture</h1></a>
                                </div>
                                <!-- Cart & Menu Area -->
                                <div class="header-cart-menu d-flex align-items-center ml-auto">
                                    <!-- Cart Area -->
                                    <div class="cart">
                                        
                                        <ul class="cart-list">
                                            <li>
                                                <a href="#" class="image"><img src="../../../designer/img/custo/product-img/product-10.jpg" class="cart-thumb" alt=""></a>
                                                <div class="cart-item-desc">
                                                    <h6><a href="#">Women's Fashion</a></h6>
                                                    <p>1x - <span class="price">$10</span></p>
                                                </div>
                                                <span class="dropdown-product-remove"><i class="icon-cross"></i></span>
                                            </li>
                                            <li>
                                                <a href="#" class="image"><img src="../../../designer/img/custo/product-img/product-11.jpg" class="cart-thumb" alt=""></a>
                                                <div class="cart-item-desc">
                                                    <h6><a href="#">Women's Fashion</a></h6>
                                                    <p>1x - <span class="price">$10</span></p>
                                                </div>
                                                <span class="dropdown-product-remove"><i class="icon-cross"></i></span>
                                            </li>
                                            <li class="total">
                                                <span class="pull-right">Total: $20.00</span>
                                                <a href="cart.html" class="btn btn-sm btn-cart">Cart</a>
                                                <a href="checkout-1.html" class="btn btn-sm btn-checkout">Checkout</a>
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="header-right-side-menu ml-15">
                                        <a href="#" id="sideMenuBtn"><i class="ti-menu" aria-hidden="true"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>

            <!-- Top Header Area End -->
            <div class="main_header_area">
                <div class="container h-100">
                    <div class="row h-100">
                        <div class="col-12 d-md-flex justify-content-between">
                            
                            <div class="main-menu-area">
                                <nav class="navbar navbar-expand-lg align-items-start">

                                    <div>
                            	<ul class="navbar-nav animated" id="nav">
                                <li class="nav-item dropdown">
                                				
                                                
                                     <a class="nav-link dropdown-toggle" href="#" id="karlDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><img src="../../../designer/images/user.png" style="width:45px; height:45px;position:absolute;"/><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{{Session::get('email')}}{{csrf_field()}}</a>
                                                <div class="dropdown-menu" aria-labelledby="karlDropdown">
                                                    <a class="dropdown-item" href="{{route('my_profile', ['reg_id' => $reg_id])}}"><img src="../../../designer/images/user.png" style="width:20px; height:20px;"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Profile</a>

                                                    <a class="dropdown-item" href="/logout"><img src="../../../designer/images/login-icon.jpg" style="width:20px; height:20px;"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Logout</a>
                                                    <!--<a class="dropdown-item" href="product-details.html">Product Details</a>
                                                    <a class="dropdown-item" href="cart.html">Cart</a>
                                                    <a class="dropdown-item" href="checkout.html">Checkout</a>-->
                                                </div>
                                 </li>
                                
                                 <li><br>
                                 	
                                 </li> 
                                               
                                  <li>
                                                                      
                                    </li>          
                                </ul>
                            </div>

                                </nav>
                            </div>
                            
                            <!-- Help Line -->
                            
                            <div class="help-line">
                                <a href="tel:+346573556778"><i class="ti-headphone-alt"></i> +91-9207064521</a>

                            </div>
                            
                        </div>
                                            </div>
                </div>
            </div>
        </header>
        <!-- ****** Header Area End ****** -->

        <!-- ****** Top Discount Area Start ****** -->
        <section class="top-discount-area d-md-flex align-items-center">
            <!-- Single Discount Area -->
            <div class="single-discount-area">
                <h5><a href="{{route('deshome', ['reg_id' => $reg_id])}}">HOME</a></h5>
                
            </div>
            <!-- Single Discount Area -->
            <div class="single-discount-area">
                <h5><a href="{{route('completed_request', ['reg_id' => $reg_id])}}">Completed Requests</a></h5>
            </div>
            <!-- Single Discount Area -->
            <div class="single-discount-area">
                <h5><a href="{{route('my_products', ['reg_id' => $reg_id])}}">My Designs</a></h5>
            </div>
        </section>
       <div>

        <?php
            $sess=Session::get('reg_id');
            $reg=DB::table('registers')->where('reg_id',$sess)->first();
            $log=DB::table('logs')->where('reg_id',$sess)->first();

        ?>
                

                            
                <div style="width:600px;height:auto;margin-left:600px;margin-top:50px;background-color:ash;float:left">
                    <img id="blah" src="../../../storage/upload/{{$reg->register_photo}}" style="margin-left:150px;width:200px;height:200px;border-radius:100px;" >
                    <form method="post" action="{{route('update_password', ['reg_id' => $reg_id])}}" id="pphoto" name="pphoto"  enctype="multipart/form-data" name="add_product" id="add_product">
                        <input type="hidden" name="_token" value="{{csrf_token()}}">
                        @csrf
                    <label>Old Password</label>
                    <input type="password" name="password">
                    <label>New Password</label>
                    <input type="password" name="newpassword">
                    <label>Confirm Password</label>
                    <input type="password" name="cpassword">
                    <input type="submit" name="submit" style="background-color:green;color:white;">
        </form>
                </div>
                
            </div>  
        	<div class="clearfix"> </div>
		</div>
		
				
        <script>
            var msg = '{{Session::get('alert')}}';
            var exist = '{{Session::has('alert')}}';
            if(exist){
            alert(msg);
             }
        </script>                                     
       
        
            		
            <hr/>

        <!-- ****** Footer Area End ****** -->
    </div>
    <!-- /.wrapper end -->

    <!-- jQuery (Necessary for All JavaScript Plugins) -->
    <script src="../../../designer/js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="../../../designer/js/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="../../../designer/js/bootstrap.min.js"></script>
    <!-- Plugins js -->
    <script src="../../../designer/js/plugins.js"></script>
    <!-- Active js -->
    <script src="../../../designer/js/active.js"></script>
    <script>
// Get the elements with class="column"
var elements = document.getElementsByClassName("column");

// Declare a loop variable
var i;

// Full-width images
function one() {
    for (i = 0; i < elements.length; i++) {
        elements[i].style.msFlex = "100%";  // IE10
        elements[i].style.flex = "100%";
    }
}

// Two images side by side
function two() {
    for (i = 0; i < elements.length; i++) {
        elements[i].style.msFlex = "50%";  // IE10
        elements[i].style.flex = "50%";
    }
}

// Four images side by side
function four() {
    for (i = 0; i < elements.length; i++) {
        elements[i].style.msFlex = "25%";  // IE10
        elements[i].style.flex = "25%";
    }
}

// Add active class to the current button (highlight it)
var header = document.getElementById("myHeader");
var btns = header.getElementsByClassName("btn");
for (var i = 0; i < btns.length; i++) {
  btns[i].addEventListener("click", function() {
    var current = document.getElementsByClassName("active");
    current[0].className = current[0].className.replace(" active", "");
    this.className += " active";
  });
}
</script>
   

</body>

</html>