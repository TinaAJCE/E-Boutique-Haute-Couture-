
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.5/css/select2.css" /> -->
    <link rel="stylesheet" href="../../../designer/css/select2.css" />

    <!-- Title  -->
    

    <!-- Favicon  -->
    <link rel="icon" href="../../../customer/img/core-img/favicon.ico">

    <!-- Core Style CSS -->
    <link rel="stylesheet" href="../../../designer/css/core-style.css">
    <link rel="stylesheet" href="../../../designer/style.css">

    <!-- Responsive CSS -->
    <link href="../../../designer/css/responsive.css" rel="stylesheet">
	<style>
		input[type=file],[type=text],input[type=textarea],input[type=password],input[type=number],input[type=email],input[type=date],textarea,select,button {
            width: 100%;
            padding: 15px;
            margin: 5px 0 22px 0;
            display: inline-block;
            border: none;
            background:#e0e0e0;
            border-radius: 12px;
           
            }
            /* input[type=file]
            {
               
                padding: 15px;
                width:150px;
                background:#e0e0e0;
               
                 
            } */
            input[type=submit]
            {
                width: 800px;; 
                margin: 5px 0 22px 200px;
                height:80px;
                display: inline-block;
                color:white;
                border: none;
                background:#15D047;
                border-radius: 12px;
                
            }
           
* {
    box-sizing: border-box;
}

body {
    margin: 0;
    font-family: Arial, Helvetica, sans-serif;
}
h1{
    font-family:arizonia;
}

.header {
    text-align: center;
    padding: 32px;
}

.row {
    display: -ms-flexbox; /* IE 10 */
    display: flex;
    -ms-flex-wrap: wrap; /* IE 10 */
    flex-wrap: wrap;
    padding: 0 4px;
}

/* Create two equal columns that sits next to each other */
.column {
    -ms-flex: 50%; /* IE 10 */
    flex: 50%;
    padding: 0 4px;
}

.column img {
    margin-top: 8px;
    vertical-align: middle;
}

/* Style the buttons */
.btn {
    border: none;
    outline: none;
    padding: 10px 16px;
    background-color: #f1f1f1;
    cursor: pointer;
    font-size: 18px;
}

.btn:hover {
    background-color: #ddd;
}

.btn.active {
    background-color: #666;
    color: white;
}
	</style>
</head>

<body>
    <div class="catagories-side-menu">
        <!-- Close Icon -->
        <div id="sideMenuClose">
            <i class="ti-close"></i>
        </div>
        <?php

                                                       
$reg=Session::get('email');
$register=DB::table('logs')->where('email',$reg)->first();
$reg_id=$register->reg_id;

?>
        <!--  Side Nav  -->
        <div class="nav-side-menu">
            <div class="menu-list">
                <h6>Categories</h6>
                <ul id="menu-content" class="menu-content collapse out">
                    <!-- Single Item -->
                    <li data-toggle="collapse" data-target="#women" class="collapsed active">
                        <a href="#">Designer<span class="arrow"></span></a>
                        <ul class="sub-menu collapse" id="women">
                            <li><a href="/upload_designs">Upload My Designs</a></li>
                            <li><a href="{{route('admin_request', ['reg_id' => $reg_id])}}">Admin Requests</a></li>
                            <li><a href="{{route('customer_request', ['reg_id' => $reg_id])}}">Customer Requests</a></li>
                            <li><a href="{{route('completed_request', ['reg_id' => $reg_id])}}">Completed Requests</a></li>
                            <li><a href="{{route('my_products', ['reg_id' => $reg_id])}}">My Products</a></li>
                           
                           
                        </ul>
                    </li>
                    <!-- Single Item -->
                    
                    <!-- Single Item -->
                    <li data-toggle="collapse" data-target="#profile" class="collapsed">
                        <a href="#">Profile<span class="arrow"></span></a>
                        <ul class="sub-menu collapse" id="profile">
                        <li><a href="{{route('my_profile', ['reg_id' => $reg_id])}}">My Profile</a></li>
                        <li><a href="{{route('change_password', ['reg_id' => $reg_id])}}">Change Password</a></li>
                            
                        </ul>
                    </li>
                    
                 </ul>
            </div>
        </div>
    </div>

    <div id="wrapper">

        <!-- ****** Header Area Start ****** -->
        <header class="header_area">
            <!-- Top Header Area Start -->
            <div class="top_header_area">
                <div class="container h-100">
                    <div class="row h-100 align-items-center justify-content-end">

                        <div class="col-12 col-lg-7">
                            <div class="top_single_area d-flex align-items-center">
                                <!-- Logo Area -->
                                <div class="top_logo">
                                    <a href="#"><h1>Haute Couture</h1></a>
                                </div>
                                <!-- Cart & Menu Area -->
                                <div class="header-cart-menu d-flex align-items-center ml-auto">
                                    <!-- Cart Area -->
                                    <div class="cart">
                                        <!--<a href="#" id="header-cart-btn" target="_blank"><span class="cart_quantity">2</span> <i class="ti-bag"></i> Your Bag $20</a>
                                       
                                         Cart List Area Start-->
                                        <ul class="cart-list">
                                            <li>
                                                <a href="#" class="image"><img src="../../../designer/img/custo/product-img/product-10.jpg" class="cart-thumb" alt=""></a>
                                                <div class="cart-item-desc">
                                                    <h6><a href="#">Women's Fashion</a></h6>
                                                    <p>1x - <span class="price">$10</span></p>
                                                </div>
                                                <span class="dropdown-product-remove"><i class="icon-cross"></i></span>
                                            </li>
                                            <li>
                                                <a href="#" class="image"><img src="../../../designer/img/custo/product-img/product-11.jpg" class="cart-thumb" alt=""></a>
                                                <div class="cart-item-desc">
                                                    <h6><a href="#">Women's Fashion</a></h6>
                                                    <p>1x - <span class="price">$10</span></p>
                                                </div>
                                                <span class="dropdown-product-remove"><i class="icon-cross"></i></span>
                                            </li>
                                            <li class="total">
                                                <span class="pull-right">Total: $20.00</span>
                                                <a href="cart.html" class="btn btn-sm btn-cart">Cart</a>
                                                <a href="checkout-1.html" class="btn btn-sm btn-checkout">Checkout</a>
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="header-right-side-menu ml-15">
                                        <a href="#" id="sideMenuBtn"><i class="ti-menu" aria-hidden="true"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>

            <!-- Top Header Area End -->
            <div class="main_header_area">
                <div class="container h-100">
                    <div class="row h-100">
                        <div class="col-12 d-md-flex justify-content-between">
                            <!-- Header Social Area -->
                            <!--<div class="header-social-area">
                                <a href="#"><span class="karl-level">Share</span> <i class="fa fa-pinterest" aria-hidden="true"></i></a>
                                <a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                                <a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                                <a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
                            </div>-->
                            <!-- Menu Area -->
                            <div class="main-menu-area">
                                <nav class="navbar navbar-expand-lg align-items-start">

                                    <!--<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#karl-navbar" aria-controls="karl-navbar" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"><i class="ti-menu"></i></span></button>

                                    <div class="collapse navbar-collapse align-items-start collapse" id="karl-navbar">
                                        <ul class="navbar-nav animated" id="nav">
                                            <li class="nav-item active"><a class="nav-link" href="index.html">Home</a></li>
                                            <li class="nav-item dropdown">
                                                <a class="nav-link dropdown-toggle" href="#" id="karlDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Pages</a>
                                                <div class="dropdown-menu" aria-labelledby="karlDropdown">
                                                    <a class="dropdown-item" href="index.html">Home</a>
                                                    <a class="dropdown-item" href="shop.html">Shop</a>
                                                    <a class="dropdown-item" href="product-details.html">Product Details</a>
                                                    <a class="dropdown-item" href="cart.html">Cart</a>
                                                    <a class="dropdown-item" href="checkout.html">Checkout</a>
                                                </div>
                                            </li>
                                            <li class="nav-item"><a class="nav-link" href="#">Dresses</a></li>
                                            <li class="nav-item"><a class="nav-link" href="#"><span class="karl-level">hot</span> Shoes</a></li>
                                            <li class="nav-item"><a class="nav-link" href="#">Contact</a></li>
                                        </ul>
                                    </div>-->
                                    <div>
                            	<ul class="navbar-nav animated" id="nav">
                                <li class="nav-item dropdown">
                                				
                                     <a class="nav-link dropdown-toggle" href="#" id="karlDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><img src="../../../designer/images/user.png" style="width:45px; height:45px;position:absolute;"/><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{{Session::get('email')}}{{csrf_field()}}</a>
                                                <div class="dropdown-menu" aria-labelledby="karlDropdown">
                                                    <a class="dropdown-item" href="{{route('my_profile', ['reg_id' => $reg_id])}}"><img src="../../../designer/images/user.png" style="width:20px; height:20px;"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Profile</a>

                                                    <a class="dropdown-item" href="/logout"><img src="../../../designer/images/login-icon.jpg" style="width:20px; height:20px;"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Logout</a>
                                                    <!--<a class="dropdown-item" href="product-details.html">Product Details</a>
                                                    <a class="dropdown-item" href="cart.html">Cart</a>
                                                    <a class="dropdown-item" href="checkout.html">Checkout</a>-->
                                                </div>
                                 </li>
                                
                                 <li><br>
                                 	
                                 </li> 
                                               
                                  <li>
                                                                      
                                    </li>          
                                </ul>
                            </div>

                                </nav>
                            </div>
                            
                            <!-- Help Line -->
                            
                            <div class="help-line">
                                <a href="tel:+346573556778"><i class="ti-headphone-alt"></i> +91-9207064521</a>

                            </div>
                            
                        </div>
                                            </div>
                </div>
            </div>
        </header>
        <!-- ****** Header Area End ****** -->

        <!-- ****** Top Discount Area Start ****** -->
        <section class="top-discount-area d-md-flex align-items-center">
            <!-- Single Discount Area -->
            <div class="single-discount-area">
                <h5><a href="{{route('deshome', ['reg_id' => $reg_id])}}">HOME</a></h5>
                
            </div>
            <!-- Single Discount Area -->
            <div class="single-discount-area">
                <h5><a href="{{route('completed_request', ['reg_id' => $reg_id])}}">Completed Requests</a></h5>
            </div>
            <!-- Single Discount Area -->
            <div class="single-discount-area">
                <h5><a href="{{route('my_products', ['reg_id' => $reg_id])}}">My Designs</a></h5>
            </div>
        </section>
        

        <div>
            <br>
                                <h2 style = "font-family:garamond">My Designs</h2>
            <div>
                                     <?php
                                        use App\ProductsCategory;
                                        $systems= DB::table('products_categories')->select('category_id','category_name')->get();
                                        $designer_email=Session::get('email');
                                        
                                        $designer_id=DB::table('logs')->where('email',$designer_email)->first();  
                                        // dd($designer_id->reg_id);
                                    ?>

                                    <script src="../../../admin/js/jscolor.js"></script>
            
                <hr>
                <form method="post" action="/designs_upload"  enctype="multipart/form-data" name="add_product" id="add_product">
                <input type="hidden" name="_token" value="{{csrf_token()}}">
                @csrf
                <input type="hidden" name="designer_id" value="{{$designer_id->reg_id}}">
                <div class="container" style="width:80%">
                    
    				<br><br>		
                    <label for="category"><b>Product Category</b></label>
                        <select id="p_category" name="p_category">
                            <?php
                                foreach($systems as $object)
                                {
                                    $category_id=$object->category_id;
                                    $category_name=$object->category_name;
                                    echo"<option value='$category_id'>$category_name</option>";
                                }
                                    
                            ?>
                             <label id="derror_name"></label>     
                         </select>
                         <br>
                    <label for="name"><b>Brand Name</b></label>
                        <input type="text" placeholder="Enter Product Name" name="product_name" autocomplete="off" id="product_name"  required>
						<label id="derror_name" style="color: red;"></label>
                        <br>
                    <label for="color"><b>Product Color</b></label>
                    <input type="text"  name="product_color" id="product_color" class="jscolor {width:200, height:150, position:'right'}" style="width: 100%;padding: 15px; margin: 5px 0 22px 0; display: inline-block;border: none; background: #f1f1f1;border-radius: 12px;">

                        <br>
                    <label for="price"><b>Unit Price</b></label>
                        <input type="number" placeholder="Enter Price" name="product_price" id="product_price" autocomplete="off" min="1" required>
						<label id="derror_price" style="color: red;"></label>
                    <br>

                    
                   <label for="stock"><b>Product Stock</b></label>
                        <input type="number" placeholder="Enter Stock" name="product_stock" id="product_stock" autocomplete="off" min="1" required>
						<label id="derror_stock" style="color: red;"></label>
                    <br>
                    
                    <label for="description"><b>Product Description</b></label>
                        <textarea rows="10" cols="50" name="product_desc" id="product_desc" autocomplete="off" required>
                        </textarea>
                        <label id="derror_desc" style="color: red;"></label>

                    <br>
                    <?php
                    $syst= DB::table('letter_sizes')->select('letter_size_id','letter_size')->get();
                    ?>
                    <label for="letter_size"><b>Size</b></label>
                        <select id="size" name="size" required>
                            <option></option>
                            <?php
                                foreach($syst as $object)
                                {
                                    $l_id=$object->letter_size_id;
                                    $l_size=$object->letter_size;
                                    echo"<option value='$l_id'>$l_size</option>";
                                }
                                    
                            ?>
                             <label id="derror_lname"></label>     
                         </select>
                         <br>

                    
                    <?php
                    $sys= DB::table('bust_sizes')->select('bs_id','bust_size')->get();
                    ?>
                    <label for="bust_size"><b>Chest Measurement</b></label>
                        <select id="b_size" name="b_size" required>
                            <option></option>
                            <?php
                                foreach($sys as $object)
                                {
                                    $b_id=$object->bs_id;
                                    $b_size=$object->bust_size;
                                    echo"<option value='$b_id'>$b_size</option>";
                                }
                                    
                            ?>
                    <label id="derror_bname"></label>     
                    </select>
                    <br>
                    <?php
                    $sysm= DB::table('natural_waists')->select('n_id','natural_waist_size')->get();
                    ?>
                    <label for="na_size"><b>Natural Waist Size</b></label>
                        <select id="n_size" name="n_size" required>
                            <option></option>
                            <?php
                                foreach($sysm as $object)
                                {
                                    $n_id=$object->n_id;
                                    $n_size=$object->natural_waist_size;
                                    echo"<option value='$n_id'>$n_size</option>";
                                }
                                    
                            ?>
                             <label id="derror_nname"></label>     
                         </select>
                         <br>

                         <br>
                    <?php
                    $sysmt= DB::table('hip_sizes')->select('h_id','hip_size')->get();
                    ?>
                    <label for="hip_size"><b>Hip Size</b></label>
                        <select id="h_size" name="h_size" required>
                            <option></option>
                            <?php
                                foreach($sysmt as $object)
                                {
                                    $h_id=$object->h_id;
                                    $h_size=$object->hip_size;
                                    echo"<option value='$h_id'>$h_size</option>";
                                }
                                    
                            ?>
                             <label id="derror_hname"></label>     
                         </select>
                         <br>
                    <?php
                    $sysms= DB::table('low_waists')->select('l_id','low_waist_size')->get();
                    ?>
                    <label for="l_size"><b>Low Waist Size</b></label>
                        <select id="l_size" name="l_size" required>
                            <option></option>
                            <?php
                                foreach($sysms as $object)
                                {
                                    $l_id=$object->l_id;
                                    $l_size=$object->low_waist_size;
                                    echo"<option value='$l_id'>$l_size</option>";
                                }
                                    
                            ?>
                             <label id="derror_lname"></label>     
                         </select>     
                         <br>

                         <?php
                                                                    $fabs= DB::table('fabrics')->select('fab_id','fab_name','fab_image')->get();
                                                                    ?>
                                                                    <label for="fabs"><b>Available Fabrics</b></label>
                                                                    <select id="fabs" name="fabs" style="background: #f1f1f1;" required>
                                                                            <option></option>
                                                                            <?php
                                                                                foreach($fabs as $object)
                                                                                {
                                                                                    $f_id=$object->fab_id;
                                                                                    $fname=$object->fab_name;
                                                                                    $image=$object->fab_image;
                                                                                    echo"<option value='$f_id' data-img_src='../../../storage/upload/$image'>$fname</option>";
                                                                                
                                                                                }
                                                                                    
                                                                            ?>
                                                                            <label id="derror_lname"></label>     
                                                                    </select>
                                                                <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script> -->
                                                                <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.5/js/select2.js"></script> -->
                                                                <script src="../../../customer/js/jquery.min.js"></script>
                                                                <script src="../../../customer/js/select2.js"></script>

                                                                
                                                                <script type="text/javascript">
                                                                    function custom_template(obj){
                                                                            var data = $(obj.element).data();
                                                                            var text = $(obj.element).text();
                                                                            if(data && data['img_src']){
                                                                                img_src = data['img_src'];
                                                                                template = $("<div><img src=\"" + img_src + "\" style=\"width:65px;height:65px;border-radius:32.5px;\"/>" + text + "</div>");
                                                                                return template;
                                                                            }
                                                                        }
                                                                        var options = {
                                                                            'templateSelection': custom_template,
                                                                            'templateResult': custom_template,
                                                                        }
                                                                        $('#fabs').select2(options);
                                                                        $('.select2-container--default .select2-selection--single').css({'height': '70px','width' : '100%','background': '#f2f2f2','border-radius':'12px'});

                                                                </script>
                    <label for="cover_photo"><b>Cover Photo</b></label>
                        <input type="file" id="pic" name="pic" autocomplete="off" required>
                        <label id="derror_pic" style="color: red;"></label>
                    <br>
                    
                    <label for="photos"><b>Photos</b></label>
                        <input type="file" autocomplete="off" name="files[]" id="files[]" multiple required>
                        <label id="derror_pics" style="color: red;"></label>
   
                    <hr>

                    <button type="submit" id="create_item" name="create_item" style="background-color:#3C3;color:white;">Send My Product</button>
                </div>
                <script src="jscolor.js"></script>
                <script>


$("#product_name").keyup(function(){
     var product_name = $("#product_name").val();
     var filter = /^(?![\s]+$)[a-zA-Z\s]*$/;
     if (!filter.test(product_name)) {
       //alert('Please provide a valid email address');
       $("#derror_name").text(product_name+" is not a valid name");
       product_name.focus;
       //return false;
    } else {
        $("#derror_name").text("");
    }
 });


 
 </script>
<script>


$("#product_price").keyup(function(){
     var product_price = $("#product_price").val();
     var filter =/^\d{1,8}(\.\d{1,4})?$/;
     if (!filter.test(product_price)) {
       //alert('Please provide a valid email address');
       $("#derror_price").text(product_price+" is not a valid price");
       product_price.focus;
       //return false;
    } else {
        $("#derror_price").text("");
    }
 });

 
 </script>

<script>


$("#product_stock").keyup(function(){
     var product_stock = $("#product_stock").val();
     var filter =/^\d{1,8}(\d{1,4})?$/;
     if (!filter.test(product_stock)) {
       //alert('Please provide a valid email address');
       $("#derror_stock").text(product_stock+" is not a valid stock");
       product_stock.focus;
       //return false;
    } else {
        $("#derror_stock").text("");
    }
 });

 </script>

<script>


$("#product_desc").keyup(function(){
     var product_desc = $("#product_desc").val();
     var filter =/^[a-zA-Z0-9?$@#()'!,+\-=_:.&€£*%\s]+$/;
     if (!filter.test(product_desc)) {
       //alert('Please provide a valid email address');
       $("#derror_desc").text(product_desc +" is not a valid description");
       product_desc.focus;
       //return false;
    } else {
        $("#derror_desc").text("");
    }
 });

 </script>

<script>
(function($) {
    $.fn.checkFileType = function(options) {
        var defaults = {
            allowedExtensions: [],
            success: function() {},
            error: function() {}
        };
        options = $.extend(defaults, options);

        return this.each(function() {

            $(this).on('change', function() {
                var value = $(this).val(),
                    file = value.toLowerCase(),
                    extension = file.substring(file.lastIndexOf('.') + 1);

                if ($.inArray(extension, options.allowedExtensions) == -1) {
                    options.error();
                    $(this).focus();
                } else {
                    options.success();

                }

            });

        });
    };

})(jQuery);

$(function() {
    var pic = $("#pic").val();
    $('#pic').checkFileType({
        allowedExtensions: ['jpg','jpeg','png'],
        success: function() {
        $("#derror_pic").text("success");

            //alert('Success');
        },
        error: function() {
            $("#derror_pic").text(pic+"  not a valid file type");
           // alert('Error');
        }
    });

});
</script>

<script>
(function($) {
    $.fn.checkFileType = function(options) {
        var defaults = {
            allowedExtensions: [],
            success: function() {},
            error: function() {}
        };
        options = $.extend(defaults, options);

        return this.each(function() {

            $(this).on('change', function() {
                var value = $(this).val(),
                    file = value.toLowerCase(),
                    extension = file.substring(file.lastIndexOf('.') + 1);

                if ($.inArray(extension, options.allowedExtensions) == -1) {
                    options.error();
                    $(this).focus();
                } else {
                    options.success();

                }

            });

        });
    };

})(jQuery);

$(function() {
    var files = $("#files").val();
    $('#files').checkFileType({
        allowedExtensions: ['jpg','jpeg','png'],
        success: function() {
        $("#derror_pics").text("success");

            //alert('Success');
        },
        error: function() {
            $("#derror_pics").text(files+"  not a valid file type");
           // alert('Error');
        }
    });

});
</script>


                	
                </form> 




        </div>












<br><br>
            		
            <hr/>

        <!-- ****** Footer Area End ****** -->
    </div>
    <!-- /.wrapper end -->

    <!-- jQuery (Necessary for All JavaScript Plugins) -->
    <script src="../../../designer/js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="../../../designer/js/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="../../../designer/js/bootstrap.min.js"></script>
    <!-- Plugins js -->
    <script src="../../../designer/js/plugins.js"></script>
    <!-- Active js -->
    <script src="../../../designer/js/active.js"></script>
    <script>
// Get the elements with class="column"
var elements = document.getElementsByClassName("column");

// Declare a loop variable
var i;

// Full-width images
function one() {
    for (i = 0; i < elements.length; i++) {
        elements[i].style.msFlex = "100%";  // IE10
        elements[i].style.flex = "100%";
    }
}

// Two images side by side
function two() {
    for (i = 0; i < elements.length; i++) {
        elements[i].style.msFlex = "50%";  // IE10
        elements[i].style.flex = "50%";
    }
}

// Four images side by side
function four() {
    for (i = 0; i < elements.length; i++) {
        elements[i].style.msFlex = "25%";  // IE10
        elements[i].style.flex = "25%";
    }
}

// Add active class to the current button (highlight it)
var header = document.getElementById("myHeader");
var btns = header.getElementsByClassName("btn");
for (var i = 0; i < btns.length; i++) {
  btns[i].addEventListener("click", function() {
    var current = document.getElementsByClassName("active");
    current[0].className = current[0].className.replace(" active", "");
    this.className += " active";
  });
}
</script>
 <script>
            var msg = '{{Session::get('alert')}}';
            var exist = '{{Session::has('alert')}}';
            if(exist){
            alert(msg);
             }
        </script>  

</body>

</html>