
<!DOCTYPE HTML>
<html>
<head>
<link rel="icon" href="../../../customer/img/core-img/favicon.ico">
<title></title>
<meta name="csrf-token" content="{{ csrf_token() }}" />

<script src="../../../admin/js/jQuery v3.3.1.js"></script>

<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Glance Design Dashboard Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
SmartPhone Compatible web template, free WebDesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>

<!-- Bootstrap Core CSS -->
<link href="../../../admin/css/bootstrap.css" rel='stylesheet' type='text/css' />

<!-- Custom CSS -->
<link href="../../../admin/css/style.css" rel='stylesheet' type='text/css' />

<!-- font-awesome icons CSS -->
<link href="../../../admin/css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons CSS-->

<!-- side nav css file -->
<link href='../../../admin/css/SidebarNav.min.css' media='all' rel='stylesheet' type='text/css'/>
<!-- //side nav css file -->
 
 <!-- js-->
<script src="../../../admin/js/jquery-1.11.1.min.js"></script>
<script src="../../../admin/js/modernizr.custom.js"></script>

<!--webfonts-->
<link href="//fonts.googleapis.com/css?family=PT+Sans:400,400i,700,700i&amp;subset=cyrillic,cyrillic-ext,latin-ext" rel="stylesheet">
<!--//webfonts--> 

<!-- chart -->
<script src="../../../admin/js/Chart.js"></script>
<!-- //chart -->

<!-- Metis Menu -->
<script src="../../../admin/js/metisMenu.min.js"></script>
<script src="../../../admin/js/custom.js"></script>
<link href="../../../admin/css/custom.css" rel="stylesheet">
<!--//Metis Menu -->
<style>
#chartdiv {
  width: 100%;
  height: 295px;
}

table
{
	text-align:center;
	
}

	
th
{
    height:100px;
    /* width:150px; */
	background-color:#000;
	text-align:center;
	color:#FFF;
}
td
{
    text-align:center;
    height:100px;
    width:150px;
}
input[type=text],input[type=textarea],input[type=password],input[type=number],input[type=email],input[type=date],textarea {
            width: 100%;
            padding: 15px;
            margin: 5px 0 22px 0;
            display: inline-block;
            border:none;
            background:#f2f2f2;
            border-radius: 12px;
           
            }
            select {
            width: 400px;
            padding: 15px;
            margin: 5px 0 22px 0;
            display: inline-block;
            
            background:#f2f2f2;
            border-radius: 12px;
           
            }

</style>
<!--pie-chart --><!-- index page sales reviews visitors pie chart -->
<script src="../../../admin/js/pie-chart.js" type="text/javascript"></script>
<!-- <script type="text/javascript">

        $(document).ready(function () {
            $('#demo-pie-1').pieChart({
                barColor: '#2dde98',
                trackColor: '#eee',
                lineCap: 'round',
                lineWidth: 8,
                onStep: function (from, to, percent) {
                    $(this.element).find('.pie-value').text(Math.round(percent) + '%');
                }
            });

            $('#demo-pie-2').pieChart({
                barColor: '#8e43e7',
                trackColor: '#eee',
                lineCap: 'butt',
                lineWidth: 8,
                onStep: function (from, to, percent) {
                    $(this.element).find('.pie-value').text(Math.round(percent) + '%');
                }
            });

            $('#demo-pie-3').pieChart({
                barColor: '#ffc168',
                trackColor: '#eee',
                lineCap: 'square',
                lineWidth: 8,
                onStep: function (from, to, percent) {
                    $(this.element).find('.pie-value').text(Math.round(percent) + '%');
                }
            });

           
        });

    </script>-->
<!-- //pie-chart --><!-- index page sales reviews visitors pie chart -->

	<!-- requried-jsfiles-for owl -->
					<link href="../../../admin/css/owl.carousel.css" rel="stylesheet">
					<!--<script src="../../../admin/js/owl.carousel.js"></script>
						<script>
							$(document).ready(function() {
								$("#owl-demo").owlCarousel({
									items : 3,
									lazyLoad : true,
									autoPlay : true,
									pagination : true,
									nav:true,
								});
							});
						</script>-->
					<!-- //requried-jsfiles-for owl -->
</head> 
<body class="cbp-spmenu-push">
<?php
                                        use App\Logs;
                                        $sess=session()->get('email');
                                        $a=Logs::where('email',$sess)->get();
                                        foreach($a as $object)
                                        {
                                            $log_id=$object->log_id;
                                            $reg_id=$object->reg_id;
                                        }
                                        $user = DB::table('registers')->where('reg_id', $reg_id)->first();
                                        $name = DB::table('registers')->where('reg_id', $reg_id)->pluck('register_name');
                                        //dd($name[0]);
                ?>
	<div class="main-content">
	<div class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left" id="cbp-spmenu-s1">
		<!--left-fixed -navigation-->
		<aside class="sidebar-left">
      <nav class="navbar navbar-inverse">
          <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".collapse" aria-expanded="false">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            </button>
            <h1><a class="navbar-brand"><span><img src="../../../customer/img/core-img/favicon.ico" style="width:50px;height:50px;"></span>HC<span class="dashboard_text"></span></a></h1>
          </div>
          <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="sidebar-menu">
              <li class="header"></li>
              <li class="treeview">
                <a href="/dashboard">
                <i class="fa fa-dashboard"></i> <span>Dashboard</span>
                </a>
              </li>
			  <li class="treeview">
                <a href="#">
                <i class="fa fa-laptop"></i>
                <span>Orders</span>
                <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                <li><a href="/delivered_orders"><i class="fa fa-angle-right"></i>Delivered Orders</a></li>
                  <li><a href="/dispatched_orders"><i class="fa fa-angle-right"></i>Dispatched Orders</a></li>
                </ul>
              </li>
              <li class="treeview">
                <a href="#">
                <i class="fa fa-laptop"></i>
                <span>Products</span>
                <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                  <li><a href="/product_type"><i class="fa fa-angle-right"></i>New Product Type</a></li>
                  <li><a href="/new_product"><i class="fa fa-angle-right"></i>Add New Products</a></li>
                </ul>
              </li>
              
              <li class="treeview">
                <a href="#">
                <i class="fa fa-laptop"></i>
                <span>Designs Requests</span>
                <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                  <li><a href="/req_from_cust"><i class="fa fa-angle-right"></i>Request From Customers</a></li>
                  <li><a href="/designer_products"><i class="fa fa-angle-right"></i>Designs From Designer</a></li>
                  <li><a href="/notify_customer"><i class="fa fa-angle-right"></i>Designed Customer Request</a></li>
                  <li><a href="/completed_admin_request"><i class="fa fa-angle-right"></i>Completed Admin Requests</a></li>
                  <li><a href="/completed_customer_request"><i class="fa fa-angle-right"></i>CompletedCustomerRequests</a></li>

                </ul>
              </li>
			  
              <li class="treeview">
                <a href="#">
                <i class="fa fa-edit"></i> <span>Views</span>
                <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                  <li><a href="{{route('view', ['reg_id' => $reg_id])}}"><i class="fa fa-angle-right"></i>Products View</a></li>
                  <li><a href="{{route('catview', ['reg_id' => $reg_id])}}"><i class="fa fa-angle-right"></i>Categorical View</a></li>
                  <li><a href="{{route('viewpro', ['reg_id' => $reg_id])}}"><i class="fa fa-angle-right"></i>All Products View</a></li>
                  <li><a href="{{route('viewprocat', ['reg_id' => $reg_id])}}"><i class="fa fa-angle-right"></i>Product Categories</a></li>
                  <li><a href="{{route('viewfabrics', ['reg_id' => $reg_id])}}"><i class="fa fa-angle-right"></i>Used Fabrics</a></li>
                  <li><a href="{{route('size_chart', ['reg_id' => $reg_id])}}"><i class="fa fa-angle-right"></i>Size Chart</a></li>



                </ul>
              </li>
             
              <li class="treeview">
                <a href="#">
                <i class="fa fa-envelope"></i> <span>Users </span>
                
                <ul class="treeview-menu">
                  <li><a href="{{route('customer', ['reg_id' => $reg_id])}}"><i class="fa fa-angle-right"></i> Customer</a></li>
                  <li><a href="{{route('designer', ['reg_id' => $reg_id])}}"><i class="fa fa-angle-right"></i> Designer</a></li>
                  <li><a href="{{route('distributor', ['reg_id' => $reg_id])}}"><i class="fa fa-angle-right"></i> Distributor</a></li>
                </ul>
              </li>
             
            </ul>
          </div>
          <!-- /.navbar-collapse -->
      </nav>
    </aside>
	</div>
		<!--left-fixed -navigation-->
		
		<!-- header-starts -->
		<div class="sticky-header header-section ">
			<div class="header-left">
				<!--toggle button start-->
				<button id="showLeftPush"><i class="fa fa-bars"></i></button>
				<!--toggle button end-->
				<div class="profile_details_left"><!--notifications of menu start -->
					<ul class="nofitications-dropdown">
						<?Php
              $cart=DB::table('carts')->where('status',0)->where('checked',1)->get();
              $c=count($cart);
              
            ?>
          <li class="dropdown head-dpdn">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-bell"></i><span class="badge blue">{{$c}}</span></a>
							<ul class="dropdown-menu">
								<li>
									<div class="notification_header">
										<h3>You have {{$c}} new notification</h3>
									</div>
								</li>
              <?php
                if($c!=0)
                {
                  foreach($cart as $a)
                  {
                    $p=$a->product_id;
                    $c=DB::table('products')->where('product_id',$p)->first();
                    $d=DB::table('registers')->where('reg_id',$a->reg_id)->first();
              ?>
              
								<li><a href="#">
									<div class="user_img"><img src="../../../storage/upload/<?php echo $c->cover_image; ?>" alt=""></div>
								   <div class="notification_desc">
									<p>{{$c->product_name}}</p>
									<p><span>{{$d->register_name}}</span></p>
									</div>
								  <div class="clearfix"></div>	
								 </a></li>
              <?php
                  }
                }
                
              ?>
								 
							</ul>
						</li>	
											
						<li class="dropdown head-dpdn">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-bell"></i><span class="badge blue">0</span></a>
							<ul class="dropdown-menu">
								<li>
									<div class="notification_header">
										<h3>You have 0 new notification</h3>
									</div>
								</li>
							</ul>
						</li>
								
								
						<li class="dropdown head-dpdn">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-tasks"></i><span class="badge blue1">0</span></a>
							<ul class="dropdown-menu">
								<li>
									<div class="notification_header">
										<h3>You have 0 pending task</h3>
									</div>
								</li>
							</ul>
						</li>
								
					<div class="clearfix"> </div>
				</div>
				<!--notification menu end -->
				<div class="clearfix"> </div>
			</div>
			<div class="header-right">
				
				
				<!--search-box-->
				<!--<div class="search-box">
					<form class="input">
						<input class="sb-search-input input__field--madoka" placeholder="Search..." type="search" id="input-31" />
						<label class="input__label" for="input-31">
							<svg class="graphic" width="100%" height="100%" viewBox="0 0 404 77" preserveAspectRatio="none">
								<path d="m0,0l404,0l0,77l-404,0l0,-77z"/>
							</svg>
						</label>
					</form>
				</div>--><!--//end-search-box-->
				
				<div class="profile_details">		
					<ul>
						<li class="dropdown profile_details_drop">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
								<div class="profile_img">	
									<span class="prfil-img"><img src="../../../storage/upload/{{$user->register_photo}}" style="width:50px;height:50px;border-radius:25px;" alt=""> </span> 
									<div class="user-name"> 
                                    
                                    
										<p><?php  echo $name[0];?>{{csrf_field()}}</p>
										<span>Administrator</span>
									</div>
									<i class="fa fa-angle-down lnr"></i>
									<i class="fa fa-angle-up lnr"></i>
									<div class="clearfix"></div>	
								</div>	
							</a>
							<ul class="dropdown-menu drp-mnu">
								<!--<li> <a href="#"><i class="fa fa-cog"></i> Settings</a> </li> 
								<li> <a href="#"><i class="fa fa-user"></i> My Account</a> </li> -->
								<li> <a href="{{route('logs', ['reg_id' => $reg_id])}}"><i class="fa fa-suitcase"></i> Profile</a> </li> 
								<li> <a href="/logout"><i class="fa fa-sign-out"></i> Logout</a> </li>
							</ul>
						</li>
					</ul>
				</div>
				<div class="clearfix"> </div>				
			</div>
			<div class="clearfix"> </div>	
		</div>

		<?php 
					  	
						  
						  $sess=session()->get('email');
						  $a=Logs::where('email',$sess)->get();
						  foreach($a as $object)
						  {
							  $log_id=$object->log_id;
							  $reg_id=$object->reg_id;
						  }
						 // $user = DB::table('registers')->where('reg_id', $reg_id)->pluck('');

						  $customer = DB::table('logs')->where('login_type', 1)->count();
						  $distributor = DB::table('logs')->where('login_type', 3)->count();
						  $designer = DB::table('logs')->where('login_type', 2)->count();



						  //dd($name);
						  //echo $name;
					  
		?>


		<!-- //header-ends -->
		<!-- main content start-->
		<div id="page-wrapper">

            <div style="width:1450px;height:auto;margin-top:20px;">
			
                <table style="width:1500px;margin-top:40px;">
                    <tr>
                          <th>Product ID</th>
                          <th>Customer</th>
                          <th>Product Name</th>
                          <th>Image</th>
                          <th></th>
                          <th>Quantity</th>
                          <th>Size</th>
                          <th>Fabric</th>
                          <th>Status</th>
                          <th>Distributor</th>
                          <th>Action</th>
                    </tr>
                            <?php
                                $m=DB::table('request_designers')->whereIn('status',array(3,0))->where('checked',1)->get();
                                
                                if(count($m)!=0)
                                {
                                    foreach($m as $i)
                                    {
                                        
                                        $email=DB::table('logs')->where('reg_id',$i->reg_id)->first();
                                        $product=DB::table('products')->where('product_id',$i->product_id)->first();
                                        $product_name=$product->product_name;
                                        $size=DB::table('letter_sizes')->where('letter_size_id',$product->letter_size_id)->first();
                                        $fabric=DB::table('fabrics')->where('fab_id',$product->fab_id)->first();
                                        $distributors=DB::table('registers')->select('registers.reg_id','registers.register_name','logs.email','logs.login_status','logs.login_type')
->join('logs','registers.reg_id','=','logs.reg_id')
->where(['login_type'=>3])
->get();
                                          //$co_id=$i->co_id;

                            ?>
                                        <tr>
                                            
                                            <td><input type="text" id="product_id"  value="{{$i->product_id}}" readonly style="width:50px;"></td>

                                            <td><input type="text"  value="{{$email->email}}" readonly style="width:250px;"></td>

                                            <td><input type="text" id="product_name" value="{{$product_name}}" readonly style="width:100px;"></td>

                                            <td><img src="../../../storage/upload/{{$product->cover_image}}"  style="width:70px;height:70px;border-radius:35px;"></td>

                                            <td><input type="hidden" value="{{$product->product_color}}" id="product_color" readonly style="width:70px;height:70px;border-radius:35px; background-color:#{{$i->product_color}};"></td> 
                                            
                                            <td><input type="text" value="{{$i->quantity}}" id="quantity" readonly style="width:50px;"></td>

                                            <td><input type="text" value="{{$size->letter_size}}"  readonly style="width:150px;"></td>

                                            <td><input type="text" value="{{$fabric->fab_name}}"  readonly style="width:100px;"></td>
                                            <td>
                                                <?php
                                                if($i->status==0)
                                                {
                                                ?>
                                                    <img src="../../../admin/images/completed.jpg" style="width:100px;height:100px;border-radius:50px;">
                                                <?php
                                                }
                                                else if($i->status==3)
                                                {
                                                ?>
                                                    <img src="../../../admin/images/requested.jpg" style="width:100px;height:100px;border-radius:50px;">
                                                <?php
                                                }
                                                ?>
                                            </td>
                                            <td>
                                                <form method="post" action="{{route('request_cust_distributor', ['rtd_id' => $i->rtd_id])}}"enctype="multipart/form-data" name="add_product" id="add_product">
                                                    <input type="hidden" name="_token" value="{{csrf_token()}}">
                                                    @csrf


                                                <?php
                                                if($i->status==0)
                                                {
                                                ?>
                                                <select id="distributor" name="distributor" class="distributor" required>
                                                    <option></option>
                                                    <?php
                                                        foreach($distributors as $s)
                                                        {
                                                    ?>
                                                        <option value="{{$s->reg_id}}">{{$s->register_name}}({{$s->email}})</option>
                                                    <?php
                                                        }
                                                    ?>
                                                </select>
                                                    <?php
                                                }
                                                else
                                                {
                                            ?>

                                            <?php
                                                }
                                            ?>
                                            </td>
                                            <td>
                                                <?php
                                                    if($i->status==0)
                                                    {
                                                ?>
                                                    <button id="req_designer" name="req_designer"  style="background-color:green;color:white;width:180px;height:70px;">Send To Distributor</button>

                                                <?php
                                                    }
                                                    else{
                                                ?>
                                                    <button id="req_designer" name="req_designer"  style="background-color:green;color:white;width:180px;height:70px;">Request Moved To the Distributor</button>

                                                <?php
                                                    }
                                                ?>
                                            </td>

                                                </form>

                                        </tr>

                            <?php

                                    }
                                }
                          ?>
                </table>
                <script type="text/javascript">
                     var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');

                      function update(co_id) {
                       // alert(co_id);
                       var coid = parseInt(document.getElementById('cart_id-'+co_id).value); 
                        var pid = parseInt(document.getElementById('product_id-'+co_id).value);
                        var uemail = document.getElementById('user_email-'+co_id).value;
                        var pname = document.getElementById('product_name-'+co_id).value;
                        var pcolor = document.getElementById('product_color-'+co_id).value;
                        var qty = parseInt(document.getElementById('quantity-'+co_id).value);
                        var lsize = document.getElementById('size-'+co_id).value;
                        var fname = document.getElementById('fab_name-'+co_id).value;
                        var designer = document.getElementById('designer-'+co_id).value; 
                       
                    //alert(coid);
                    // alert(pid);
                    //alert(uemail);
                     //alert(pcolor);
                    //     alert(qty);
                     //    alert(lsize);
                    //   alert(fname);
                    // alert(designer);

                            $.ajax({
                                url: '/admin_request_designer',
                                data: {'_token': CSRF_TOKEN, 'check_cart' : coid, 'user_email' : uemail, 'designer' : designer, 'product_id' : pid, 'product_color' : pcolor, 'letter_size' : lsize, 'fname' : fname, 'quantity' : qty},
                                type: "post",
                                
                                success: function (update) {
                                  //alert(update);
                                 //alert(JSON.stringify(update));
                                  alert('Request send to the designer');
                                  document.location.reload(true)
                                   // alert('failed');
                                  
                                }
                                
                            });
                        }


                </script>
        	</div>
            <div class="clearfix"> </div>
		</div>
		
				
	
	<!-- for amcharts js -->
			

    <!-- <script  src="../../../admin/js/index1.js"></script> -->
	<div class="clearfix"> </div>
			
		</div>
				
			</div>
		</div>
	<!--footer-->
	
	</div>
		
	<!-- new added graphs chart js-->
	
    
    




    

	<!-- new added graphs chart js-->
	
	<!-- Classie --><!-- for toggle left push menu script -->
		<script src="../../../admin/js/classie.js"></script>
		<script>
			var menuLeft = document.getElementById( 'cbp-spmenu-s1' ),
				showLeftPush = document.getElementById( 'showLeftPush' ),
				body = document.body;
				
			showLeftPush.onclick = function() {
				classie.toggle( this, 'active' );
				classie.toggle( body, 'cbp-spmenu-push-toright' );
				classie.toggle( menuLeft, 'cbp-spmenu-open' );
				disableOther( 'showLeftPush' );
			};
			

			function disableOther( button ) {
				if( button !== 'showLeftPush' ) {
					classie.toggle( showLeftPush, 'disabled' );
				}
			}
		</script>
	<!-- //Classie --><!-- //for toggle left push menu script -->
		
	<!--scrolling js-->
	<script src="../../../admin/js/jquery.nicescroll.js"></script>
	<script src="../../../admin/js/scripts.js"></script>
	<!-- scrolling js -->
	
	<!-- side nav js -->
	<script src='../../../admin/js/SidebarNav.min.js' type='text/javascript'></script>
	<script>
      $('.sidebar-menu').SidebarNav()
    </script> 
	<!-- //side nav js-->
	
	<!-- for index page weekly sales java script -->
	<script src="../../../admin/js/SimpleChart.js"></script>
    
	<!-- //for index page weekly sales java script -->
	
	
	<!-- Bootstrap Core JavaScript -->
   <script src="../../../admin/js/bootstrap.js"> </script>
	<!-- //Bootstrap Core JavaScript -->
	
</body>
</html>
