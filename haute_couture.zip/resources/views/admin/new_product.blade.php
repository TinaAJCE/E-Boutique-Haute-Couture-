
<!DOCTYPE HTML>
<html>
<head>
<link rel="icon" href="../../../customer/img/core-img/favicon.ico">
<title></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Glance Design Dashboard Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
SmartPhone Compatible web template, free WebDesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>

<!-- Bootstrap Core CSS -->
<link href="../../../admin/css/bootstrap.css" rel='stylesheet' type='text/css' />

<!-- Custom CSS -->
<link href="../../../admin/css/style.css" rel='stylesheet' type='text/css' />

<!-- font-awesome icons CSS -->
<link href="../../../admin/css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons CSS-->

<!-- side nav css file -->
<link href='../../../admin/css/SidebarNav.min.css' media='all' rel='stylesheet' type='text/css'/>
<!-- //side nav css file -->
 
 <!-- js-->
<script src="../../../admin/js/jquery-1.11.1.min.js"></script>
<script src="../../../admin/js/modernizr.custom.js"></script>

<!--webfonts-->
<link href="//fonts.googleapis.com/css?family=PT+Sans:400,400i,700,700i&amp;subset=cyrillic,cyrillic-ext,latin-ext" rel="stylesheet">
<!--//webfonts--> 



<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.5/css/select2.css" />




<!-- chart -->
<script src="../../../admin/js/Chart.js"></script>
<!-- //chart -->

<!-- Metis Menu -->
<script src="../../../admin/js/metisMenu.min.js"></script>
<script src="../../../admin/js/custom.js"></script>
<link href="../../../admin/css/custom.css" rel="stylesheet">



 
<!--//Metis Menu -->
<style>
#chartdiv {
  width: 100%;
  height: 295px;
}
</style>
<!--pie-chart --><!-- index page sales reviews visitors pie chart -->
<script src="../../../admin/js/pie-chart.js" type="text/javascript"></script>
<!-- <script type="text/javascript">

        $(document).ready(function () {
            $('#demo-pie-1').pieChart({
                barColor: '#2dde98',
                trackColor: '#eee',
                lineCap: 'round',
                lineWidth: 8,
                onStep: function (from, to, percent) {
                    $(this.element).find('.pie-value').text(Math.round(percent) + '%');
                }
            });

            $('#demo-pie-2').pieChart({
                barColor: '#8e43e7',
                trackColor: '#eee',
                lineCap: 'butt',
                lineWidth: 8,
                onStep: function (from, to, percent) {
                    $(this.element).find('.pie-value').text(Math.round(percent) + '%');
                }
            });

            $('#demo-pie-3').pieChart({
                barColor: '#ffc168',
                trackColor: '#eee',
                lineCap: 'square',
                lineWidth: 8,
                onStep: function (from, to, percent) {
                    $(this.element).find('.pie-value').text(Math.round(percent) + '%');
                }
            });

           
        });

    </script>-->
<!-- //pie-chart --><!-- index page sales reviews visitors pie chart -->

	<!-- requried-jsfiles-for owl -->
					<link href="../../../admin/css/owl.carousel.css" rel="stylesheet">
					<!--<script src="../../../admin/js/owl.carousel.js"></script>
						<script>
							$(document).ready(function() {
								$("#owl-demo").owlCarousel({
									items : 3,
									lazyLoad : true,
									autoPlay : true,
									pagination : true,
									nav:true,
								});
							});
						</script>-->
					<!-- //requried-jsfiles-for owl -->
    <style>
            th
            { 
               
            } 
            th, td { 
                width:150px; 
                text-align:center; 
                
                padding:5px 
              
            } 
            .col_3
            {
                padding-top: 5px; 
            }
            input[type=text],input[type=textarea],input[type=password],input[type=number],input[type=email],input[type=date],textarea,select,button {
            width: 100%;
            padding: 15px;
            margin: 5px 0 22px 0;
            display: inline-block;
            border: none;
            background:#959494;
            border-radius: 12px;
           
            }
            input[type=file]
            {
               
                padding: 15px;
                width:150px;
                background:#959494;
               
                 
            }
            input[type=submit]
            {
                width: 800px;; 
                margin: 5px 0 22px 200px;
                height:60px;
                display: inline-block;
                color:white;
                border: none;
                background:#15D047;
                border-radius: 12px;
                
            }
            #d1
            {
                
            }
    
        body {
            font-family: Arial, Helvetica, sans-serif;
            background-color: black;
        }

        /** {
            box-sizing: border-box;
        }

        /* Add padding to containers */
        .container {
        /* padding: 16px;*/
            background-color: white;
            background-image:url(images/photo-1533628635777-112b2239b1c7.jpg);
            background-repeat:repeat;
            
        }

        /* Full-width input fields */
        input[type=text],input[type=file],input[type=password],input[type=number],input[type=email],input[type=date],textarea,select,button {
            width: 100%;
            padding: 15px;
            margin: 5px 0 22px 0;
            display: inline-block;
            border: none;
            background: #f1f1f1;
            border-radius: 12px;
        }

        input[type=text]:focus, input[type=password]:focus {
            background-color: #ddd;
            outline: none;
        }

        /* Overwrite default styles of hr */
        hr {
            border: 1px solid #f1f1f1;
            margin-bottom: 25px;
        }

        /* Set a style for the submit button */
        .registerbtn {
            background-color: #4CAF50;
            color: white;
            padding: 16px 20px;
            margin: 8px 0;
            border: none;
            cursor: pointer;
            width: 100%;
            opacity: 0.9;
        }

        .registerbtn:hover {
            opacity: 1;
        }

        /* Add a blue text color to links */
        a {
            color: dodgerblue;
        }

        /* Set a grey background color and center the text of the "sign in" section */
        .signin {
            background-color: #f1f1f1;
            text-align: center;
        }
        /*div.about {
            position: absolute;
            left: 150px;
            width: 200px;
            height: 120px;
            border: 3px solid green;
        } */





        #button1{
            
        width: 380px;
        height: 40px;
        color:#000;
        border-radius:20px;


        }
        #button2{
        width: 380px;
        height: 40px;
        color:#000;
        border-radius:20px;

        }

    </style>

</head> 
<body class="cbp-spmenu-push">
<div class="main-content">
	<div class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left" id="cbp-spmenu-s1">
		<!--left-fixed -navigation-->
		<aside class="sidebar-left">
      <nav class="navbar navbar-inverse">
          <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".collapse" aria-expanded="false">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            </button>
            <h1><a class="navbar-brand"><span><img src="../../../customer/img/core-img/favicon.ico" style="width:50px;height:50px;"></span>H C<span class="dashboard_text"></span></a></h1>
          </div>
          <?php
                                        use App\Logs;
                                        $sess=session()->get('reg_id');
                                        // dd($sess);
                                        $a=DB::table('logs')->where('reg_id',$sess)->first();
                                        //Logs::where('reg_id',$sess)->first();
                                            // $log_id=$a->id;
                                            $reg_id=$a->reg_id;
                                        
                                        $user = DB::table('registers')->where('reg_id', $reg_id)->first();
                                        $name = DB::table('registers')->where('reg_id', $reg_id)->pluck('register_name');
                                       
                                    ?>

          <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="sidebar-menu">
              <li class="header"></li>
              <li class="treeview">
                <a href="/dashboard">
                <i class="fa fa-dashboard"></i> <span>Dashboard</span>
                </a>
              </li>
			  <li class="treeview">
                <a href="#">
                <i class="fa fa-laptop"></i>
                <span>Orders</span>
                <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                <li><a href="/delivered_orders"><i class="fa fa-angle-right"></i>Delivered Orders</a></li>
                  <li><a href="/dispatched_orders"><i class="fa fa-angle-right"></i>Dispatched Orders</a></li>
                </ul>
              </li>
              <li class="treeview">
                <a href="#">
                <i class="fa fa-laptop"></i>
                <span>Products</span>
                <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                  <li><a href="/product_type"><i class="fa fa-angle-right"></i>New Product Type</a></li>
                  <li><a href="/new_product"><i class="fa fa-angle-right"></i>Add New Products</a></li>
                </ul>
              </li>
              
              <li class="treeview">
                <a href="#">
                <i class="fa fa-laptop"></i>
                <span>Designs Requests</span>
                <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                  <li><a href="/req_from_cust"><i class="fa fa-angle-right"></i>Request From Customers</a></li>
                  <li><a href="/designer_products"><i class="fa fa-angle-right"></i>Designs From Designer</a></li>
                  <li><a href="/completed_admin_request"><i class="fa fa-angle-right"></i>Completed Admin Requests</a></li>
                  <li><a href="/completed_customer_request"><i class="fa fa-angle-right"></i>CompletedCustomerRequests</a></li>

                </ul>
              </li>
			  
              <li class="treeview">
                <a href="#">
                <i class="fa fa-edit"></i> <span>Views</span>
                <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                  <li><a href="{{route('view', ['reg_id' => $reg_id])}}"><i class="fa fa-angle-right"></i>Products View</a></li>
                  <li><a href="{{route('catview', ['reg_id' => $reg_id])}}"><i class="fa fa-angle-right"></i>Categorical View</a></li>
                  <li><a href="{{route('viewpro', ['reg_id' => $reg_id])}}"><i class="fa fa-angle-right"></i>All Products View</a></li>
                  <li><a href="{{route('viewprocat', ['reg_id' => $reg_id])}}"><i class="fa fa-angle-right"></i>Product Categories</a></li>
                  <li><a href="{{route('viewfabrics', ['reg_id' => $reg_id])}}"><i class="fa fa-angle-right"></i>Used Fabrics</a></li>
                  <li><a href="{{route('size_chart', ['reg_id' => $reg_id])}}"><i class="fa fa-angle-right"></i>Size Chart</a></li>



                </ul>
              </li>
             
              <li class="treeview">
                <a href="#">
                <i class="fa fa-envelope"></i> <span>Users </span>
                
                <ul class="treeview-menu">
                  <li><a href="{{route('customer', ['reg_id' => $reg_id])}}"><i class="fa fa-angle-right"></i> Customer</a></li>
                  <li><a href="{{route('designer', ['reg_id' => $reg_id])}}"><i class="fa fa-angle-right"></i> Designer</a></li>
                  <li><a href="{{route('distributor', ['reg_id' => $reg_id])}}"><i class="fa fa-angle-right"></i> Distributor</a></li>
                </ul>
              </li>
             
            </ul>
          </div>
          <!-- /.navbar-collapse -->
      </nav>
    </aside>
	</div>
		<!--left-fixed -navigation-->
		
		<!-- header-starts -->
		<div class="sticky-header header-section ">
			<div class="header-left">
				<!--toggle button start-->
				<button id="showLeftPush"><i class="fa fa-bars"></i></button>
				<!--toggle button end-->
                <div class="profile_details_left"><!--notifications of menu start -->
					<ul class="nofitications-dropdown">
						<?Php
              $cart=DB::table('carts')->where('status',0)->where('checked',1)->get();
              $c=count($cart);
              
            ?>
          <li class="dropdown head-dpdn">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-bell"></i><span class="badge blue">{{$c}}</span></a>
							<ul class="dropdown-menu">
								<li>
									<div class="notification_header">
										<h3>You have {{$c}} new notification</h3>
									</div>
								</li>
              <?php
                if($c!=0)
                {
                  foreach($cart as $a)
                  {
                    $p=$a->product_id;
                    $c=DB::table('products')->where('product_id',$p)->first();
                    $d=DB::table('registers')->where('reg_id',$reg_id)->first();
              ?>
              
								<li><a href="#">
									<div class="user_img"><img src="../../../storage/upload/<?php echo $c->cover_image; ?>" alt=""></div>
								   <div class="notification_desc">
									<p>{{$c->product_name}}</p>
									<p><span>{{$d->register_name}}</span></p>
									</div>
								  <div class="clearfix"></div>	
								 </a></li>
              <?php
                  }
                }
                
              ?>
								 
							</ul>
						</li>	
											
						<li class="dropdown head-dpdn">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-bell"></i><span class="badge blue">0</span></a>
							<ul class="dropdown-menu">
								<li>
									<div class="notification_header">
										<h3>You have 0 new notification</h3>
									</div>
								</li>
							</ul>
						</li>
								
								
						<li class="dropdown head-dpdn">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-tasks"></i><span class="badge blue1">0</span></a>
							<ul class="dropdown-menu">
								<li>
									<div class="notification_header">
										<h3>You have 0 pending task</h3>
									</div>
								</li>
							</ul>
						</li>
								
					<div class="clearfix"> </div>
				</div>
				<!--notification menu end -->
				<div class="clearfix"> </div>
			</div>
			<div class="header-right">
				
				
				<!--search-box-->
				<!--<div class="search-box">
					<form class="input">
						<input class="sb-search-input input__field--madoka" placeholder="Search..." type="search" id="input-31" />
						<label class="input__label" for="input-31">
							<svg class="graphic" width="100%" height="100%" viewBox="0 0 404 77" preserveAspectRatio="none">
								<path d="m0,0l404,0l0,77l-404,0l0,-77z"/>
							</svg>
						</label>
					</form>
				</div>--><!--//end-search-box-->
				
				<div class="profile_details">		
					<ul>
						<li class="dropdown profile_details_drop">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
								<div class="profile_img">	
									<span class="prfil-img"><img src="" alt=""> </span> 
									<div class="user-name">
                                    
                                    
										<p>Tina Jose</p>
										<span>Administrator</span>
									</div>
									<i class="fa fa-angle-down lnr"></i>
									<i class="fa fa-angle-up lnr"></i>
									<div class="clearfix"></div>	
								</div>	
							</a>
							<ul class="dropdown-menu drp-mnu">
								<!--<li> <a href="#"><i class="fa fa-cog"></i> Settings</a> </li> 
								<li> <a href="#"><i class="fa fa-user"></i> My Account</a> </li> -->
								<li> <a href=""><i class="fa fa-suitcase"></i> Profile</a> </li> 
								<li> <a href="/logout"><i class="fa fa-sign-out"></i> Logout</a> </li>
							</ul>
						</li>
					</ul>
				</div>
               
				<div class="clearfix"> </div>				
			</div>
            
			<div class="clearfix"> </div>
            	
		</div>
       
		<!-- //header-ends -->
<!-- main content start-->
<div id="page-wrapper">
			<div class="main-page">
			<div class="col_3">
            <br>
            <h2>Add New Product</h2>
            <div>
                                     <?php
                                        use App\ProductsCategory;
                                        $systems= DB::table('products_categories')->select('category_id','category_name')->get();
                                          
                                    ?>
                                    <script src="../../../admin/js/jscolor.js"></script>
            
                <hr>
                <form method="post" action="/new_product_add"  enctype="multipart/form-data" name="add_product" id="add_product">
                <input type="hidden" name="_token" value="{{csrf_token()}}">
                @csrf

                <div class="container" style="width:80%">
                    
    				<br><br>		
                    <label for="category"><b>Product Category</b></label>
                        <select id="p_category" name="p_category">
                            <?php
                                foreach($systems as $object)
                                {
                                    $category_id=$object->category_id;
                                    $category_name=$object->category_name;
                                    echo"<option value='$category_id'>$category_name</option>";
                                }
                                    
                            ?>
                             <label id="derror_name"></label>     
                         </select>
                         <br>
                    <label for="name"><b>Brand Name</b></label>
                        <input type="text" placeholder="Enter Product Name" name="product_name" autocomplete="off" id="product_name"  required>
						<label id="derror_name" style="color: red;"></label>
                        <br>
                    <label for="color"><b>Product Color</b></label>
                    <input type="text"  name="product_color" id="product_color" class="jscolor {width:200, height:150, position:'right'}" style="width: 100%;padding: 15px; margin: 5px 0 22px 0; display: inline-block;border: none; background: #f1f1f1;border-radius: 12px;">

                        <br>
                    <label for="price"><b>Unit Price</b></label>
                        <input type="number" placeholder="Enter Price" name="product_price" id="product_price" autocomplete="off" min="1" required>
						<label id="derror_price" style="color: red;"></label>
                    <br>

                    
                   <label for="stock"><b>Product Stock</b></label>
                        <input type="number" placeholder="Enter Stock" name="product_stock" id="product_stock" autocomplete="off" min="1" required>
						<label id="derror_stock" style="color: red;"></label>
                    <br>
                    
                    <label for="description"><b>Product Description</b></label>
                        <textarea rows="10" cols="50" name="product_desc" id="product_desc" autocomplete="off" required>
                        </textarea>
                        <label id="derror_desc" style="color: red;"></label>

                    <br>
                    <?php
                    $syst= DB::table('letter_sizes')->select('letter_size_id','letter_size')->get();
                    ?>
                    <label for="letter_size"><b>Size</b></label>
                        <select id="size" name="size" required>
                            <option></option>
                            <?php
                                foreach($syst as $object)
                                {
                                    $l_id=$object->letter_size_id;
                                    $l_size=$object->letter_size;
                                    echo"<option value='$l_id'>$l_size</option>";
                                }
                                    
                            ?>
                             <label id="derror_lname"></label>     
                         </select>
                         <br>

                    
                    <?php
                    $sys= DB::table('bust_sizes')->select('bs_id','bust_size')->get();
                    ?>
                    <label for="bust_size"><b>Chest Measurement</b></label>
                        <select id="b_size" name="b_size" required>
                            <option></option>
                            <?php
                                foreach($sys as $object)
                                {
                                    $b_id=$object->bs_id;
                                    $b_size=$object->bust_size;
                                    echo"<option value='$b_id'>$b_size</option>";
                                }
                                    
                            ?>
                    <label id="derror_bname"></label>     
                    </select>
                    <br>
                    <?php
                    $sysm= DB::table('natural_waists')->select('n_id','natural_waist_size')->get();
                    ?>
                    <label for="na_size"><b>Natural Waist Size</b></label>
                        <select id="n_size" name="n_size" required>
                            <option></option>
                            <?php
                                foreach($sysm as $object)
                                {
                                    $n_id=$object->n_id;
                                    $n_size=$object->natural_waist_size;
                                    echo"<option value='$n_id'>$n_size</option>";
                                }
                                    
                            ?>
                             <label id="derror_nname"></label>     
                         </select>
                         <br>

                         <br>
                    <?php
                    $sysmt= DB::table('hip_sizes')->select('h_id','hip_size')->get();
                    ?>
                    <label for="hip_size"><b>Hip Size</b></label>
                        <select id="h_size" name="h_size" required>
                            <option></option>
                            <?php
                                foreach($sysmt as $object)
                                {
                                    $h_id=$object->h_id;
                                    $h_size=$object->hip_size;
                                    echo"<option value='$h_id'>$h_size</option>";
                                }
                                    
                            ?>
                             <label id="derror_hname"></label>     
                         </select>
                         <br>
                    <?php
                    $sysms= DB::table('low_waists')->select('l_id','low_waist_size')->get();
                    ?>
                    <label for="l_size"><b>Low Waist Size</b></label>
                        <select id="l_size" name="l_size" required>
                            <option></option>
                            <?php
                                foreach($sysms as $object)
                                {
                                    $l_id=$object->l_id;
                                    $l_size=$object->low_waist_size;
                                    echo"<option value='$l_id'>$l_size</option>";
                                }
                                    
                            ?>
                             <label id="derror_lname"></label>     
                         </select>     
                         <br>

                    <?php
                    $fabs= DB::table('fabrics')->select('fab_id','fab_name','fab_image')->get();
                    ?>
                    <label for="fabs"><b>Used Fabric</b></label>
                     <select id="fabs" name="fabs" style="background: #f1f1f1;" required>
                            <option></option>
                            <?php
                                foreach($fabs as $object)
                                {
                                    $f_id=$object->fab_id;
                                    $fname=$object->fab_name;
                                    $image=$object->fab_image;
                                    echo"<option value='$f_id' data-img_src='../../../storage/upload/$image'>$fname</option>";
                                }
                                    
                            ?>
                             <label id="derror_lname"></label>     
                         </select>
                         <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.5/js/select2.js"></script>
<script type="text/javascript">
    function custom_template(obj){
            var data = $(obj.element).data();
            var text = $(obj.element).text();
            if(data && data['img_src']){
                img_src = data['img_src'];
                template = $("<div><img src=\"" + img_src + "\" style=\"width:65px;height:65px;border-radius:32.5px;\"/>" + text + "</div>");
                return template;
            }
        }
    var options = {
        'templateSelection': custom_template,
        'templateResult': custom_template,
    }
    $('#fabs').select2(options);
    $('.select2-container--default .select2-selection--single').css({'height': '70px','background': '#f1f1f1','border-radius':'12px'});

</script>

                    <label for="cover_photo"><b>Cover Photo</b></label>
                        <input type="file" id="pic" name="pic" autocomplete="off" required>
                        <label id="derror_pic" style="color: red;"></label>
                    <br>
                    
                    <label for="photos"><b>Photos</b></label>
                        <input type="file" autocomplete="off" name="files[]" id="files[]" multiple required>
                        <label id="derror_pics" style="color: red;"></label>
   
                    <hr>

                    <button type="submit" id="create_item" name="create_item" style="background-color:#3C3;">Add New Product</button>
                </div>
                <script src="jscolor.js"></script>
                <script>


$("#product_name").keyup(function(){
     var product_name = $("#product_name").val();
     var filter = /^(?![\s]+$)[a-zA-Z\s]*$/;
     if (!filter.test(product_name)) {
       //alert('Please provide a valid email address');
       $("#derror_name").text(product_name+" is not a valid name");
       product_name.focus;
       //return false;
    } else {
        $("#derror_name").text("");
    }
 });


 
 </script>
<script>


$("#product_price").keyup(function(){
     var product_price = $("#product_price").val();
     var filter =/^\d{1,8}(\.\d{1,4})?$/;
     if (!filter.test(product_price)) {
       //alert('Please provide a valid email address');
       $("#derror_price").text(product_price+" is not a valid price");
       product_price.focus;
       //return false;
    } else {
        $("#derror_price").text("");
    }
 });

 
 </script>

<script>


$("#product_stock").keyup(function(){
     var product_stock = $("#product_stock").val();
     var filter =/^\d{1,8}(\d{1,4})?$/;
     if (!filter.test(product_stock)) {
       //alert('Please provide a valid email address');
       $("#derror_stock").text(product_stock+" is not a valid stock");
       product_stock.focus;
       //return false;
    } else {
        $("#derror_stock").text("");
    }
 });

 </script>

<script>


$("#product_desc").keyup(function(){
     var product_desc = $("#product_desc").val();
     var filter =/^[a-zA-Z0-9?$@#()'!,+\-=_:.&€£*%\s]+$/;
     if (!filter.test(product_desc)) {
       //alert('Please provide a valid email address');
       $("#derror_desc").text(product_desc +" is not a valid description");
       product_desc.focus;
       //return false;
    } else {
        $("#derror_desc").text("");
    }
 });

 </script>

<script>
(function($) {
    $.fn.checkFileType = function(options) {
        var defaults = {
            allowedExtensions: [],
            success: function() {},
            error: function() {}
        };
        options = $.extend(defaults, options);

        return this.each(function() {

            $(this).on('change', function() {
                var value = $(this).val(),
                    file = value.toLowerCase(),
                    extension = file.substring(file.lastIndexOf('.') + 1);

                if ($.inArray(extension, options.allowedExtensions) == -1) {
                    options.error();
                    $(this).focus();
                } else {
                    options.success();

                }

            });

        });
    };

})(jQuery);

$(function() {
    var pic = $("#pic").val();
    $('#pic').checkFileType({
        allowedExtensions: ['jpg','jpeg','png'],
        success: function() {
        $("#derror_pic").text("success");

            //alert('Success');
        },
        error: function() {
            $("#derror_pic").text(pic+"  not a valid file type");
           // alert('Error');
        }
    });

});
</script>

<script>
(function($) {
    $.fn.checkFileType = function(options) {
        var defaults = {
            allowedExtensions: [],
            success: function() {},
            error: function() {}
        };
        options = $.extend(defaults, options);

        return this.each(function() {

            $(this).on('change', function() {
                var value = $(this).val(),
                    file = value.toLowerCase(),
                    extension = file.substring(file.lastIndexOf('.') + 1);

                if ($.inArray(extension, options.allowedExtensions) == -1) {
                    options.error();
                    $(this).focus();
                } else {
                    options.success();

                }

            });

        });
    };

})(jQuery);

$(function() {
    var files = $("#files").val();
    $('#files').checkFileType({
        allowedExtensions: ['jpg','jpeg','png'],
        success: function() {
        $("#derror_pics").text("success");

            //alert('Success');
        },
        error: function() {
            $("#derror_pics").text(files+"  not a valid file type");
           // alert('Error');
        }
    });

});
</script>














                	
                </form> 











                </div>                    
        	<div class="clearfix"> </div>
		</div>
		
		<script>
            var msg = '{{Session::get('alert')}}';
            var exist = '{{Session::has('alert')}}';
            if(exist){
            alert(msg);
             }
        </script>		
	
	<!-- for amcharts js -->
			<script src="../../../admin/js/amcharts.js"></script>
			<script src="../../../admin/js/serial.js"></script>
			<script src="../../../admin/js/export.min.js"></script>
			<link rel="stylesheet" href="../../../admin/css/export.css" type="text/css" media="all" />
			<script src="../../../admin/js/light.js"></script>
	<!-- for amcharts js -->

    <script  src="../../../admin/js/index1.js"></script>
	
						
			</div>
		</div>
	<!--footer-->
	
    <!--//footer-->
	</div>
		
	<!-- new added graphs chart js-->
	
    <script src="../../../admin/js/Chart.bundle.js"></script>
    <script src="../../../admin/js/utils.js"></script>
	
	<script>
        var MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
        var color = Chart.helpers.color;
        var barChartData = {
            labels: ["January", "February", "March", "April", "May", "June", "July"],
            datasets: [{
                label: 'Dataset 1',
                backgroundColor: color(window.chartColors.red).alpha(0.5).rgbString(),
                borderColor: window.chartColors.red,
                borderWidth: 1,
                data: [
                    randomScalingFactor(),
                    randomScalingFactor(),
                    randomScalingFactor(),
                    randomScalingFactor(),
                    randomScalingFactor(),
                    randomScalingFactor(),
                    randomScalingFactor()
                ]
            }, {
                label: 'Dataset 2',
                backgroundColor: color(window.chartColors.blue).alpha(0.5).rgbString(),
                borderColor: window.chartColors.blue,
                borderWidth: 1,
                data: [
                    randomScalingFactor(),
                    randomScalingFactor(),
                    randomScalingFactor(),
                    randomScalingFactor(),
                    randomScalingFactor(),
                    randomScalingFactor(),
                    randomScalingFactor()
                ]
            }]

        };

        window.onload = function() {
            var ctx = document.getElementById("canvas").getContext("2d");
            window.myBar = new Chart(ctx, {
                type: 'bar',
                data: barChartData,
                options: {
                    responsive: true,
                    legend: {
                        position: 'top',
                    },
                    title: {
                        display: true,
                        text: 'Chart.js Bar Chart'
                    }
                }
            });

        };

        document.getElementById('randomizeData').addEventListener('click', function() {
            var zero = Math.random() < 0.2 ? true : false;
            barChartData.datasets.forEach(function(dataset) {
                dataset.data = dataset.data.map(function() {
                    return zero ? 0.0 : randomScalingFactor();
                });

            });
            window.myBar.update();
        });

        var colorNames = Object.keys(window.chartColors);
        document.getElementById('addDataset').addEventListener('click', function() {
            var colorName = colorNames[barChartData.datasets.length % colorNames.length];;
            var dsColor = window.chartColors[colorName];
            var newDataset = {
                label: 'Dataset ' + barChartData.datasets.length,
                backgroundColor: color(dsColor).alpha(0.5).rgbString(),
                borderColor: dsColor,
                borderWidth: 1,
                data: []
            };

            for (var index = 0; index < barChartData.labels.length; ++index) {
                newDataset.data.push(randomScalingFactor());
            }

            barChartData.datasets.push(newDataset);
            window.myBar.update();
        });

        document.getElementById('addData').addEventListener('click', function() {
            if (barChartData.datasets.length > 0) {
                var month = MONTHS[barChartData.labels.length % MONTHS.length];
                barChartData.labels.push(month);

                for (var index = 0; index < barChartData.datasets.length; ++index) {
                    //window.myBar.addData(randomScalingFactor(), index);
                    barChartData.datasets[index].data.push(randomScalingFactor());
                }

                window.myBar.update();
            }
        });

        document.getElementById('removeDataset').addEventListener('click', function() {
            barChartData.datasets.splice(0, 1);
            window.myBar.update();
        });

        document.getElementById('removeData').addEventListener('click', function() {
            barChartData.labels.splice(-1, 1); // remove the label first

            barChartData.datasets.forEach(function(dataset, datasetIndex) {
                dataset.data.pop();
            });

            window.myBar.update();
        });
    </script>
	<!-- new added graphs chart js-->
	
	<!-- Classie --><!-- for toggle left push menu script -->
		<script src="../../../admin/js/classie.js"></script>
		<script>
			var menuLeft = document.getElementById( 'cbp-spmenu-s1' ),
				showLeftPush = document.getElementById( 'showLeftPush' ),
				body = document.body;
				
			showLeftPush.onclick = function() {
				classie.toggle( this, 'active' );
				classie.toggle( body, 'cbp-spmenu-push-toright' );
				classie.toggle( menuLeft, 'cbp-spmenu-open' );
				disableOther( 'showLeftPush' );
			};
			

			function disableOther( button ) {
				if( button !== 'showLeftPush' ) {
					classie.toggle( showLeftPush, 'disabled' );
				}
			}
		</script>
	<!-- //Classie --><!-- //for toggle left push menu script -->
		
	<!--scrolling js-->
	<script src="../../../admin/js/jquery.nicescroll.js"></script>
	<script src="../../../admin/js/scripts.js"></script>
	<!--//scrolling js-->
	
	<!-- side nav js -->
	<script src='../../../admin/js/SidebarNav.min.js' type='text/javascript'></script>
	<script>
      $('.sidebar-menu').SidebarNav()
    </script>
	<!-- //side nav js -->
	
	<!-- for index page weekly sales java script -->
	<script src="../../../admin/js/SimpleChart.js"></script>
    <script>
       

    </script>
	<!-- //for index page weekly sales java script -->
	
	
	<!-- Bootstrap Core JavaScript -->
   <script src="../../../admin/js/bootstrap.js"> </script>
	<!-- //Bootstrap Core JavaScript -->
	
</body>
</html>
